﻿using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Abstractions;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Resolvers;
using Newtonsoft.Json.Serialization;

namespace CDOIntegrationService.Refactor.Models
{
    [OpenApiExample(typeof(SchedulingTicketRequest))]
    public class SchedulingTicketRequestModel
    {
        [OpenApiProperty]
        public string Id { get; set; }
        [OpenApiProperty]
        public string Method { get; set; }
        [OpenApiProperty]
        public string EOW { get; set; }
        [OpenApiProperty]
        public string CdoName { get; set; }
        [OpenApiProperty]
        public string patientFhirId { get; set; }
        [OpenApiProperty]
        public string pendedOrderId { get; set; }
    }

    public class SchedulingTicketRequest : OpenApiExample<SchedulingTicketRequestModel>
    {
        public override IOpenApiExample<SchedulingTicketRequestModel> Build(NamingStrategy namingStrategy = null)
        {
            this.Examples.Add(
                 OpenApiExampleResolver.Resolve(
                     "SchedulingTicketRequest",
                     new SchedulingTicketRequestModel()
                     {
                         Id = "Test_8007_Kelsey",
                         Method = "Bridge-Refill",
                         EOW = "8007",
                         CdoName = "Kelsey",
                         patientFhirId = "eVcnydVbqbyyxUVgU5TJXJA3",
                         pendedOrderId = "44983376"
                     },
                     namingStrategy
                 ));
            return this;
        }
    }
}