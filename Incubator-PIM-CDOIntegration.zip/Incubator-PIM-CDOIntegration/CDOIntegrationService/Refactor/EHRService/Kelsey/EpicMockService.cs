﻿using System;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.ConfigService;
using CDOIntegrationService.Refactor.Models;
using Microsoft.Extensions.Logging;

namespace CDOIntegrationService
{
    public class EpicMockService : IEHRService
    {
        private readonly ILogger<EpicMockService> _logger;
        private readonly IBlobServices _blobServices;
        private readonly IAzureConfig _configuration;

        public EpicMockService(ILogger<EpicMockService> logger, IBlobServices blobServices, IAzureConfig configuration)
        {
            _logger = logger;
            _blobServices = blobServices;
            _configuration = configuration;
        }

        public async Task<string> GetPatientData(string patientFhirId, string resourceType, EhrFetchType ehrFetchType)
        {
            try
            {
                _logger.LogInformation("EpicMockService.GetPatientData() execution started");

                var isSingleJson = _configuration.GetValueFromAzureConfig<bool>("IsSingleMockJson");

                var mockData = isSingleJson ? await _blobServices.FetchBlobData(@$"Kelsey/EhrMockResponse/{patientFhirId}.json")
                    : await GetPatientDataMultiple(patientFhirId, resourceType);

                _logger.LogInformation("EpicMockService.GetPatientData() execution ended");

                return mockData;
            }

            catch (Exception ex)
            {
                _logger.LogError("EpicMockService.GetPatientData() failed. Exception: {Error}", ex);
                throw;
            }
        }

        public async Task<string> GetPatientDataForMRUpdater(string patientFhirId, string resourceName)
        {
            try
            {
                _logger.LogInformation("EpicMockService.GetMedicationRequestForMRUpdater() execution started for patientID: " + patientFhirId + " and Resource: " + resourceName);

                string response;
                if (resourceName.Contains("Appointment") || resourceName.Contains("Condition") || resourceName.Contains("Encounter") || resourceName.Contains("MedicationRequest") || resourceName.Contains("AllergyIntolerance") || resourceName.Contains("Observation") || resourceName.Contains("Patient"))
                    response = await _blobServices.FetchBlobData(@$"Kelsey/EhrMockResponse/{patientFhirId}/{resourceName.ToLower()}.json");
                else if (resourceName.Contains("Location") || resourceName.Contains("Medication"))
                    response = await _blobServices.FetchBlobData(@$"Kelsey/EhrMockResponse/{resourceName}.json");
                else
                    response = await _blobServices.FetchBlobData(@$"Kelsey/EhrMockResponse/{patientFhirId}/{resourceName}.json");

                _logger.LogInformation("EpicMockService.GetMedicationRequestForMRUpdater() execution ended for patientID: " + patientFhirId + " and Resource: " + resourceName);
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError("EpicMockService.GetPatientDataForMRUpdater() failed. Exception: {Error}", ex);
                throw;
            }
        }

        Task<bool> IEHRService.GetEhrHealth()
        {
            throw new NotImplementedException();
        }

        public async Task<string> GetPatientDataMultiple(string resourceFhirId, string resourceName)
        {
            try
            {
                _logger.LogInformation("EpicMockService.GetPatientDataMultiple() execution started for patientID: " + resourceFhirId + " and Resource: " + resourceName);

                string response;
                if (resourceName.Contains("Appointment") || resourceName.Contains("Condition") || resourceName.Contains("Encounter") || resourceName.Contains("MedicationRequest") || resourceName.Contains("AllergyIntolerance") || resourceName.Contains("Observation") || resourceName.Contains("Patient"))
                    response = await _blobServices.FetchBlobData(@$"Kelsey/EhrMockResponse/{resourceFhirId}/{resourceName.ToLower()}.json");

                else if (resourceName.Contains("Location") || resourceName.Contains("Medication"))
                    response = await _blobServices.FetchBlobData(@$"Kelsey/EhrMockResponse/{resourceName}.json");

                else
                    response = await _blobServices.FetchBlobData(@$"Kelsey/EhrMockResponse/{resourceFhirId}/{resourceName}.json");

                _logger.LogInformation("EpicMockService.GetPatientDataMultiple() execution ended for patientID: " + resourceFhirId + " and Resource: " + resourceName);
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError("EpicMockService.GetPatientDataMultiple() failed. Exception: {Error}", ex);
                throw;
            }
        }
    }
}