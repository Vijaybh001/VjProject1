﻿using System;
using System.Collections.Generic;
using FhirServiceLibrary;

namespace CDOIntegrationService.Refactor.Models
{
    public class DeletePatientModel
    {
        public List<FhirCrudIdentifier> Identifiers { get; set; }
        public string PatientFhirId { get; set; }
        public bool DeleteAll { get; set; }
        public string resourceTypes { get; set; }
        public bool IsFhirIdDelete { get; set; }
    }
}

