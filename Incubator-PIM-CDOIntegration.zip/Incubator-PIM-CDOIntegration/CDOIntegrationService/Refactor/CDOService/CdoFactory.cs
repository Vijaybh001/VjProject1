using System;
using CDOIntegrationService.Refactor;
using CDOIntegrationService.Refactor.MedicationRequestStatusUpdate;
using CDOIntegrationService.Refactor.MessageService;
using CDOIntegrationService.Refactor.Models;
using CDOIntegrationService.Refactor.MyChartService;
using CDOIntegrationService.Refactor.ReturnToProvider;
using CDOIntegrationService.Refactor.SchedulingTicketService;
using CDOIntegrationService.Refactor.SignFinalOrder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace CDOIntegrationService;

public class CdoFactory : ICdoFactory
{
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<CdoFactory> _logger;
    
    public CdoFactory(IServiceProvider serviceProvider,  ILogger<CdoFactory> logger)
    {
        _serviceProvider = serviceProvider;
        _logger = logger;
    }
    public IEHRWrapper GetEhrWrapperService(string CdoName)
    {
        _logger.LogInformation("KelseyCdoService.GetEhrWrapperService() execution started ");
        _logger.LogInformation("KelseyCdoService.GetEhrWrapperService() execution ended ");
        //var services = _serviceProvider.GetServices<IEHRWrapper>();
        return CdoName switch
        {
            Constants.KELSEY => _serviceProvider.GetService<KelseyEHRWrapper>(),
            _ => throw new Exception("Invalid CDO Type"),
        };
    }

    public IMedicationRequestStatusUpdater GetMedicationRequestUpdateWrapperService(string CdoName)
    {
        _logger.LogInformation("KelseyCdoService.GetMedicationRequestUpdateWrapperService() execution started ");
        _logger.LogInformation("KelseyCdoService.GetMedicationRequestUpdateWrapperService() execution ended ");
        //var services = _serviceProvider.GetServices<IMedicationRequestStatusUpdate>();
        return CdoName switch
        {
            Constants.KELSEY => _serviceProvider.GetService<KelseyMedicationRequestStatusUpdate>(),
            _ => throw new Exception("Invalid CDO Type"),
        };
    }

    public ICheckMedicationRequestStatus CheckMedicationRequestStatusWrapperService(string CdoName)
    {
        _logger.LogInformation("KelseyCdoService.CheckMedicationRequestStatusWrapperService() execution started ");
        _logger.LogInformation("KelseyCdoService.CheckMedicationRequestStatusWrapperService() execution ended ");
        return CdoName switch
        {
            Constants.KELSEY => _serviceProvider.GetService<CheckMedicationRequestStatus>(),
            _ => throw new Exception("Invalid CDO Type"),
        };
    }

    public ISendMyChartMessage SendMyChartMessage(string CdoName, bool isMock)
    {
        _logger.LogInformation("KelseyCdoService.SendMyChartMessage() execution started ");
        _logger.LogInformation("KelseyCdoService.SendMyChartMessage() execution ended ");
        return CdoName switch
        {
            Constants.KELSEY => isMock ? _serviceProvider.GetService<SendMockMyChartMessage>() : _serviceProvider.GetService<SendMyChartMessage>(),
            _ => throw new Exception("Invalid CDO Type"),
        };
    }

    public IFhirWrapper GetFhirWrapperService(string CdoName)
    {
        _logger.LogInformation("KelseyCdoService.GetFhirWrapperService() execution started ");
        _logger.LogInformation("KelseyCdoService.GetFhirWrapperService() execution ended ");
        //var services = _serviceProvider.GetServices<IFhirWrapper>();
        return CdoName switch
        {
            Constants.KELSEY => _serviceProvider.GetService<KelseyFhirWrapper>(),
            _ => throw new Exception("Invalid CDO Type"),
        };
    }

    public ICDSService GetCdsService(string CdoName)
    {
        throw new NotImplementedException();

    }

    public IMessageService GetMessageService(string CdoName, bool isMock)
    {
        _logger.LogInformation("KelseyCdoService.GetMessageService() execution started ");
        _logger.LogInformation("KelseyCdoService.GetMessageService() execution ended ");
        return CdoName switch
        {
            Constants.KELSEY => isMock ? _serviceProvider.GetService <KelseyMockMessageService>() : _serviceProvider.GetService <KelseyMessageService>(),
            _ => throw new Exception("Invalid CDO Type"),
        };
    }

    public ISignFinalOrder GetSignFinalOrder(string CdoName, bool isMock)
    {
        _logger.LogInformation("KelseyCdoService.GetSignFinalOrder() execution started ");
        _logger.LogInformation("KelseyCdoService.GetSignFinalOrder() execution ended ");
        return CdoName switch
        {
            Constants.KELSEY => isMock ? _serviceProvider.GetService<SignFinalOrderMock>() : _serviceProvider.GetService<SignFinalOrder>(),
            _ => throw new Exception("Invalid CDO Type"),
        };
    }

    public IProcessSchedulingTicket processSchedulingTicket(SchedulingTicketRequestModel req, string CdoName)
    {
        _logger.LogInformation("KelseyCdoService.processSchedulingTicket() execution started ");
        _logger.LogInformation("KelseyCdoService.processSchedulingTicket() execution ended ");
        return CdoName switch
        {
            Constants.KELSEY => _serviceProvider.GetService<ProcessSchedulingTicket>(),
            Constants.XYZ => _serviceProvider.GetService<ProcessSchedulingTicket>(),
            _ => throw new Exception("Invalid CDO Type"),
        };
    }

    public ISendRecommendation sendRecommendation(string CdoName, bool isMock)
    {
        _logger.LogInformation("KelseyCdoService.sendRecommendation() execution started ");
        _logger.LogInformation("KelseyCdoService.sendRecommendation() execution ended ");
        return CdoName switch
        {
            Constants.KELSEY => isMock ? _serviceProvider.GetService<SendMockRecommendation>() : _serviceProvider.GetService<SendRecommendation>(),
            _ => throw new Exception("Invalid CDO Type"),
        };
    }
}