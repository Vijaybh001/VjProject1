namespace CDOIntegrationService;

public class EpicCDSService:ICDSService
{
    public void OrderSign(string patientId)
    {
        throw new System.NotImplementedException();
    }
}