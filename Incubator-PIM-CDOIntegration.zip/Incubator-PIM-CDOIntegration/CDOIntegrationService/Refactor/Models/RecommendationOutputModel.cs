﻿using System;
namespace CDOIntegrationService.Refactor.Models
{
    public class RecommendationOutputModel
    {
        public APIStatus APIStatus { get; set; }
    }
}

