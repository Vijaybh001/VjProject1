using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using System.Net;
using CDOIntegrationService.Refactor.Models;
using FluentValidation;
using Hl7.Fhir.Serialization;
using Serilog.Context;
using Incubator_OIA_CommonModels;
using CDOIntegrationService.Refactor.CustomException;
using static Hl7.Fhir.Model.VerificationResult;
using Hl7.Fhir.Model;
using System.Text.Json;
using YamlDotNet.Serialization;
namespace CDOIntegrationService;

public class GetPatientRawHttpTrigger
{
    private readonly ICdoServiceFactory _cdoFactory;
    private readonly ILogger<GetPatientRawHttpTrigger> _logger;
    private readonly IValidator<PatientRequestModel> _validator;
    public GetPatientRawHttpTrigger(ILogger<GetPatientRawHttpTrigger> log, ICdoServiceFactory cdoFactory, IValidator<PatientRequestModel> validator)
    {
        _cdoFactory = cdoFactory;
        _logger = log;
        _validator = validator;
    }
    [HttpPost]
    [FunctionName("GetPatientEverythingInfo")]
    [OpenApiOperation(operationId: "GetPatientEverythingInfo", tags: new[] { "GetPatientEverythingInfo" })]
    [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(PatientRequestModel), Deprecated = false, Description = "Request", Required = true)]
    [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string))]
    public async Task<IActionResult> GetPatientEverythingInfo(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] PatientRequestModel req,
            ILogger log)
    {

        try
        {
            if (req == null)
                throw new ValidationException("RequestBody cannot be empty");

            await _validator.ValidateAndThrowAsync(req);
            using (LogContext.PushProperty("PatientFhirId", req.PatientFhirId))
            using (LogContext.PushProperty("CdoId", req.Identifiers.CDOID))
            {
                _logger.LogInformation("GetPatientEverythingInfo: execution started");
                var cdoService = _cdoFactory.GetCdoService(req.Identifiers.CDOID);
                var patientRaw = await cdoService.GetPatientRaw(req);

                var serializer = new FhirJsonSerializer();
                string jsonPatientData = null;

                if (patientRaw != null)
                    jsonPatientData = serializer.SerializeToString(patientRaw);

                ContentResult result = new()
                {
                    ContentType = "application/json",
                    Content = jsonPatientData,
                    StatusCode = 200
                };
                //GetPatientRawOutputModel response = new GetPatientRawOutputModel()
                //{
                //    APIStatusCode = new ResponseModel()
                //    {
                //        StatusCode = (int)HttpStatusCode.OK
                //    },
                //    BundleData = patientRaw
                //};
                
                _logger.LogInformation("GetPatientEverythingInfo: execution finished");

                return result;
            }
        }
        catch (ValidationException ex)
        {
            _logger.LogError("GetPatient.GetPatientEverythingInfo() failed. Exception: {Error}", ex);
            return new BadRequestObjectResult(new ResponseModel()
            {
                StatusCode = (int)HttpStatusCode.BadRequest,
                ErrorMessage = ex.Message
            })
            {
                StatusCode = (int)HttpStatusCode.BadRequest
            };
        }
        catch (ResponseCustomException ex)
        {
            _logger.LogError("GetPatient.GetPatientEverythingInfo() failed. Exception: {Error}", ex);
            return new BadRequestObjectResult(new GetPatientRawOutputModel()
            {
                APIStatusCode = new ResponseModel()
                {
                    StatusCode = ex.CustomObject.StatusCode,
                    ErrorMessage = $"GetPatient.GetPatientEverythingInfo() failed. Exception: {ex.CustomObject.ErrorMessage}"
                }
            })
            {
                StatusCode = ex.CustomObject.StatusCode
            };
        }
        catch (Exception ex)
        {
            var obj = new ResponseModel()
            {
                StatusCode = (int)HttpStatusCode.InternalServerError,
                ErrorMessage = ex.Message
            };
            var result = new OkObjectResult(obj)
            {
                StatusCode = (int)HttpStatusCode.InternalServerError
            };
            _logger.LogError("GetPatient.GetPatientEverythingInfo() failed. Exception: {Error}", ex);
            return result;
        }

    }
}