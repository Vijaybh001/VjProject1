﻿using System;
using CDOIntegrationService.Refactor.Models;
using System.Threading.Tasks;

namespace CDOIntegrationService.Refactor.MyChartService.Kelsey
{
	public class XyzMkoMyChartMessages:ISendMyChartMessage
	{
        public XyzMkoMyChartMessages()
        {
        }
        public async Task<MyChartMessageOutputModel> SendMessage(MyChartMessageInputModel myChartMessageInputModel)
        {
            //TODO: This async method lacks 'await' operators
            throw new NotImplementedException();
        }
    }
}

