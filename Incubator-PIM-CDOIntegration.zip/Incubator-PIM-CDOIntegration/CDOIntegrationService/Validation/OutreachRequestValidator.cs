﻿using System;
using FluentValidation;
using static Incubator_OIA_CommonModels.CosmosModel;

namespace CDOIntegrationService.Validation
{
	public class OutreachRequestValidator : AbstractValidator<OutReachRequest>
    {
		public OutreachRequestValidator()
		{
            RuleFor(x => x.CDOName).NotEmpty().WithMessage("CDOName cannot be empty");
            RuleFor(x => x.EOWID).NotEmpty().WithMessage("EOWID cannot be empty");
            RuleFor(x => x.id).NotEmpty().WithMessage("id cannot be empty");
            RuleFor(x => x.PendedOrderId).NotEmpty().WithMessage("PendedOrderId cannot be empty");
        }
	}
}


