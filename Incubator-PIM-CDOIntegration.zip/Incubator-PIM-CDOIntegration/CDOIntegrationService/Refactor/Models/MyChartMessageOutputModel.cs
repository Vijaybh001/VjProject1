﻿using System;
using Incubator_OIA_CommonModels;
using Newtonsoft.Json;

namespace CDOIntegrationService.Refactor.Models
{
    public class MyChartMessageOutputModel
    {
        [JsonProperty("mychartuserid")]
        public string Mychartuserid { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("msgid")]
        public string Msgid { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }
    }
    public class MyChartOutputModel
    {
        public ResponseModel ApiStatusCode { get; set; }
        public MyChartMessageOutputModel MyChartMessageOutputModel { get; set; }
    }

}
