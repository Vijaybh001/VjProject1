﻿using System;
using System.Collections.Generic;
using FhirServiceLibrary;
using Hl7.Fhir.Model;

namespace CDOIntegrationService.Refactor.Models
{
    public class FhirData
    {
        public Bundle Appointment { get; set; }
        public Patient Patient { get; set; }
        public Bundle Condition { get; set; }
        public Bundle Encounter { get; set; }
        //public Stu3.MedicationStatement MedStatement { get; set; }
        public Bundle MedRequest { get; set; }
        public Bundle Observation { get; set; }
        public Medication Medication { get; set; }
        public Bundle AllergyIntolerance { get; set; }
        public Bundle Location { get; set; }
        public Bundle ServiceRequest { get; set; }
    }
    public class FhirBundleData
    {
        public string FhirPatientId { get; set; }
        public string ResourceType { get; set; }
        public List<FhirCrudIdentifier> Identifiers { get; set; }
        public Bundle FhirBundle { get; set; }
        public string CdoPatientId { get; set; }
    }
}

