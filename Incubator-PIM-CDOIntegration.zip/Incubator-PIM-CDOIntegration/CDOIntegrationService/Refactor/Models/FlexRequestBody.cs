﻿using System;
using Incubator_OIA_CommonModels;

namespace CDOIntegrationService.Refactor.Models
{
    public class FlexRequestBody
	{
		public string CDOName { get; set; }
		public string ActiveMedRequestID { get; set; }
		public string PendedOrderId { get; set; }
		public string PatientMRN { get; set; }
		public int NoOfRepeats { get; set; }
		public decimal Quantity { get; set; }
        public PendAuthProvider PendAuthProvider { get; set; }
		public string OrderEncounterCSN { get; set; }
		public string RxNormCode { get; set; }
		public string MsgSubmittedInstant { get; set; }
		public string PatientFhirId { get; set; }
	}
}

