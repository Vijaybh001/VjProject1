using System;
using System.Text.Json;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.Models;
using Hl7.Fhir.Model;
using Hl7.Fhir.Serialization;
using Microsoft.Extensions.Logging;
using FhirServiceLibrary;
using JsonSerializer = System.Text.Json.JsonSerializer;
using CDOIntegrationService.Refactor;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using Hl7.Fhir.ElementModel.Types;
using Incubator_OIA_CommonModels;
using CDOIntegrationService.Refactor.CustomException;
using RestSharp;

namespace CDOIntegrationService;

public class FhirCrudService : IFhirCrudService
{
    private readonly ILogger<FhirCrudService> _logger;
    private readonly IFhirService _fhirService;
    private readonly FhirUtils _fhirUtils;
    private readonly FhirJsonParser _fhirJsonParser;

    public FhirCrudService(ILogger<FhirCrudService> logger, IFhirService fhirService, FhirUtils fhirUtils)
    {
        _logger = logger;
        _fhirService = fhirService;
        _fhirUtils = fhirUtils;
        _fhirJsonParser = new();
    }

    public async Task<Bundle> GetPatientEverythingDetails(PatientRequestModel req)
    {
        try
        {
            _logger.LogInformation("FhirCrudService.GetPatientEverythingDetails() execution started ");
            var body = new PatientRawRequest()
            {
                PatientFhirID = req.PatientFhirId,
                ResourceType = req.ResourceType
            };
            var result = await _fhirService.GetPatientEverythingById(body);
            if (result == null)
            {
                _logger.LogError("FhirCrudService.GetPatientEverythingDetails() failed. PatientBundle is null");
                ResponseModel responseModel = new ResponseModel()
                {
                    StatusCode = (int)System.Net.HttpStatusCode.BadRequest,//TODO: Need to ask from mohit for this case
                    ErrorMessage = "Patient Bundle is null"
                };
                throw new ResponseCustomException(new RestResponse(), responseModel);
            }
            _logger.LogInformation("FhirCrudService.GetPatientEverythingDetails() execution ended ");
            return result;

        }
        catch (Exception ex)
        {
            _logger.LogError("FhirCrudService.GetPatientEverythingDetails() failed. Exception: {Error}", ex);
            throw;
        }
    }

    //public async Task<string> UpsertPatient(PatientRequestModel req, Patient data)
    //{
    //    try
    //    {
    //        _logger.LogInformation("FhirCrudService.UpsertPatient() execution started ");

    //        var options = new JsonSerializerOptions().ForFhir(ModelInfo.ModelInspector);
    //        var fhirData = JsonSerializer.Serialize(data, options);

    //        var body = new PatientRawRequest()
    //        {
    //            Identifiers = _fhirUtils.CreateIdentifier(req),
    //            ResourceType = req.ResourceType
    //        };

    //        var newFhirId = await _fhirService.UpsertPatient(body, data);
    //        _logger.LogInformation("FhirCrudService.UpsertPatient() execution ended ");
    //        return newFhirId;
    //    }
    //    catch (Exception ex)
    //    {
    //        _logger.LogError("FhirCrudService.UpsertPatient() failed. Exception: {Error}", ex);
    //        throw;
    //    }
    //}

    //public async Task<string> SetBundle(PatientRequestModel req, FhirBundleData bundleData)
    //{
    //    try
    //    {
    //        _logger.LogInformation("FhirCrudService.SetBundle() execution started ");
    //        if (bundleData.FhirBundle == null)
    //        {
    //            _logger.LogInformation("FhirCrudService: SetBundle() " + bundleData.ResourceType + " bundle is null for " + bundleData.FhirPatientId);
    //            return "";
    //        }
    //        var body = new UpsertFhirModelRequest()
    //        {
    //            FhirBundle= bundleData.FhirBundle,
    //            FhirPatientId = bundleData.FhirPatientId,
    //            Identifiers = _fhirUtils.CreateIdentifier(req),
    //            ResourceType = bundleData.ResourceType
    //        };
    //        body.Identifiers.Add(new FhirCrudIdentifier()
    //        {
    //            Name = Refactor.Constants.FHIR_ID,
    //            Value = bundleData.CdoPatientId
    //        });

    //        var result = await _fhirService.UpsertNonPatientResource(body);

    //        _logger.LogInformation("FhirCrudService.SetBundle() execution ended ");
    //        return result;
    //    }
    //    catch (Exception ex)
    //    {
    //        _logger.LogError("FhirCrudService.SetBundle() failed for {Resource}. Exception: {Error}", bundleData.ResourceType, ex.Message);
    //        throw;
    //    }
    //}

    public async Task<Bundle> UpsertPatientData(PatientRequestModel req, FhirBundleData bundleData)
    {
        try
        {
            _logger.LogInformation("FhirCrudService.UpsertPatientData() execution started ");
            if (bundleData.FhirBundle == null)
            {
                _logger.LogInformation("FhirCrudService: UpsertPatientData()  bundle is null for " + bundleData.FhirPatientId);
                return null;
            }
            var body = new UpsertFhirModelRequest()
            {
                FhirPatientId = bundleData.FhirPatientId,
                Identifiers = _fhirUtils.CreateIdentifier(req),
            };
            body.Identifiers.Add(new FhirCrudIdentifier()
            {
                Name = Refactor.Constants.FHIR_ID,
                Value = bundleData.CdoPatientId
            });

            var result = await _fhirService.UpsertPatientData(body, bundleData.FhirBundle);

            _logger.LogInformation("FhirCrudService.UpsertPatientData() execution ended ");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError("FhirCrudService.UpsertPatientData() failed for {Resource}. Exception: {Error}", bundleData.ResourceType, ex.Message);
            throw;
        }
    }

    public async Task<Bundle> DeleteEverything(PatientRequestModel req, bool isFhirIdDelete, bool deleteAll)
    {
        try
        {
            _logger.LogInformation("FhirCrudService.DeleteEverything() execution started ");
            var body = new PatientRawRequest()
            {
                PatientFhirID = req.PatientFhirId
            };

            var result = await _fhirService.DeletePatientById(body, deleteAll, isFhirIdDelete);

            _logger.LogInformation("FhirCrudService.DeleteEverything() execution ended ");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError("FhirCrudService.DeleteEverything() failed. Exception: {Error}", ex);
            throw;
        }
    }

    public async Task<bool> GetFhirHealth()
    {
        try
        {
            _logger.LogInformation("FhirCrudService.GetFhirHealth() execution started ");
            PatientRequestModel req = new PatientRequestModel()
            {
                PatientFhirId = "HealthCheck",
                ResourceType = "*",
                EHRName = "HealthCheck",
                Identifiers = new PIMFhirIdentifier() {
                    EOW = "HealthCheck",
                    CDOID = "HealthCheck",
                    AssigningAuthority = "HealthCheck"
                }
            };
            var body = new PatientRawRequest()
            {
                PatientFhirID = req.PatientFhirId,
                Identifiers = _fhirUtils.CreateIdentifier(req),
                ResourceType = req.ResourceType
            };
            await _fhirService.GetPatientEverythingById(body);
            _logger.LogInformation("FhirCrudService.GetFhirHealth() execution ended ");
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError("FhirCrudService.GetFhirHealth() failed. Exception: {Error}", ex.Message);
            return false;
        }
    }

    public async Task<bool> GetUpsertFhirHealth()
    {
        try
        {
            _logger.LogInformation("FhirCrudService.GetUpsertFhirHealth() execution started ");

             //Create Patient
            var patient = new Patient();
            patient.Id = "HealthCheck";
            patient.Identifier.Add(new Identifier() { Use = Identifier.IdentifierUse.Official, System = "HealthCheck", Value = "HealthCheck" });
            patient.Active = true;
            patient.Name.Add(new HumanName() { Use = HumanName.NameUse.Official, Text = "Health Check", Family = "Check", Given = new List<string> { "Health" } });
            patient.Gender = AdministrativeGender.Female;
            patient.BirthDate = "1971-01-11";

            var dataBundle = new Bundle();
            dataBundle.AddResourceEntry(patient, "");

            var identifiers = new FhirCrudIdentifier()
            {
                Name = "CDO",
                Value = "HealthCheck"
            };

            var reqBody = new UpsertFhirModelRequest()
            {
                FhirPatientId = "HealthCheck",
                Identifiers = new List<FhirCrudIdentifier>() { identifiers }
            };

            reqBody.Identifiers.Add(new FhirCrudIdentifier()
            {
                Name = Refactor.Constants.FHIR_ID,
                Value = "HealthCheck"
            });

            await _fhirService.UpsertPatientData(reqBody, dataBundle);
            _logger.LogInformation("FhirCrudService.GetUpsertFhirHealth() execution ended ");
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError("FhirCrudService.GetUpsertFhirHealth() failed. Exception: {Error}", ex.Message);
            return false;
        }
    }

    public async Task<bool> GetDeleteFhirHealth()
    {
        try
        {
            _logger.LogInformation("FhirCrudService.GetDeleteFhirHealth() execution started ");
            var body = new PatientRawRequest()
            {
                PatientFhirID = "HealthCheck"
            };

            await _fhirService.DeletePatientById(body, true, true);

            _logger.LogInformation("FhirCrudService.GetDeleteFhirHealth() execution ended ");
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError("FhirCrudService.GetDeleteFhirHealth() failed. Exception: {Error}", ex.Message);
            return false;
        }
    }

    public async Task<Bundle> GetResourceById(string resourceId, string resourceType)
    {
        try
        {
            _logger.LogInformation("FhirCrudService.GetResourceById() execution started ");
            _logger.LogInformation("FhirCrudService.GetResourceById() execution ended ");
            return await _fhirService.GetFhirResourceById(resourceId, resourceType);
        }
        catch(Exception ex)
        {
            _logger.LogError("FhirCrudService.GetResourceById() failed. Exception: {Error}", ex);
            throw;
        }
    }
}
