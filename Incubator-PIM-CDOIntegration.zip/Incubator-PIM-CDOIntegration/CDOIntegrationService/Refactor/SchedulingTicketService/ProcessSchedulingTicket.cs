﻿using System;
using System.IO;
using System.Reflection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using CDOIntegrationService.Refactor.Models;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.MessageService;
using CDOIntegrationService.Refactor.DBLayer;

namespace CDOIntegrationService.Refactor.SchedulingTicketService
{
    public class ProcessSchedulingTicket : IProcessSchedulingTicket
    {
        private readonly IConfiguration _config;
        private readonly ILogger<KelseyMockMessageService> _logger;
        private readonly IBlobServices _blobServices;
        private readonly ICosmosService _cosmosService;

        public ProcessSchedulingTicket(IConfiguration configuration, ILogger<KelseyMockMessageService> logger, IBlobServices blobServices, ICosmosService cosmosService)
        {
            _logger = logger;
            _config = configuration;
            _blobServices = blobServices;
            _cosmosService = cosmosService;
        }

        public async Task processSchedulingTicket(SchedulingTicketRequestModel req)
        {
            try
            {
                _logger.LogInformation("ProcessSchedulingTicket.processSchedulingTicket() execution started ");

                var binDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                var rootDirectory = Path.GetFullPath(Path.Combine(binDirectory, ".."));
                var path = File.ReadAllText(rootDirectory + "/MockData/MkoPatientMessagesMock.json");

                //Todo: call createSchedulingAPI from schedulerAPI
                var responseData = JsonConvert.DeserializeObject<SchedulingTicketResponseModel>(path);

                if (responseData.APIStatus.Status.Equals("Success"))
                {
                    var cosmosRecord = await _cosmosService.FetchCosmosRecordByQueryParams(req.Id, req.CdoName);

                    var record = cosmosRecord.Orders.Find(order => order.PendedOrder.PendedOrderId == req.pendedOrderId);
                    //if (record != null && record.OrderSteps.PimOutReachSteps !=null && record.OrderSteps.PimOutReachSteps.ProcessSteps != null && record.OrderSteps.PimOutReachSteps.ProcessSteps.SchedulerTicket.Status == "Pending")
                    //{
                    //    record.OrderSteps.PimOutReachSteps.ProcessSteps.SchedulerTicket.Status = "Success";
                    //    record.OrderSteps.PimOutReachSteps.ProcessSteps.SchedulerTicket.CurrentTimestamp = DateTime.UtcNow;

                    //    var containerName = _config.GetValue<string>("CosmosDBAuditContainerInboxRefill");
                    //    var container = _cosmosService.GetContainer(containerName);
                    //    await _cosmosService.UpdateAsync<CosmosModel.CosmosData>(container, cosmosRecord, cosmosRecord.CDOName);
                    //}
                }
                else
                {
                    _logger.LogInformation("ProcessSchedulingTicket.processSchedulingTicket(): SchedulingTicket failed {Error}", responseData.APIStatus.Status);
                }

                _logger.LogInformation("ProcessSchedulingTicket.processSchedulingTicket() execution ended ");
            }
            catch (Exception ex)
            {
                _logger.LogCritical(" createSchedulingTicketHttptrigger: createSchedulingTicket() failed. Exception: {Error}", ex);
                throw;
            }
        }
    }
}