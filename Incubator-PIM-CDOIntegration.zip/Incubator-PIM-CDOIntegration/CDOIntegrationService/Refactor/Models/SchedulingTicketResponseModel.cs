﻿using System;
using System.Collections.Generic;

namespace CDOIntegrationService.Refactor.Models
{
    public class Message
    {
        public string data { get; set; }
    }

    public class SchedulingTicketResponseModel
    {
        public APIStatus APIStatus { get; set; }
        public List<Message> Messages { get; set; }
    }
}