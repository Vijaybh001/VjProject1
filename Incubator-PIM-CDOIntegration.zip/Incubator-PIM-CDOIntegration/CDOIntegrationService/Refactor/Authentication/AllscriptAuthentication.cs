using System.Threading.Tasks;
using AzureFhirFramework.RestClientWrapper;
using AzureFhirFramework.RestClientWrapper.RestPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace CDOIntegrationService.Refactor.Authentication;

public class AllscriptAuthentication: IAuthentication
{
    private readonly IConfiguration _config;
    private readonly ILogger<AllscriptAuthentication> _logger;
    private readonly IRestClientWrapper _restClientWrapper;
    public AllscriptAuthentication(IConfiguration config, ILogger<AllscriptAuthentication> logger,IRestClientWrapper restClientWrapper)
    {
        _config = config;
        _logger = logger;
        _restClientWrapper= restClientWrapper;
    }

    public Task<string> GetToken()
    {
        throw new System.NotImplementedException();
    }

    public void RefreshToken()
    {
        _logger.LogInformation("AllScriptAuthentication:RefreshToken");
    }
}
