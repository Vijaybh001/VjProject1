﻿namespace CDOIntegrationService.Refactor.Models;

public static class Constant
{
    public enum CosmosExceptionType
    {
        NotFound,
        Conflict,
        BadRequest,
        PreconditionFailed,
        InternalServerError,
        Unauthorized,
        Forbidden,
        RequestEntityTooLarge,
        TooManyRequests,
        ServiceUnavailable,
        GatewayTimeout,
        Unknown
    }

}
