﻿using System;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.MessageService;
using CDOIntegrationService.Refactor.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Serilog;

namespace CDOIntegrationService.Refactor.ReturnToProvider
{
	public class SendMockRecommendation : ISendRecommendation
	{
        private readonly IConfiguration _config;
        private readonly ILogger<SendMockRecommendation> _logger;
        private readonly IBlobServices _blobServices;
        public SendMockRecommendation(IConfiguration configuration, ILogger<SendMockRecommendation> logger, IBlobServices blobServices)
        {
            _logger = logger;
            _config = configuration;
            _blobServices = blobServices;
        }

        public Task<ReturnToProviderResponse> RecommendationMessages(RecommendationInputModel req)
        {
            //TODO: This async method lacks 'await' operators and will run synchronously.
            try
            {
                _logger.LogInformation("SendMockRecommendation.recommendationMessages() execution started ");
                var binDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                var rootDirectory = Path.GetFullPath(Path.Combine(binDirectory, ".."));
                var path = File.ReadAllText(rootDirectory + "/MockData/RecommendationToProviderMock.json");

                var responseData = JsonConvert.DeserializeObject<ReturnToProviderResponse>(path);
                responseData.EOWFWDID = req.EOWID;
                _logger.LogInformation("SendMockRecommendation.recommendationMessages() execution ended ");
                return Task.FromResult(responseData);

            }
            catch (Exception ex)
            {
                _logger.LogCritical("SendMockRecommendation: recommendationMessages() failed. Exception: {Error}", ex);
                throw;
            }
        }
    }
}

