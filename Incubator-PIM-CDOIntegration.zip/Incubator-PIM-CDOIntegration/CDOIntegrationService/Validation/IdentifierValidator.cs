﻿using CDOIntegrationService.Refactor.Models;
using FluentValidation;

namespace CDOIntegrationService.Validation
{
	public class IdentifierValidator: AbstractValidator<PIMFhirIdentifier>
	{
		public IdentifierValidator()
		{
			//RuleFor(x => x.AssigningAuthority).NotEmpty().WithMessage("AssigningAuthority cannot be empty");
            //RuleFor(x => x.EOW).NotEmpty().WithMessage("EOW cannot be empty");
            RuleFor(x => x.CDOID).NotEmpty().WithMessage("CDOID cannot be empty");
        }
	}
}

