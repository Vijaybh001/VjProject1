﻿using System;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.Authentication;
using CDOIntegrationService.Refactor.CustomException;
using CDOIntegrationService.Refactor.EHRService.Kelsey;
using CDOIntegrationService.Refactor.Flex;
using CDOIntegrationService.Refactor.Models;
using AzureFhirFramework.RestClientWrapper;
using AzureFhirFramework.RestClientWrapper.RestPolicy;
using Hl7.Fhir.Serialization;
using Incubator_OIA_CommonModels;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;
using static Incubator_OIA_CommonModels.CosmosModel;

namespace CDOIntegrationService.Refactor.SignFinalOrder
{
	public class SignFinalOrder: ISignFinalOrder
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<FlexService> _logger;
        private readonly IRestClientWrapper _restService;
        public SignFinalOrder(IConfiguration configuration, ILogger<FlexService> logger, IRestClientWrapper restClientWrapper)
        {
            _logger = logger;
            _configuration = configuration;
            _restService = restClientWrapper;
        }
        public async Task<SignFinalOrderResponseModel> SignOrder(OutReachRequest req)
        {
            try
            {
                _logger.LogInformation("SignFinalOrder.SignOrder() execution started ");
                var signFinalOrderApi = _configuration.GetValue<string>("SignFinalOrderApi");
                SignFinalOrderResponseModel signFinalOrderResponse = new SignFinalOrderResponseModel();
                var request = new RestRequest
                {
                    Method = Method.Post,
                    Resource = signFinalOrderApi
                };
                request.AddHeader("Authorization", $"Basic {_configuration.GetValue<string>("EpicBasicToken")}");
                request.AddQueryParameter("OrdId", req.PendedOrderId);
                request.AddQueryParameter("NumRefills", req.NoOfRefill);

                var response = await _restService.ExecuteRequest(request, "signFinalOrder Api");
                ResponseModel responseModel = new ResponseModel()
                {
                    StatusCode = (int)response.StatusCode,
                    ErrorMessage = response.Content
                };
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    if (response != null && !string.IsNullOrEmpty(response.Content))
                    {
                        if (!response.IsSuccessful)
                        {
                            signFinalOrderResponse.APIStatusCode = new ResponseModel
                            {
                                StatusCode = (int)response.StatusCode,
                                ErrorMessage = response.Content
                            };
                        }
                        else
                        {
                            var responseData = JsonConvert.DeserializeObject<Models.SignPendedRefillOrder>(response.Content);
                            _logger.LogInformation("SignFinalOrder.SignOrder() : SignFinalOrder api successfully Executed");
                            signFinalOrderResponse = new SignFinalOrderResponseModel
                            {
                                APIStatusCode = new ResponseModel
                                {
                                    StatusCode = (int)response.StatusCode
                                },
                                signPendedRefillOrder = new Models.SignPendedRefillOrder()
                                {
                                    actOrdStatus = responseData.actOrdStatus,
                                    OIARetOrdID = responseData.OIARetOrdID,
                                    Status = responseData.Status,
                                    eowID = responseData.eowID,
                                    eowStatus = responseData.eowStatus,
                                    ordSignedStatus = responseData.ordSignedStatus,
                                    refillEncID = responseData.refillEncID,
                                    refillEncStatus = responseData.refillEncStatus,
                                    refillNumRefills = responseData.refillNumRefills,
                                    refillSIG = responseData.refillSIG
                                }
                            };
                        }
                    }
                    else
                    {
                        _logger.LogError("SignFinalOrder.SignOrder(): SignOrder Response is null");
                        signFinalOrderResponse = new SignFinalOrderResponseModel
                        {
                            APIStatusCode = new ResponseModel
                            {
                                StatusCode = (int)response.StatusCode,
                                ErrorMessage = response.Content
                            }
                        };
                    }
                }
                else
                {
                    _logger.LogError("SignFinalOrder.SignOrder(): SignOrder Response api Failed");
                    throw new ResponseCustomException(response, responseModel);
                }
                _logger.LogInformation("SignFinalOrder.SignOrder() execution ended ");
                return signFinalOrderResponse;
            }
            catch (Exception ex)
            {
                _logger.LogError("SignFinalOrder.SignOrder() failed. Exception: {Error}", ex);
                throw;
            }
        }
    }
}

