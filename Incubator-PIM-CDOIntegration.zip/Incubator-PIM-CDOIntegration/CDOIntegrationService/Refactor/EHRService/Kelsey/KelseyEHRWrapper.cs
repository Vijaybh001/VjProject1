using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor;
using CDOIntegrationService.Refactor.EHRService.Kelsey;
using CDOIntegrationService.Refactor.Models;
using Hl7.Fhir.Model;
using Hl7.Fhir.Serialization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Serilog.Context;
using System.Diagnostics;
using System.Collections.Concurrent;
using System.Threading;

namespace CDOIntegrationService;

public class KelseyEHRWrapper : IEHRWrapper
{
    private readonly ILogger<KelseyEHRWrapper> _logger;
    private readonly IEHRFactory _eHRFactory;
    private readonly FhirJsonParser _fhirJsonParser;
    private readonly FhirJsonSerializer _fhirJsonSerializer;
    private readonly IFhirResourceConverter _fhirResourceConverter;
    private readonly IConfiguration _config;
    private readonly KelseyEHRUtils _kelseyEHRUtils;

    public KelseyEHRWrapper(ILogger<KelseyEHRWrapper> logger, IEHRFactory eHRFactory, IFhirResourceConverter fhirResourceConverter, IConfiguration config, KelseyEHRUtils kelseyEHRUtils)
    {
        _eHRFactory = eHRFactory;
        _logger = logger;
        _fhirJsonParser = new();
        _fhirJsonSerializer = new();
        _fhirResourceConverter = fhirResourceConverter;
        _config = config;
        _kelseyEHRUtils = kelseyEHRUtils;
    }

    public async Task<Bundle> GetPatientData(string patientFhirId, bool isMock)
    {
        using (LogContext.PushProperty("PatientFhirId", patientFhirId))
        {
            try
            {
                _logger.LogInformation("KelseyEHRWrapper.GetPatientData() execution started ");
                var isSingleJson = _config.GetValue<bool>("IsSingleMockJson");

                if(isMock && isSingleJson)
                {
                    // if single json to read for mock
                    var ehrservice = _eHRFactory.GetEHRService(Constants.EPIC, isMock);
                    var response = await ehrservice.GetPatientData(patientFhirId, "", EhrFetchType.ById);
                    return _fhirJsonParser.Parse<Bundle>(response);
                }
                // if multiple json/real ehr 
                return await GetPatientDataMultiple(patientFhirId, isMock);
            }

            catch (Exception ex)
            {
                _logger.LogError("KelseyEHRWrapper.GetPatientData() failed. Exception: {Error}", ex);
                throw;
            }
        }
    }

    public async Task<Bundle> GetPatientDataMultiple(string patientFhirId, bool isMock)
    {
        try
        {
            _logger.LogInformation("KelseyEHRWrapper.GetPatientData() execution started ");
            var _ehrservice = _eHRFactory.GetEHRService(Constants.EPIC, isMock);

            FhirData fhirData = new();

            var patient = await _ehrservice.GetPatientData(patientFhirId, Constants.PATIENT, EhrFetchType.ById);
            var appointment = _ehrservice.GetPatientData(patientFhirId, Constants.APPOINTMENT, EhrFetchType.ByPatient);
            var condition = _ehrservice.GetPatientData(patientFhirId, Constants.CONDITION, EhrFetchType.ByPatient);
            var encounter = _ehrservice.GetPatientData(patientFhirId, Constants.ENCOUNTER, EhrFetchType.ByPatient);
            var medRequest = _ehrservice.GetPatientData(patientFhirId, Constants.MEDICATIONREQUEST, EhrFetchType.ByPatient);
            var observation = _ehrservice.GetPatientData(patientFhirId, Constants.OBSERVATION, EhrFetchType.ByPatient);
            var allergyIntolerance = _ehrservice.GetPatientData(patientFhirId, Constants.ALLERGYINTOLERANCE, EhrFetchType.ByPatient);

            await System.Threading.Tasks.Task.WhenAll(appointment, condition, encounter, medRequest, observation, allergyIntolerance);

            if (!string.IsNullOrEmpty(patient))
            {
                fhirData.Patient = _fhirJsonParser.Parse<Patient>(patient);
            }
            else
            {
                _logger.LogInformation("KelseyEHRWrapper.GetPatientDataMultiple() - No Patient resource data for Patient: {PatientFhirId}", patientFhirId);
                throw new Exception("No Patient resource data for Patient: " + patientFhirId);
            }

            if (!string.IsNullOrEmpty(encounter.Result))
                fhirData.Encounter = _fhirJsonParser.Parse<Bundle>(encounter.Result);
            else
                _logger.LogInformation("KelseyEHRWrapper.GetPatientDataMultiple() - No Encounter resource data for Patient: {PatientFhirId}", patientFhirId);

            if (!string.IsNullOrEmpty(appointment.Result))
            {
                fhirData.Appointment = _fhirJsonParser.Parse<Bundle>(appointment.Result);
                fhirData.Encounter = _fhirResourceConverter.ConvertAppointmentToEncounter(fhirData.Appointment, fhirData.Encounter);
            }
            else
                _logger.LogInformation("KelseyEHRWrapper.GetPatientDataMultiple() - No Appointment resource data for Patient: {PatientFhirId}", patientFhirId);

            if (!string.IsNullOrEmpty(condition.Result))
                fhirData.Condition = _fhirJsonParser.Parse<Bundle>(condition.Result);
            else
                _logger.LogInformation("KelseyEHRWrapper.GetPatientDataMultiple() - No Condition resource data for Patient: {PatientFhirId}", patientFhirId);

            if (!string.IsNullOrEmpty(medRequest.Result))
            {
                fhirData.MedRequest = _fhirJsonParser.Parse<Bundle>(medRequest.Result);
                fhirData.MedRequest = await ProcessMedRequestData(fhirData.MedRequest, _ehrservice, patientFhirId);
            }
            else
                _logger.LogInformation("KelseyEHRWrapper.GetPatientDataMultiple() - No Medication Request resource data for Patient: {PatientFhirId}", patientFhirId);

            if (!string.IsNullOrEmpty(observation.Result))
            {
                fhirData.Observation = _fhirJsonParser.Parse<Bundle>(observation.Result);
                fhirData.ServiceRequest = await ProcessServiceRequestDataAsync(_ehrservice, patientFhirId, _fhirJsonParser, fhirData);
            }
            else
                _logger.LogInformation("KelseyEHRWrapper.GetPatientDataMultiple() - No Observation resource data for Patient: {PatientFhirId}", patientFhirId);

            if (!string.IsNullOrEmpty(allergyIntolerance.Result))
                fhirData.AllergyIntolerance = _fhirJsonParser.Parse<Bundle>(allergyIntolerance.Result);
            else
                _logger.LogInformation("KelseyEHRWrapper.GetPatientDataMultiple() - No Allergy Intolerance resource data for Patient: {PatientFhirId}", patientFhirId);


            fhirData.Location = await ProcessLocationDataAsync(_ehrservice, patientFhirId, _fhirJsonParser, fhirData);

            //Uncomment below 2 lines for generating mockdata loaded into Files.
            //WritePatientData(patient, encounter.Result, appointment.Result, condition.Result, diagReport.Result, medRequest.Result, observation.Result, allergyIntolerance.Result, patientFhirId, fhirData, _ehrservice);
            //return null;

            _kelseyEHRUtils.ValidateEpicData(fhirData);

            var fhirBundle = new Bundle();

            // add only resources of valid type to final bundle
            fhirBundle.AddResourceEntry(fhirData.Patient, "");
            fhirBundle.Entry.AddRange(fhirData.AllergyIntolerance.Entry.Where(entry => entry.Resource is not OperationOutcome));
            fhirBundle.Entry.AddRange(fhirData.Appointment.Entry.Where(entry => entry.Resource is not OperationOutcome));
            fhirBundle.Entry.AddRange(fhirData.Condition.Entry.Where(entry => entry.Resource is not OperationOutcome));
            fhirBundle.Entry.AddRange(fhirData.Encounter.Entry.Where(entry => entry.Resource is not OperationOutcome));
            fhirBundle.Entry.AddRange(fhirData.Location.Entry.Where(entry => entry.Resource is not OperationOutcome));
            fhirBundle.Entry.AddRange(fhirData.MedRequest.Entry.Where(entry => entry.Resource is not OperationOutcome));
            fhirBundle.Entry.AddRange(fhirData.Observation.Entry.Where(entry => entry.Resource is not OperationOutcome));
            fhirBundle.Entry.AddRange(fhirData.ServiceRequest.Entry.Where(entry => entry.Resource is not OperationOutcome));

            _logger.LogInformation("KelseyEHRWrapper.GetPatientData() execution ended ");

            return fhirBundle;
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyEHRWrapper.GetPatientData() failed. Exception: {Error}", ex);
            throw;
        }
    }
    private async Task<Bundle> ProcessMedRequestData(Bundle medRequestBundle, IEHRService _ehrservice, string patientFhirId)
    {
        try
        {
            _logger.LogInformation("KelseyEHRWrapper.ProcessMedRequestData() execution started");
            var tasks = new List<System.Threading.Tasks.Task>();
            foreach (var entry in medRequestBundle.Entry)
            {
                if (entry.Resource is MedicationRequest medRequestResource)
                {
                    _logger.LogInformation("KelseyEHRWrapper.ProcessMedRequestData() MedicationRequest resource found for MedicationRequest ID: {MedicationRequestId}", medRequestResource.Id);
                    if (medRequestResource.DispenseRequest != null && medRequestResource.DispenseRequest.ValidityPeriod != null)
                    {
                        if (!string.IsNullOrEmpty(medRequestResource.DispenseRequest.ValidityPeriod.Start))
                        {
                            medRequestResource.DispenseRequest.ValidityPeriod.Start = _kelseyEHRUtils.ConvertToDatetime(medRequestResource.DispenseRequest.ValidityPeriod.Start);
                        }
                        else
                        {
                            _logger.LogInformation("KelseyEHRWrapper.ProcessMedRequestData() - No medRequestResource.DispenseRequest.ValidityPeriod.Start for MedicationRequest ID: {MedicationRequestId}", medRequestResource.Id);
                        }
                        if (!string.IsNullOrEmpty(medRequestResource.DispenseRequest.ValidityPeriod.End))
                        {
                            medRequestResource.DispenseRequest.ValidityPeriod.End = _kelseyEHRUtils.ConvertToDatetime(medRequestResource.DispenseRequest.ValidityPeriod.End);
                        }
                        else
                        {
                            _logger.LogInformation("KelseyEHRWrapper.ProcessMedRequestData() - No medRequestResource.DispenseRequest.ValidityPeriod.End for MedicationRequest ID: {MedicationRequestId}", medRequestResource.Id);
                        }
                    }
                    else
                    {
                        _logger.LogInformation("KelseyEHRWrapper.ProcessMedRequestData() - No medRequestResource.DispenseRequest OR No medRequestResource.DispenseRequest.ValidityPeriod for MedicationRequest ID: {MedicationRequestId}", medRequestResource.Id);
                    }

                    if (medRequestResource.DosageInstruction.Count > 0)
                    {
                        string bound = "";
                        if (medRequestResource.DosageInstruction[0].Timing?.Repeat?.Bounds != null)
                        {
                            bound = _fhirJsonSerializer.SerializeToString(medRequestResource.DosageInstruction[0].Timing?.Repeat?.Bounds);
                        }
                        else
                        {
                            _logger.LogInformation("KelseyEHRWrapper.ProcessMedRequestData() No Dosage Instructions Bound value is returning as null for MedicationrequestID: {MedicationRequestId}", medRequestResource.Id);
                        }
                        if (bound.Contains(Constants.START))
                        {
                            var boundData = JsonSerializer.Deserialize<BoundModel>(bound, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
                            var startPeriod = _kelseyEHRUtils.ConvertToDatetime(boundData.Start);
                            Period boundModel = new Period();
                            boundModel.Start = startPeriod;
                            medRequestResource.DosageInstruction[0].Timing.Repeat.Bounds = boundModel; // TODO null check
                        }
                    }
                    else
                    {
                        _logger.LogInformation("KelseyEHRWrapper.ProcessMedRequestData() - No medRequestResource.DosageInstruction data to fetch Bounds for MedicationRequest ID: {MedicationRequestId}", medRequestResource.Id);
                    }
                    using (LogContext.PushProperty("MedicationRequestId", medRequestResource.Id))
                    {
                        tasks.Add(AddMedicationData(_ehrservice, medRequestResource));
                    }
                }
            }
            await System.Threading.Tasks.Task.WhenAll(tasks);
            _logger.LogInformation("KelseyEHRWrapper.ProcessMedRequestData() execution ended for Patient: {patientFhirId}", patientFhirId);
            return medRequestBundle;
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyEHRWrapper.ProcessMedRequestData() failed. Exception: {Error}", ex);
            throw;
        }
    }

    private async System.Threading.Tasks.Task AddMedicationData(IEHRService _ehrservice, MedicationRequest medRequestResource)
    {
        try
        {
            _logger.LogInformation("KelseyEHRWrapper.AddMedicationData() execution started");
            if (medRequestResource.Medication != null)
            {
                var med = _fhirJsonSerializer.SerializeToString(medRequestResource.Medication);
                if (!string.IsNullOrEmpty(med))
                {
                    var medicationReference = JsonSerializer.Deserialize<ReferenceModel>(med, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
                    if (!string.IsNullOrEmpty(medicationReference.Reference))
                    {
                        //var medication = await _ehrservice.GetMedication(medicationReference.Reference);
                        var medication = await _ehrservice.GetPatientData("", medicationReference.Reference, EhrFetchType.ById);
                        if (!string.IsNullOrEmpty(medication) && !medication.Contains(Constants.OPERATIONOUTCOME))
                        {
                            var medicationFhirData = _fhirJsonParser.Parse<Medication>(medication);
                            medRequestResource.Identifier.AddRange(medicationFhirData.Identifier); // add identifier data of medication to medrequest
                            _kelseyEHRUtils.AddMedicationtoMedrequest(medRequestResource, medicationFhirData);
                        }
                        else
                        {
                            _logger.LogInformation("KelseyEHRWrapper.AddMedicationData() No Medication data returned");
                            throw new Exception("No Medication data returned for MedicationRequest ID: " + medRequestResource.Id);
                        }
                    }
                    else
                    {
                        _logger.LogInformation("KelseyEHRWrapper.AddMedicationData() No medicationReference.Reference data");
                    }
                }
                else
                {
                    _logger.LogInformation("KelseyEHRWrapper.AddMedicationData() No med Reference data");
                }
            }
            else
            {
                _logger.LogInformation("KelseyEHRWrapper.AddMedicationData() No medRequestResource.Medication data");
            }
            _logger.LogInformation("KelseyEHRWrapper.AddMedicationData() execution ended");
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyEHRWrapper.AddMedicationData() failed. Exception: {Error}", ex);
            throw;
        }
    }

    private async Task<Bundle> ProcessLocationDataAsync(IEHRService _ehrservice, string patientFhirId, FhirJsonParser parser, FhirData fhirData)
    {
        _logger.LogInformation("KelseyEHRWrapper.ProcessLocationDataAsync() execution started for PatientID: {patientFhirId}", patientFhirId);

        var stopwatch = new Stopwatch();

        var locationBundle = new Bundle();

        stopwatch.Start();
        try
        {
            var encounterResourceList = fhirData.Encounter.Entry
                .Where(entry => entry.Resource is Encounter)
                .Select(entry => entry.Resource as Encounter)
                .Where(entry => entry.Location != null && entry.Location.Any())
                .ToList();

            ConcurrentDictionary<int, string> TaskList = new ConcurrentDictionary<int, string>();

            using (var resource = new SemaphoreSlim(_config.GetValue<int>("EpicResourceProcessChunkLimit")))
            {
                var tasks = encounterResourceList.Select(async encounterResource =>
                {
                    await resource.WaitAsync();
                    try
                    {
                        var task = await ProcessLocationData(_ehrservice, patientFhirId, encounterResource);
                        var index = encounterResourceList.IndexOf(encounterResource);
                        TaskList[index] = (!string.IsNullOrEmpty(task) && !task.Contains(Constants.OPERATIONOUTCOME)) ? task : null;
                    }
                    finally
                    {
                        resource.Release();
                    }
                });
                await System.Threading.Tasks.Task.WhenAll(tasks);
            }

            _logger.LogInformation("KelseyEHRWrapper.ProcessLocationDataAsync() network call takes time : {stopwatch}", stopwatch.ElapsedMilliseconds / 1000);

            foreach (var encounterResource in encounterResourceList)
            {
                var index = encounterResourceList.IndexOf(encounterResource);
                var task = TaskList[index];

                var loc = _fhirJsonSerializer.SerializeToString(encounterResource.Location[0].Location);
                var locationReference = JsonSerializer.Deserialize<ReferenceModel>(loc, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });

                if (!string.IsNullOrEmpty(task) && !task.Contains(Constants.OPERATIONOUTCOME))
                {
                    _logger.LogInformation("KelseyEHRWrapper.ProcessLocationDataAsync().ProcessLocationData() adding resource entry to location bundle");
                    var location = parser.Parse<Location>(task);
                    locationBundle.AddResourceEntry(location, _config.GetValue<string>("PimFhirServerUrl") + "/" + locationReference.Reference);
                    encounterResource.Extension = location.Extension;

                    foreach (var ext in location.Extension)
                    {
                        try
                        {
                            CodeableConcept codeableConcept = (CodeableConcept)ext.Value;
                            encounterResource.ServiceType = codeableConcept;
                        }
                        catch (Exception e)
                        {
                            _logger.LogError("KelseyEHRWrapper:ProcessLocationDataAsync : Error to get location codeableconcept : {Error}", e.Message);
                        }
                    }
                }
                else
                {
                    _logger.LogInformation("KelseyEHRWrapper:ProcessLocationDataAsync.ProcessLocationData() :No location data found for Encounter ID : {Id}", encounterResource.Id);
                }
            }

            stopwatch.Stop();

            _logger.LogInformation("KelseyEHRWrapper.ProcessLocationDataAsync() call takes time to complete: {stopwatch}", stopwatch.ElapsedMilliseconds / 1000);
            _logger.LogInformation("KelseyEHRWrapper.ProcessLocationDataAsync() execution ended for PatientID: {patientFhirId}", patientFhirId);
            stopwatch.Reset();
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyEHRWrapper:ProcessLocationDataAsync : Error : {Error}", ex);
            throw;
        }
        return locationBundle;
    }

    private async Task<string> ProcessLocationData(IEHRService _ehrservice, string patientFhirId, Encounter encounterResource)
    {
        string task;

        var loc = _fhirJsonSerializer.SerializeToString(encounterResource.Location[0].Location);
        var locationReference = JsonSerializer.Deserialize<ReferenceModel>(loc, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });

        if (!string.IsNullOrEmpty(locationReference.Reference))
        {
            _logger.LogInformation("KelseyEHRWrapper.ProcessLocationDataAsync().ProcessLocationData() fetching location for Location reference : {Reference}", locationReference.Reference);
            task = await _ehrservice.GetPatientData(patientFhirId, locationReference.Reference, EhrFetchType.ByPatient);
        }
        else
        {
            _logger.LogError("KelseyEHRWrapper.ProcessServiceRequestDataAsync().ProcessServiceRequest(): Location Data Reference is empty");
            throw new Exception("Location Data Reference is empty");
        }
        return task;
    }

    private async Task<Bundle> ProcessServiceRequestDataAsync(IEHRService _ehrservice, string patientFhirId, FhirJsonParser parser, FhirData fhirData)
    {
        _logger.LogInformation("KelseyEHRWrapper.ProcessServiceRequestDataAsync() execution started for PatientID: {PatientFhirId}", patientFhirId);
        var serviceRequestBundle = new Bundle();
        var stopwatch = new Stopwatch();
        stopwatch.Start();
        try
        {

            var observationResourceList = fhirData.Observation.Entry
               .Where(entry => entry.Resource is Observation observationResource)
               .Select(entry => entry.Resource as Observation)
               .Where(resource => resource?.BasedOn.Count > 0)
               .ToList();

            ConcurrentDictionary<int, string> TaskList = new ConcurrentDictionary<int, string>();

            using (var resource = new SemaphoreSlim(_config.GetValue<int>("EpicResourceProcessChunkLimit")))
            {
                var tasks = observationResourceList.Select(async observationResource =>
                {
                    await resource.WaitAsync();
                    try
                    {
                        var task = await ProcessServiceRequest(_ehrservice, patientFhirId, observationResource);
                        var index = observationResourceList.IndexOf(observationResource);
                        TaskList[index] = (!string.IsNullOrEmpty(task) && !task.Contains(Constants.OPERATIONOUTCOME)) ? task : null;
                    }
                    finally
                    {
                        resource.Release();
                    }
                });

                await System.Threading.Tasks.Task.WhenAll(tasks);
            }

            _logger.LogInformation("KelseyEHRWrapper.ProcessServiceRequestDataAsync() network call takes time : {stopwatch}", stopwatch.ElapsedMilliseconds / 1000);


            foreach (var observationResource in observationResourceList)
            {
                var index = observationResourceList.IndexOf(observationResource);
                var task = TaskList[index];

                var serviceRequestReference = observationResource.BasedOn[0].Reference;
                if (!string.IsNullOrEmpty(serviceRequestReference))
                {
                    if (!string.IsNullOrEmpty(task) && !task.Contains(Constants.OPERATIONOUTCOME))
                    {
                        _logger.LogInformation("KelseyEHRWrapper.ProcessServiceRequestDataAsync() adding resource entry to service request bundle");
                        var serviceRequest = parser.Parse<ServiceRequest>(task);
                        serviceRequestBundle.AddResourceEntry(serviceRequest, _config.GetValue<string>("PimFhirServerUrl") + "/" + serviceRequestReference);
                    }
                    else
                    {
                        _logger.LogInformation("KelseyEHRWrapper.ProcessServiceRequestDataAsync() No serviceRequest resource data returned for Observation ID: {ObservationId}", observationResource.Id);
                        throw new Exception("No serviceRequest resource data returned for Observation ID: " + observationResource.Id + "and PatientID: " + patientFhirId);
                    }
                }
                else
                {
                    _logger.LogInformation("KelseyEHRWrapper.ProcessServiceRequestDataAsync() No serviceRequestReference data found in Observarion resource for Observation ID: {ObservationId}", observationResource.Id);
                }
            }

            stopwatch.Stop();

            _logger.LogInformation("KelseyEHRWrapper.ProcessServiceRequestDataAsync() call takes time to complete: {stopwatch}", stopwatch.ElapsedMilliseconds / 1000);
            _logger.LogInformation("KelseyEHRWrapper.ProcessServiceRequestDataAsync() execution ended for PatientID: {patientFhirId}", patientFhirId);
            stopwatch.Reset();

            _logger.LogInformation("KelseyEHRWrapper.ProcessServiceRequestDataAsync() execution ended for PatientID: {PatientFhirId}", patientFhirId);
            return serviceRequestBundle;
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyEHRWrapper:ProcessServiceRequestDataAsync : Error : {Error}", ex);
            throw;
        }
    }

    private async Task<string> ProcessServiceRequest(IEHRService _ehrservice, string patientFhirId, Observation observationResource)
    {
        var serviceRequestReference = observationResource.BasedOn[0].Reference;

        string task;
        if (!string.IsNullOrEmpty(serviceRequestReference))
        {
            _logger.LogInformation("KelseyEHRWrapper.ProcessServiceRequestDataAsync().ProcessServiceRequest() fetching location for service request reference : {Reference}", serviceRequestReference);
            task = await _ehrservice.GetPatientData(patientFhirId, serviceRequestReference, EhrFetchType.ByPatient);
        }
        else
        {
            _logger.LogError("KelseyEHRWrapper.ProcessServiceRequestDataAsync().ProcessServiceRequest(): Service Req Reference is empty");
            throw new Exception("Service Request Reference is empty");
        }
        return task;
    }

    public async Task<Bundle> GetPatientRawDataByResource(string patientFhirId, string resourceType)
    {
        using (LogContext.PushProperty("PatientFhirId", patientFhirId))
        {
            try
            {
                _logger.LogInformation("KelseyEHRWrapper.GetPatientRawData() execution started ");
                var _ehrservice = _eHRFactory.GetEHRService(Constants.EPIC, false);

                var fhirData = new Bundle();
                var rawResourceData = await _ehrservice.GetPatientData(patientFhirId, resourceType, EhrFetchType.ByPatient);

                if (!string.IsNullOrEmpty(rawResourceData))
                {
                    fhirData = _fhirJsonParser.Parse<Bundle>(rawResourceData);
                }
                else
                {
                    _logger.LogInformation("KelseyEHRWrapper.GetPatientRawData() - No resource data for Patient: {PatientFhirId}", patientFhirId);
                }

                _logger.LogInformation("KelseyEHRWrapper.GetPatientRawData() execution ended ");

                return fhirData;
            }
            catch (Exception ex)
            {
                _logger.LogError("KelseyEHRWrapper.GetPatientRawData() failed. Exception: {Error}", ex);
                throw;
            }
        }
    }

    //For generating Mock data from Epic
    //private void WritePatientData(string patient, string encounter, string appointment, string condition, string diagReport, string medRequest, string observation, string allergyIntolerance, string patientId, FhirData fhirData, IEHRService _ehrservice)
    //{
    //    try
    //    {
    //        string globalPath = @"/Users/ugandla/Documents/Ehr-mockdata/Kelsey/";

    //        System.IO.Directory.CreateDirectory(globalPath + patientId);

    //        //Adding Medication Resources
    //        if (!Directory.Exists(globalPath + "/Medication"))
    //        {
    //            System.IO.Directory.CreateDirectory(globalPath + "/Medication");
    //        }
    //            Bundle actualMedRequest = _fhirJsonParser.Parse<Bundle>(medRequest);
    //        foreach (var entry in actualMedRequest.Entry)
    //        {
    //            if (entry.Resource is MedicationRequest medRequestResource)
    //            {
    //                //medRequestResource.AuthoredOn = "2023-11-01";     ¸ÅModel>(med, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });

    //                var med = _fhirJsonSerializer.SerializeToString(medRequestResource.Medication);
    //                if (!string.IsNullOrEmpty(med))
    //                {
    //                    var medicationReference = JsonSerializer.Deserialize<ReferenceModel>(med, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
    //                    if (!string.IsNullOrEmpty(medicationReference.Reference))
    //                    {
    //                        var medication =  _ehrservice.GetEpicResourceById("", medicationReference.Reference);
    //                        if (!string.IsNullOrEmpty(medication.Result))
    //                        {
    //                            System.IO.File.WriteAllText(globalPath + medicationReference.Reference + ".json", medication.Result);
    //                        }
    //                    }
    //                }
    //            }
    //        }

    //        var serializer = new FhirJsonSerializer();
    //        var actualMedRequestString = serializer.SerializeToString(actualMedRequest);

    //        //Adding Location Resources
    //        if (!Directory.Exists(globalPath + "/Location"))
    //        {
    //            System.IO.Directory.CreateDirectory(globalPath + "/Location");
    //        }
    //        foreach (var entry in fhirData.Encounter.Entry)
    //        {
    //            if (entry.Resource is Hl7.Fhir.Model.Encounter encounterResource)
    //            {
    //                if (encounterResource?.Location.Count > 0)
    //                {
    //                    var loc = _fhirJsonSerializer.SerializeToString(encounterResource.Location[0].Location);
    //                    var locationReference = JsonSerializer.Deserialize<ReferenceModel>(loc, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
    //                    if (!string.IsNullOrEmpty(locationReference.Reference))
    //                    {
    //                        var location =  _ehrservice.GetEpicResourceByPatient(patientId, locationReference.Reference);
    //                        if (!string.IsNullOrEmpty(location.Result) && !location.Result.Contains(Constants.OPERATIONOUTCOME))
    //                        {
    //                            System.IO.File.WriteAllText(globalPath + locationReference.Reference + ".json", location.Result);
    //                        }
    //                    }
    //                }
    //            }
    //        }

    //        //Adding ServiceRequest Resources
    //        System.IO.Directory.CreateDirectory(globalPath + patientId + "/ServiceRequest");
    //        foreach (var entry in fhirData.Observation.Entry)
    //        {
    //            if (entry.Resource is Observation observationResource)
    //            {
    //                if (observationResource?.BasedOn.Count > 0)
    //                {
    //                    var serviceRequestReference = observationResource.BasedOn[0].Reference;
    //                    if (!string.IsNullOrEmpty(serviceRequestReference))
    //                    {
    //                        var serviceRequestResource = _ehrservice.GetEpicResourceByPatient(patientId, serviceRequestReference);
    //                        if (!string.IsNullOrEmpty(serviceRequestResource.Result) && !serviceRequestResource.Result.Contains(Constants.OPERATIONOUTCOME))
    //                        {
    //                            System.IO.File.WriteAllText(globalPath + patientId + "/" + serviceRequestReference + ".json", serviceRequestResource.Result);
    //                        }
    //                    }
    //                }
    //            }
    //        }

    //        System.IO.File.WriteAllText(globalPath + patientId + "/patient.json", patient);
    //        System.IO.File.WriteAllText(globalPath + patientId + "/encounter.json", encounter);
    //        System.IO.File.WriteAllText(globalPath + patientId + "/appointment.json", appointment);
    //        System.IO.File.WriteAllText(globalPath + patientId + "/condition.json", condition);
    //        System.IO.File.WriteAllText(globalPath + patientId + "/diagnosticreport.json", diagReport);
    //        System.IO.File.WriteAllText(globalPath + patientId + "/medicationrequest.json", actualMedRequestString);
    //        System.IO.File.WriteAllText(globalPath + patientId + "/observation.json", observation);
    //        System.IO.File.WriteAllText(globalPath + patientId + "/allergyintolerance.json", allergyIntolerance);
    //    }
    //    catch (Exception ex)
    //    {
    //        throw;
    //    }
    //}
}