﻿using System;
using System.Collections.Generic;
using CDOIntegrationService.Refactor.Models;
using FhirServiceLibrary;

namespace CDOIntegrationService.Refactor
{
	public class FhirUtils
	{
		public List<FhirCrudIdentifier> CreateIdentifier(PatientRequestModel req)
		{
            return new List<FhirCrudIdentifier>()
            {
                new FhirCrudIdentifier()
                {
                    Name=Constants.EOW,
                    Value=req.Identifiers.EOW
                },
                new FhirCrudIdentifier()
                {
                    Name=Constants.CDO,
                    Value=req.Identifiers.CDOID
                },
                new FhirCrudIdentifier()
                {
                    Name=Constants.ENV,
                    Value=Environment.GetEnvironmentVariable("CurrentEnvironment")
                },
                new FhirCrudIdentifier()
                {
                    Name=Constants.ASSIGNING_AUTHORITY,
                    Value=req.Identifiers.AssigningAuthority
                }
            };

        }
	}
}

