using System.Threading.Tasks;

namespace CDOIntegrationService.Refactor.Authentication;

public interface IAuthentication
{
    Task<string> GetToken();
    void RefreshToken();  
}