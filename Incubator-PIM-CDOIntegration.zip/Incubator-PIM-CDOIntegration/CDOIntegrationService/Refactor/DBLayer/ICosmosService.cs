﻿using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.Azure.Cosmos;
using CDOIntegrationService.Refactor.Models;
using Incubator_OIA_CommonModels;
using System;
using static Incubator_OIA_CommonModels.CosmosModel;

namespace CDOIntegrationService.Refactor.DBLayer
{
    public interface ICosmosService
    {
        Container GetContainer(string containerName, string dbName);
        Task<ItemResponse<T>> UpdateAsync<T>(Container container, T data, string partitionKey);
        Task<CosmosData> FetchCosmosRecordByQueryParams(string id, string cdoName);
        Task<List<CosmosData>> FetchCosmosRecordWithPendedMedicationRequest(int batchSize, List<string> activeProviderList, bool updateForActiveProvider);
        Task<List<string>> FetchActiveProviders();
        Task<UpsertAsyncResponseModel> UpdateMedicationRequestStatusForRecord(CosmosModel.CosmosData cosmosRecord, string partitionKey);
        Task<TransactionEOW> GetLastProcessedTime(string cdoName);
        Task AddMessagesToCosmos(OutputMessageCollection outputMessageCollection);
        Task UpdateMaxDateTime(string maxDateString, TransactionEOW lastProcRecord);
    }
}