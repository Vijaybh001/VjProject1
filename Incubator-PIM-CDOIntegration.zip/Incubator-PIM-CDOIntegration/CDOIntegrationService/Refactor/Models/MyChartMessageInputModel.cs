﻿using System;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Abstractions;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Resolvers;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace CDOIntegrationService.Refactor.Models
{
    [OpenApiExample(typeof(MyChartMessageInputModelExample))]
    public class MyChartMessageInputModel
	{
        [OpenApiProperty]
        [JsonProperty("csn")]
        public string Csn { get; set; }

        [OpenApiProperty]
        [JsonProperty("msgbody")]
        public string Msgbody { get; set; }

        [OpenApiProperty]
        [JsonProperty("subject")]
        public string Subject { get; set; }
    }

    public class MyChartMessageInputModelExample : OpenApiExample<MyChartMessageInputModel>
    {
        public override IOpenApiExample<MyChartMessageInputModel> Build(NamingStrategy namingStrategy = null)
        {
            this.Examples.Add(
                 OpenApiExampleResolver.Resolve(
                     "MyChartMessageInputModelExample",
                     new MyChartMessageInputModel()
                     {
                         Csn = "",
                         Msgbody = "",
                         Subject = ""
                     },
                     namingStrategy
                 ));
            return this;
        }
    }
}

