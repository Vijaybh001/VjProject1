﻿using System;
using CDOIntegrationService.Refactor.Models;
using FluentValidation;

namespace CDOIntegrationService.Validation
{
	public class FlexRequestValidator: AbstractValidator<FlexRequestBody>
	{
		public FlexRequestValidator()
		{
			RuleFor(x => x.PatientFhirId).NotEmpty().WithMessage("PatientFhirId cannot be empty");
            RuleFor(x => x.ActiveMedRequestID).NotEmpty().WithMessage("ActiveMedRequestID cannot be empty");
            RuleFor(x => x.CDOName).NotEmpty().WithMessage("CDOName cannot be empty");
            RuleFor(x => x.MsgSubmittedInstant).NotEmpty().WithMessage("MsgSubmittedInstant cannot be empty");
            RuleFor(x => x.PendedOrderId).NotEmpty().WithMessage("PendedOrderId cannot be empty");
            RuleFor(x => x.OrderEncounterCSN).NotEmpty().WithMessage("OrderEncounterCSN cannot be empty");
            RuleFor(x => x.RxNormCode).NotEmpty().WithMessage("RxNormCode cannot be empty");
            RuleFor(x => x.PendAuthProvider).NotEmpty().WithMessage("PendAuthProvider cannot be empty");
            RuleFor(x => x.PendAuthProvider).SetValidator(new PendAuthProviderValidator());
        }
	}
}