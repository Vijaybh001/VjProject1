﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using CDOIntegrationService.Refactor.MessageService.Kelsey;

namespace CDOIntegrationService.Triggers
{
    public class KelseyMessageCollectionHttp
    {
        private readonly IKelseyMessageCollection _kelseyMessageCollection;
        private readonly ILogger<KelseyMessageCollectionHttp> _logger;

        public KelseyMessageCollectionHttp(ILogger<KelseyMessageCollectionHttp> log, IKelseyMessageCollection kelseyMessageCollection)
        {
            _kelseyMessageCollection = kelseyMessageCollection;
            _logger = log;
        }
        [FunctionName("KelseyMessageCollectionHttp")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req, ILogger log)
        {
            try
            {
                _logger.LogInformation("MessageCollectionHttp started ");

                var outputMessageCollection= await _kelseyMessageCollection.RunMessageCollection();

                _logger.LogInformation("MessageCollectionHttp ended");

                return new OkObjectResult(outputMessageCollection);
            }

            catch (Exception ex)
            {
                _logger.LogError("MessageCollectionHttp failed. {Error}", ex);
                throw;
            }
        }
    }
}

