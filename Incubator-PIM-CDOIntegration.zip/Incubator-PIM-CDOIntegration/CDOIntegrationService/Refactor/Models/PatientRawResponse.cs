﻿using System;
using Hl7.Fhir.Model;
using Incubator_OIA_CommonModels;

namespace CDOIntegrationService.Refactor.Models
{
	public class PatientRawResponse: ResponseModel
	{
		public Bundle FhirBundle { get; set; }
	}
}

