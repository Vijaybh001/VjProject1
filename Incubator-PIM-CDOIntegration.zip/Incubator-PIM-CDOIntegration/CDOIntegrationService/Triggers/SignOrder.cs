//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.Azure.WebJobs;
//using Microsoft.Azure.WebJobs.Extensions.Http;
//using Microsoft.Extensions.Logging;
//using CDOIntegrationService.Refactor.Models;
//using FluentValidation;
//using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
//using System;
//using System.Net;
//using Serilog.Context;
//using Incubator_OIA_CommonModels;

//namespace CDOIntegrationService.Triggers
//    public class SignOrder
//{
//    private readonly ICdoServiceFactory _cdoFactory;
//    private readonly ILogger<SignOrder> _logger;
//    private readonly IValidator<FlexRequestBody> _validator;
//    public SignOrder(ILogger<SignOrder> log, ICdoServiceFactory cdoFactory, IValidator<FlexRequestBody> validator)
//    {
//        _cdoFactory = cdoFactory;
//        _logger = log;
//        _validator = validator;
//    }
//    [HttpPost]
//    [FunctionName("SignOrder")]
//    [OpenApiOperation(operationId: "SignOrder", tags: new[] { "SignOrder" })]
//    [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(FlexRequestBody), Deprecated = false, Description = "FlexRequestBody", Required = true)]
//    [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string))]
//    public async Task<IActionResult> signOrder(
//        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] FlexRequestBody req)
//    {
//        using (LogContext.PushProperty("PendedOrderID", req.PendedOrderId))
//        using (LogContext.PushProperty("PatientFhirId", req.PatientFhirId))
//        {
//            try
//            {
//                _logger.LogInformation("SignOrder() execution started ");
//                _validator.ValidateAndThrow(req);
//                var cdoService = _cdoFactory.GetCdoService(req.CDOName);
//                var data = await cdoService.SignOrder(req);
//                _logger.LogInformation("SignOrder() execution ended ");
//                return new OkObjectResult(new SignOrderResponse()
//                {
//                    StatusCode = 1,
//                    PendedMedRequestID = data
//                });
//            }
//            catch (ValidationException ex)
//            {
//                _logger.LogError("SignOrder.signOrder() failed. Exception: {Error}", ex);
//                return new BadRequestObjectResult(new ResponseModel()
//                {
//                    StatusCode = 0,
//                    ErrorMessage = $"SignOrder.signOrder() failed. Exception: {ex.Message}"
//                });
//            }
//            catch (Exception ex)
//            {
//                var obj = new ResponseModel()
//                {
//                    StatusCode = 0,
//                    ErrorMessage = $"SignOrder.signOrder() failed. Exception: {ex.Message}"
//                };
//                var result = new OkObjectResult(obj)
//                {
//                    StatusCode = (int)HttpStatusCode.InternalServerError
//                };
//                _logger.LogError("SignOrder.signOrder() failed. Exception: {Error}", ex);
//                return result;
//            }
//        }

//    }
//}
//}

