﻿using System;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.Authentication;
using CDOIntegrationService.Refactor.EHRService.Kelsey;
using CDOIntegrationService.Refactor.Models;
using AzureFhirFramework.RestClientWrapper;
using AzureFhirFramework.RestClientWrapper.RestPolicy;
using Hl7.Fhir.Model;
using Hl7.Fhir.Serialization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using RestSharp;

namespace CDOIntegrationService.Refactor.Flex
{
    public class FlexService: IFlexService
	{
        private readonly IAuthentication _authService;
        private readonly IConfiguration _configuration;
        private readonly ILogger<FlexService> _logger;
        private readonly IRestClientWrapper _restService;
        private readonly IFhirCrudService _fhirCrudService;
        private readonly IEHRService _ehrService;

        public FlexService(IAuthFactory authFactory, IConfiguration configuration, ILogger<FlexService> logger, IRestClientWrapper restClientWrapper, IFhirCrudService fhirCrudService, IEHRFactory eHRFactory)
        {
            _authService = authFactory.GetAuthService(Constants.FLEX);
            _logger = logger;
            _configuration = configuration;
            _restService = restClientWrapper;
            _fhirCrudService = fhirCrudService;
            _ehrService = eHRFactory.GetEHRService(Constants.EPIC, false);
        }

        public async Task<string> SignOrder(FlexRequestBody flexRequestBody)
        {
            try
            {
                _logger.LogInformation("FlexService.SignOrder() execution started ");
                var url = $"{_configuration.GetValue<string>("FlexBaseURL")}/fhir/R4/MedicationRequest";
                var token = await _authService.GetToken(); 

                var pendedMedRequest = await CreatePendedMedRequest(flexRequestBody);

                var request = new RestRequest(url, Method.Post);
                request.AddHeader("Authorization", $"Bearer {token}");
                request.AddHeader("claim", "user/MedicationRequest.create");
                var serializer = new FhirJsonSerializer();
                // Console.WriteLine(serializer.SerializeToString(pendedMedRequest));
                request.AddJsonBody(serializer.SerializeToString(pendedMedRequest));

                var response = await _restService.ExecuteRequest(request, "FlexSignOrder");
                if (!response.IsSuccessful)
                    throw new Exception(response.Content);
                _logger.LogInformation("FlexService.SignOrder() execution ended ");
                return pendedMedRequest.Id;
            }
            catch(Exception ex)
            {
                _logger.LogError("FlexService.SignOrder() failed. Exception: {Error}", ex);
                throw;
            }
        }

        private async Task<MedicationRequest> CreatePendedMedRequest(FlexRequestBody flexRequestBody)
        {
            try
            {
                _logger.LogInformation("FlexService.CreatePendedMedRequest() execution started ");
                var medicationRequestTask = _fhirCrudService.GetResourceById(flexRequestBody.ActiveMedRequestID, Constants.MEDICATIONREQUEST);
                var patientTask = _fhirCrudService.GetResourceById(flexRequestBody.PatientFhirId, Constants.PATIENT);
                var practitionerTask = _ehrService.GetPatientData(flexRequestBody.PendAuthProvider.ProviderFhirIdEMP, Constants.PRACTITIONER, EhrFetchType.ById);

                var parser = new FhirJsonParser();

                await System.Threading.Tasks.Task.WhenAll(medicationRequestTask, patientTask, practitionerTask);

                var medicationRequestBundle = medicationRequestTask.Result;
                var patientBundle = patientTask.Result;
                var practitionerBundle = practitionerTask.Result;

                if (medicationRequestBundle == null || medicationRequestBundle.Entry == null || !medicationRequestBundle.Entry.Any())
                {
                    _logger.LogInformation($"FlexService.CreatePendedMedRequest() execution started - {DateTime.UtcNow}");
                    throw new Exception($"No MedicationRequest data present for id {flexRequestBody.ActiveMedRequestID}");
                }

                if (patientBundle == null || patientBundle.Entry == null || !patientBundle.Entry.Any())
                {
                    _logger.LogInformation($"FlexService.CreatePendedMedRequest() execution started - {System.DateTime.UtcNow}");
                    throw new Exception($"No Patient data present for id {flexRequestBody.PatientFhirId}");
                }

                if (string.IsNullOrEmpty(practitionerBundle))
                {
                    _logger.LogInformation($"FlexService.CreatePendedMedRequest() execution started - {System.DateTime.UtcNow}");
                    throw new Exception($"No PractitionerBundle data present for id {flexRequestBody.PendAuthProvider.ProviderFhirId}");
                }

                var practitionerData = parser.Parse<Practitioner>(practitionerTask.Result);

                var activeMedResource = medicationRequestBundle.Entry.FirstOrDefault();
                var patientResource = patientBundle.Entry.FirstOrDefault();

                if(patientResource == null)
                {
                    _logger.LogInformation($"FlexService.CreatePendedMedRequest() execution started - {System.DateTime.UtcNow}");
                    throw new Exception($"No Patient data present for id {flexRequestBody.PatientFhirId}");
                }

                if(activeMedResource == null)
                {
                    _logger.LogInformation($"FlexService.CreatePendedMedRequest() execution started - {DateTime.UtcNow}");
                    throw new Exception($"No MedicationRequest data present for id {flexRequestBody.ActiveMedRequestID}");
                }

                var patientData = patientResource!.Resource as Patient;
                var activeMedRequest = activeMedResource!.Resource as MedicationRequest;

                patientData.Identifier?.Add(new()
                {
                    Use = Identifier.IdentifierUse.Usual,
                    Type = new()
                    {
                        Coding = new()
                        {
                            new Coding()
                            {
                                System = "http://terminology.hl7.org/CodeSystem/v2-0203",
                                Code = "MRN",
                                Display = "PID code"
                            }
                        }
                    },
                    Value = flexRequestBody.PatientMRN
                }) ;

                var activeEncounter = activeMedRequest.Encounter;
                if (activeEncounter != null)
                {
                    activeEncounter.Identifier = new()
                    {
                        Use = Identifier.IdentifierUse.Usual,
                        System = _configuration.GetValue<string>("FlexEncounterSystem"),
                        Value = flexRequestBody.OrderEncounterCSN
                    };
                }

                var activeMedication = activeMedRequest.Medication as CodeableConcept;
                if (activeMedication != null)
                {
                    activeMedication.Coding = new()
                    {
                        new()
                        {
                            System=_configuration.GetValue<string>("FlexRxNormSystem"),
                            Code=flexRequestBody.RxNormCode
                        }
                    };
                }

                string authoredOn = "";
                try
                {
                     authoredOn = DateTime.Parse(flexRequestBody.MsgSubmittedInstant, new CultureInfo(Constants.CULTUREINFO, true)).ToString(Constants.FLEXDATEFORMAT);
                }
                catch (Exception ex)
                {
                    _logger.LogError("FlexService.CreatePendedMedRequest() Error with parsing authoredOn date: {Error}", ex.Message);
                    authoredOn = flexRequestBody.MsgSubmittedInstant;
                }

                var pendedMedRequest = new MedicationRequest()
                {
                    Id = Guid.NewGuid().ToString(),
                    Identifier = new()
                    {
                        new()
                        {
                            Type = new()
                            {
                                Coding = new()
                                {
                                    new Coding()
                                    {
                                        System = _configuration.GetValue<string>("PendedSystem")
                                    }
                                }
                            },
                            Value = flexRequestBody.PendedOrderId
                        }
                    },
                    
                    Status = MedicationRequest.MedicationrequestStatus.Draft,
                    Intent = MedicationRequest.MedicationRequestIntent.Order,
                    Subject = new ResourceReference($"#{flexRequestBody.PatientFhirId}"),
                    Medication = activeMedication,
                    Encounter = activeEncounter,
                    AuthoredOn = authoredOn,
                    Contained = new()
                    {
                        patientData,
                        practitionerData
                    },
                    Requester = new(flexRequestBody.PendAuthProvider.ProviderId, flexRequestBody.PendAuthProvider.ProviderName),
                    DosageInstruction = activeMedRequest.DosageInstruction,
                    DispenseRequest = new()
                    {
                        InitialFill = new()
                        {
                            Quantity = new()
                            {
                                Value = flexRequestBody.Quantity
                            }
                        },
                        NumberOfRepeatsAllowed = flexRequestBody.NoOfRepeats,
                        Quantity = new()
                        {
                            Value = flexRequestBody.Quantity
                        }
                    }
                };

                _logger.LogInformation("FlexService.CreatePendedMedRequest() execution ended ");
                return pendedMedRequest;
            }
            catch(Exception ex)
            {
                _logger.LogError("FlexService.CreatePendedMedRequest() failed. Exception: {Error}", ex);
                throw;
            }
        }
    }
}

