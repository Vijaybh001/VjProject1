using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.Authentication;
using CDOIntegrationService.Refactor.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace CDOIntegrationService;

public class AllscriptEhrService: IEHRService
{
    private IAuthentication _authenticationService;
    private readonly ILogger<AllscriptEhrService> _logger;
    private readonly IConfiguration _config;

    public AllscriptEhrService(IServiceProvider serviceProvider, IConfiguration configuration, ILogger<AllscriptEhrService> logger)
    {
        var services = serviceProvider.GetServices<IAuthentication>();
        _authenticationService = services.First(o => o.GetType() == typeof(AllscriptAuthentication));
        _logger = logger;
        _config = configuration;
    }

    Task<bool> IEHRService.GetEhrHealth()
    {
        throw new NotImplementedException();
    }

    public Task<string> GetPatientDataForMRUpdater(string patientFhirId, string resourceName)
    {
        throw new NotImplementedException();
    }

    public Task<string> GetPatientData(string patientFhirId, string resourceType, EhrFetchType ehrFetchType)
    {
        throw new NotImplementedException();
    }
}