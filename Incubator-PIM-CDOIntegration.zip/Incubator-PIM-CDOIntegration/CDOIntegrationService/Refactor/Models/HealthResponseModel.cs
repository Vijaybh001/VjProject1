﻿using System;
namespace CDOIntegrationService.Refactor.Models
{
	public class HealthResponseModel
	{
        public bool Status { get; set; }
        public string Message { get; set; }
    }
}

