﻿using System;
using static Incubator_OIA_CommonModels.CosmosModel;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.Models;

namespace CDOIntegrationService.Refactor.SignFinalOrder
{
	public interface ISignFinalOrder
	{
        Task<SignFinalOrderResponseModel> SignOrder(OutReachRequest req);

    }
}

