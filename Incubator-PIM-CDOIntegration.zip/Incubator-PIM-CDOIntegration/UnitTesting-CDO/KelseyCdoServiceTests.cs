﻿using CDOIntegrationService;
using Hl7.Fhir.Model;
using System.Text.Json;
using CDOIntegrationService.Refactor.Models;
using Hl7.Fhir.Serialization;
using Microsoft.Extensions.Logging;
using Moq;
using Microsoft.Extensions.Configuration;
using CDOIntegrationService.Refactor.MessageService;
using CDOIntegrationService.Refactor.DBLayer;
using CDOIntegrationService.Refactor.Flex;
using CDOIntegrationService.Refactor;
using CDOIntegrationService.Refactor.CDOService.Kelsey;
using CDOIntegrationService.Refactor.MyChartService;
using FluentAssertions;
using CDOIntegrationService.Refactor.ConfigService;

namespace UnitTesting_CDO
{
    public class KelseyCdoServiceTests
    {
        private readonly Mock<IFhirCrudService> _epicMock;
        private readonly KelseyCdoService _eHRWrapper;
        private readonly Mock<ICdoFactory> _authMock;
        private readonly Mock<IEHRWrapper> _ehrWrapper;
        private readonly IFhirWrapper _fhirWrapper;
        private readonly Mock<IMessageService> _messageService;
        private readonly Mock<ICosmosService> _cosmosService;
        private readonly Mock<IFlexService> _flexMock;
        private readonly Mock<ISendMyChartMessage> _myChartMock;
        private readonly Mock<FhirUtils> _fhirUtils;
        private readonly Mock<KelseyUtils> _kelseyUtils;
        private readonly Mock<IAzureConfig> _azureConfig;

        public KelseyCdoServiceTests()
        {
            _ehrWrapper = new Mock<IEHRWrapper>();
            _messageService = new Mock<IMessageService>();
            _epicMock = new Mock<IFhirCrudService>();
            _cosmosService = new Mock<ICosmosService>();
            _fhirUtils = new();
            _kelseyUtils = new();
            _fhirWrapper = new KelseyFhirWrapper(_epicMock.Object, new Mock<ILogger<KelseyFhirWrapper>>().Object, _fhirUtils.Object);
            _authMock = new();
            _flexMock = new();
            _azureConfig = new Mock<IAzureConfig>();
            _myChartMock = new Mock<ISendMyChartMessage>();
            _authMock.Setup(x => x.GetEhrWrapperService(It.IsAny<string>())).Returns(_ehrWrapper.Object);
            _authMock.Setup(x => x.GetFhirWrapperService(It.IsAny<string>())).Returns(_fhirWrapper);
            _authMock.Setup(x => x.GetMessageService(It.IsAny<string>(),It.IsAny<bool>())).Returns(_messageService.Object);
            _eHRWrapper = new KelseyCdoService(new Mock<IConfiguration>().Object, new Mock<ILogger<KelseyCdoService>>().Object, _authMock.Object, _cosmosService.Object, _flexMock.Object, _kelseyUtils.Object, _myChartMock.Object, _azureConfig.Object);
        }

        //TODO: Uncomment and fix UT
        [Fact]
        public async System.Threading.Tasks.Task KelseyEHR_GetPatientData_NotNull()
        {
            //Arrange
            var options = new JsonSerializerOptions().ForFhir(ModelInfo.ModelInspector);
            var bundleOutput = new Bundle();

            var patrequestModel = new PatientRequestModel();
            _epicMock.Setup(x => x.GetPatientEverythingDetails(patrequestModel)).ReturnsAsync(bundleOutput);

            //Act
            var response = await _eHRWrapper.GetPatientDetailsFromRaw(patrequestModel);

            Assert.NotNull(response);
        }
        //TODO: Uncomment and fix UT
        [Fact]
        public async System.Threading.Tasks.Task KelseyEHR_GetPatientData_ValidEHRName()
        {

            var text = File.ReadAllText("./MockData/PatientRawJson.json");
            var parser = new FhirJsonParser();
            var bundle = parser.Parse<Bundle>(text);
            //Arrange

            var patrequestModel = new PatientRequestModel() { PatientFhirId = "PIMS-Hypertension-Patient1" };
            _epicMock.Setup(x => x.GetPatientEverythingDetails(patrequestModel)).ReturnsAsync(bundle);

            //Act
            var response = await _eHRWrapper.GetPatientDetailsFromRaw(patrequestModel);

            Assert.Equal(response.PatientName, "Camila Maria Lopez");
        }

        [Fact]
        public async System.Threading.Tasks.Task KelseyEHR_GetMyChartResponse_SuccessResponse()
        {
            //Arrange
            var myChartInputReq = new MyChartMessageInputModel()
            {
                Csn = "6179",
                Msgbody = "This is a demo message",
                Subject = "Test Message"
            };

            var expectedResponse = new MyChartMessageOutputModel()
            {
                Mychartuserid = "82",
                Status = "success",
                Msgid = "503",
                Description = "no errors"
            };

            //Act
            _myChartMock.Setup(x => x.SendMessage(myChartInputReq)).ReturnsAsync(new MyChartMessageOutputModel() {
                Mychartuserid = "82",
                Status = "success",
                Msgid = "503",
                Description = "no errors"
            });

            var response = await _eHRWrapper.SendMyChartMessage(myChartInputReq);

            // Assert
            response.Should().BeEquivalentTo(expectedResponse);
        }

        [Fact]
        public async System.Threading.Tasks.Task KelseyEHR_GetMyChartResponse_FailureResponse()
        {
            //Arrange
            var myChartInputReq = new MyChartMessageInputModel()
            {
                Csn = "TestCsn",
                Msgbody = "This is a demo message",
                Subject = "Test Message"
            };

            var expectedResponse = new MyChartMessageOutputModel()
            {
                Mychartuserid = "User does not have an active MyChart account",
                Status = "failed",
                Msgid = "0",
                Description = "Patient does not have active MyKelseyOnline status."
            };

            //Act
            _myChartMock.Setup(x => x.SendMessage(myChartInputReq)).ReturnsAsync(new MyChartMessageOutputModel()
            {
                Mychartuserid = "User does not have an active MyChart account",
                Status = "failed",
                Msgid = "0",
                Description = "Patient does not have active MyKelseyOnline status."
            });

            var response = await _eHRWrapper.SendMyChartMessage(myChartInputReq);

            // Assert
            response.Should().BeEquivalentTo(expectedResponse);
        }
    }
}

