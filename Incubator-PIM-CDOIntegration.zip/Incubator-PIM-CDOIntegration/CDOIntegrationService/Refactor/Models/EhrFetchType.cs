﻿namespace CDOIntegrationService.Refactor.Models
{
    public enum EhrFetchType
    {
        ById,
        ByPatient
    }
}

