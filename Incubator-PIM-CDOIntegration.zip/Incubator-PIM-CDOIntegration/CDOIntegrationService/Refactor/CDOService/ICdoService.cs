using CDOIntegrationService.Refactor.Models;
using Hl7.Fhir.Model;
using System;
using System.Threading.Tasks;
using Incubator_OIA_CommonModels;
using Task = System.Threading.Tasks.Task;

namespace CDOIntegrationService
{
    public interface ICdoService
    {
        Task<CosmosModel.OutputMessageCollection> GetMessages(MessageCollectionRequest req);
        Task<MyChartMessageOutputModel> MkoMessages(MyChartMessageInputModel req);
        Task<bool> ProcessSchedulingTicket(SchedulingTicketRequestModel req);
        Task<Bundle> GetPatientRaw(PatientRequestModel req);
        Task<PimResource> GetPatientDetailsFromRaw(PatientRequestModel req);
        Task<bool> SetPatient(PatientRequestModel req);
        Task<bool> DeletePatient(PatientRequestModel req);
        Task GetMedicationRequestUpdaterService(bool updateForActiveProvider=false);
        Task<MRStatusResponseModel> CheckMedicationRequestStatusService(MedicationOrder req);
        void SendCdsHookA();
        Task<ReturnToProviderResponse> RecommendationMessages(RecommendationInputModel req);
        Task<string> SignOrder(FlexRequestBody flexRequestBody);
        Task<MyChartMessageOutputModel> SendMyChartMessage(MyChartMessageInputModel req);
        Task<SignFinalOrderResponseModel> SignFinalOrder(CosmosModel.OutReachRequest req);
        Task<Bundle> GetPatientRawResource(string patientFhirId, string resourceType);
    }
}