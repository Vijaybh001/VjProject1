﻿using System;
using CDOIntegrationService.Refactor.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net;
using System.Threading.Tasks;
using Azure;
using CDOIntegrationService.Refactor;
using FluentValidation;
using Serilog.Context;
using Incubator_OIA_CommonModels;
using CDOIntegrationService.Refactor.CustomException;

namespace CDOIntegrationService.Triggers
{
	public class GetPatientDetailsHttpTrigger
	{
        private readonly ICdoServiceFactory _cdoFactory;
        private readonly ILogger<GetPatientDetailsHttpTrigger> _logger;
        private readonly IValidator<PatientRequestModel> _validator;
        public GetPatientDetailsHttpTrigger(ILogger<GetPatientDetailsHttpTrigger> log, ICdoServiceFactory cdoFactory, IValidator<PatientRequestModel> validator)
        {
            _cdoFactory = cdoFactory;
            _logger = log;
            _validator = validator;

        }
        [HttpPost]
        [FunctionName("GetPatientDetails")]
        [OpenApiOperation(operationId: "GetPatientDetails", tags: new[] { "GetPatientDetails" })]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(PatientRequestModel), Deprecated = false, Description = "Request", Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(PimResource))]
        public async Task<IActionResult> GetPatientDetails(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] PatientRequestModel req,
            ILogger log)
        {
            
            using (LogContext.PushProperty("PendedOrderID", req.PatientFhirId))
            using (LogContext.PushProperty("EOWID", req.Identifiers.EOW))
            {
                try
                {
                    if (req == null)
                        throw new ValidationException("RequestBody cannot be empty");

                    await _validator.ValidateAndThrowAsync(req);
                    using (LogContext.PushProperty("PatientFhirId", req.PatientFhirId))
                    using (LogContext.PushProperty("CdoId", req.Identifiers.CDOID))
                    {
                        _logger.LogInformation("GetPatientDetails: execution started");
                        req.ResourceType = Constants.FHIR_PATIENT_DETAILS_RESOURCES;
                        var cdoService = _cdoFactory.GetCdoService(req.Identifiers.CDOID);
                        var response = await cdoService.GetPatientDetailsFromRaw(req);
                        _logger.LogInformation("GetPatientDetails: execution finished");
                        return new OkObjectResult(new GetPatientDetailsResponse()
                        {
                            APIStatusCode = new ResponseModel()
                            {
                                StatusCode = (int)HttpStatusCode.OK,
                            },
                            GetPatDetailsResponse = new GetPatDetailsResponse()
                            {
                                Response = response
                            }
                        })
                        {
                            StatusCode = (int)HttpStatusCode.OK
                        };
                    }
                }
                catch (ValidationException ex)
                {
                    _logger.LogError("GetPatientDetailsHttpTrigger.GetPatientDetails() failed. Exception: {Error}", ex);
                    return new BadRequestObjectResult(new ResponseModel()
                    {
                        StatusCode = (int)HttpStatusCode.BadRequest,
                        ErrorMessage = ex.Message
                    })
                    {
                        StatusCode = (int)HttpStatusCode.BadRequest
                    };
                }
                catch (ResponseCustomException ex)
                {
                    _logger.LogError("GetMessages.getMessages() failed. Exception: {Error}", ex);
                    return new BadRequestObjectResult(new GetPatientDetailsResponse()
                    {
                        APIStatusCode = new ResponseModel()
                        {
                            StatusCode = ex.CustomObject.StatusCode,
                            ErrorMessage = $"GetMessages.getMessages() failed. Exception: {ex.CustomObject.ErrorMessage}"
                        }
                    })
                    {
                        StatusCode = ex.CustomObject.StatusCode
                    };
                }
                catch (Exception ex)
                {
                    _logger.LogError("GetPatientDetailsHttpTrigger.GetPatientDetails() failed. Exception: {Error}", ex);
                    return new OkObjectResult(new ResponseModel()
                    {
                        StatusCode = (int)HttpStatusCode.InternalServerError,
                        ErrorMessage = ex.Message
                    })
                    {
                        StatusCode = (int)HttpStatusCode.InternalServerError
                    };
                }
            }
        }
    }
}
