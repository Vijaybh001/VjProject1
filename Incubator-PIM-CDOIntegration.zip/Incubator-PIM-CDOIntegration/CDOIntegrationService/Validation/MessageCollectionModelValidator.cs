﻿using FluentValidation;
using CDOIntegrationService.Refactor.Models;
using CDOIntegrationService.Refactor;
using System.Globalization;
using System;
using Incubator_OIA_CommonModels;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.IdentityModel.Tokens;
using static Incubator_OIA_CommonModels.CosmosModel;

namespace CDOIntegrationService.Validation
{
    public class InputMessageValidator : AbstractValidator<InputMessage>
    {
        public InputMessageValidator()
        {
            RuleFor(m => m.Status).NotEmpty().WithMessage("Status cannot be empty");
            RuleFor(m => m.Status).NotNull().WithMessage("Status cannot be null");
            RuleFor(m => m.Status).Must(status => status.Equals(Constants.INPUT_MESSAGE_STATUS_PEND) || status.Equals(Constants.INPUT_MESSAGE_STATUS_SENT)).WithMessage("Status must be either \"3 - Pend\" or \"2 - Sent\"");

            RuleFor(m => m.MessageSource).NotEmpty().WithMessage("MessageSource cannot be empty");
            RuleFor(m => m.MessageSource).NotNull().WithMessage("MessageSource cannot be null");

            RuleFor(m => m.MsgSubmittedInstant).NotEmpty().WithMessage("MsgSubmittedInstant cannot be empty");
            RuleFor(m => m.MsgSubmittedInstant).NotNull().WithMessage("MsgSubmittedInstant cannot be null");

            RuleFor(m => m.EOWID).NotEmpty().WithMessage("EOW cannot be empty");
            RuleFor(m => m.EOWID).NotNull().WithMessage("EOW cannot be null");

            RuleFor(m => m.MessageType).NotEmpty().WithMessage("MessageType cannot be empty");
            RuleFor(m => m.MessageType).NotNull().WithMessage("MessageType cannot be null");RuleFor(m => m.MessageType).Equal(Constants.INPUT_MESSAGE_TYPE).WithMessage("MessageType is not \"Rx Auth [32]\"");

            RuleFor(m => m.DefaultPool).NotEmpty().WithMessage("DefaultPool cannot be empty");
            RuleFor(m => m.DefaultPool).NotNull().WithMessage("DefaultPool cannot be null");

            RuleFor(m => m.PatientCommPref).NotEmpty().WithMessage("PatientCommPref cannot be empty");
            RuleFor(m => m.PatientCommPref).NotEmpty().WithMessage("PatientCommPref cannot be empty");

            RuleFor(m => m.Patient.PatientId).NotEmpty().WithMessage("Patient.PatientId cannot be empty");
            RuleFor(m => m.Patient.PatientId).NotNull().WithMessage("Patient.PatientId cannot be null");

            RuleFor(m => m.Patient.MRN).NotEmpty().WithMessage("Patient.MRN cannot be empty");
            RuleFor(m => m.Patient.MRN).NotNull().WithMessage("Patient.MRN cannot be null");

            RuleFor(m => m.Patient.FHIRID).NotEmpty().WithMessage("Patient.FHIRID cannot be empty");
            RuleFor(m => m.Patient.FHIRID).NotNull().WithMessage("Patient.FHIRID cannot be null");

            RuleFor(m => m.Patient.Name).NotEmpty().WithMessage("Patient.Name cannot be empty");
            RuleFor(m => m.Patient.Name).NotNull().WithMessage("Patient.Name cannot be null");

            RuleFor(m => m.PendedOrders).Must(m => m.Count>0).WithMessage("PendedOrder is empty");

            RuleFor(m => m.Patient)
                .SetValidator(new PatientDataValidator());
        }
    }

    class PatientDataValidator : AbstractValidator<CosmosModel.PatientData>
    {
        public PatientDataValidator()
        {
            RuleFor(p => p.PatientId).NotEmpty().WithMessage("PatientId cannot be empty");
            RuleFor(p => p.FHIRID).NotEmpty().WithMessage("PartientFhirID cannot be empty");
            RuleFor(p => p.Name).NotEmpty().WithMessage("PatientName cannot be empty");
        }
    }

    public class ActiveAuthProviderValidator : AbstractValidator<CosmosModel.ActiveAuthProvider>
    {
        public ActiveAuthProviderValidator()
        {
            RuleFor(a => a.ProviderId).NotEmpty().WithMessage("ActiveAuthProviderId cannot be empty");
            RuleFor(a => a.ProviderId).NotNull().WithMessage("ActiveAuthProviderId cannot be null");
            RuleFor(a => a.ProviderFhirIdEMP).NotEmpty().WithMessage("ActiveAuthProviderFhirIdEMP cannot be empty");
            RuleFor(a => a.ProviderFhirIdEMP).NotNull().WithMessage("ActiveAuthProviderFhirIdEMP cannot be null");
        }
    }

    public class PendAuthProviderValidator : AbstractValidator<PendAuthProvider>
    {
        public PendAuthProviderValidator()
        {
            RuleFor(p => p.ProviderId).NotEmpty().WithMessage("PendAuthProviderId cannot be empty");
            RuleFor(p => p.ProviderId).NotNull().WithMessage("PendAuthProviderId cannot be null");

            RuleFor(p => p.ProviderName).NotEmpty().WithMessage("PendAuthProviderName cannot be empty");
            RuleFor(p => p.ProviderName).NotNull().WithMessage("PendAuthProviderName cannot be null");

            RuleFor(p => p.ProviderFhirId).NotEmpty().WithMessage("ProviderFhirId cannot be empty");
            RuleFor(p => p.ProviderFhirId).NotNull().WithMessage("ProviderFhirId cannot be null");

            RuleFor(p => p.ProviderFhirIdEMP).NotEmpty().WithMessage("ProviderFhirIdEMP cannot be empty");
            RuleFor(p => p.ProviderFhirIdEMP).NotNull().WithMessage("ProviderFhirIdEMP cannot be null");

        }
    }

    public class ActiveOrderValidator : AbstractValidator<ActiveOrderReceived>
    {
        public ActiveOrderValidator()
        {
            RuleFor(p => p.OrdId).NotEmpty().WithMessage("ActiveOrder Id cannot be empty");
            RuleFor(p => p.OrdId).NotNull().WithMessage("ActiveOrder Id cannot be null");

            RuleFor(p => p.NumRefillsAllowed).NotEmpty().WithMessage("ActiveOrder NumRefillsAllowed cannot be empty");
            RuleFor(p => p.NumRefillsAllowed).NotNull().WithMessage("ActiveOrder NumRefillsAllowed cannot be null");

            RuleFor(p => p.OrderInstant).NotEmpty().WithMessage("ActiveOrder OrderInstant cannot be empty");
            RuleFor(p => p.OrderInstant).NotNull().WithMessage("ActiveOrder OrderInstant cannot be null");

            RuleFor(p => p.Quantity).NotEmpty().WithMessage("ActiveOrder Quantity cannot be empty");
            RuleFor(p => p.Quantity).NotNull().WithMessage("ActiveOrder Quantity cannot be null");

        }
    }

    public class PendedOrdersProviderValidator : AbstractValidator<PendedOrders>
    {
        public PendedOrdersProviderValidator()
        {
            RuleFor(po => po.ordID).NotEmpty().WithMessage("ordID cannot be empty");
            RuleFor(po => po.ordID).NotNull().WithMessage("ordID cannot be null");

            RuleFor(po => po.MedName).NotEmpty().WithMessage("MedName cannot be empty");
            RuleFor(po => po.MedName).NotNull().WithMessage("MedName cannot be null");

            RuleFor(po => po.Quantity).NotEmpty().WithMessage("Quantity cannot be empty");
            RuleFor(po => po.Quantity).NotNull().WithMessage("Quantity cannot be null");

            RuleFor(po => po.NumRefillsAllowed).NotEmpty().WithMessage("NumRefillsAllowed cannot be empty");
            RuleFor(po => po.NumRefillsAllowed).NotNull().WithMessage("NumRefillsAllowed cannot be null");

            RuleFor(po => po.MedID).NotEmpty().WithMessage("MedID cannot be empty");
            RuleFor(po => po.MedID).NotNull().WithMessage("MedID cannot be null");

            RuleFor(po => po.RxNormCode).NotEmpty().WithMessage("RxNorm Code cannot be empty");
            RuleFor(po => po.RxNormCode).NotNull().WithMessage("RxNorm Code cannot be null");

            RuleFor(po => po.ExpireDate).Empty().Must(no => string.IsNullOrEmpty(no)).WithMessage("ExpireDate must be empty or null");

            RuleFor(po => po.ActiveAuthProvider)
                .SetValidator(new ActiveAuthProviderValidator());

            RuleFor(po => po.PendAuthProvider)
                .SetValidator(new PendAuthProviderValidator());

            RuleFor(po => po.ActiveOrder)
                .SetValidator(new ActiveOrderValidator());
        }
    }
}

