﻿using System;
using System.Collections.Generic;
using Incubator_OIA_CommonModels;

namespace CDOIntegrationService.Refactor.Models
{
    //public class ActiveAuthProvider
    //{
    //    public string ProviderId { get; set; }
    //    public string ProviderName { get; set; }
    //    public string ProviderSpecialties { get; set; }
    //    public string ProviderFhirId { get; set; }
    //    public string ProviderFhirIdEMP { get; set; }
    //}

    //public class ActiveDepartment
    //{
    //    public string DepartmentId { get; set; }
    //    public string DepartmentName { get; set; }
    //    public string DepartmentSpecialty { get; set; }
    //}

    //public class ActiveOrder
    //{
    //    public string OrderId { get; set; }
    //    public string NumRefillsAllowed { get; set; }
    //    public DateTime? OrderInstant { get; set; }
    //    public string OrderEndDate { get; set; }
    //    public string OrderEndDateGT30Days { get; set; }
    //    public string OrderNoOfRefillAllowed { get; set; }
    //    public string SupplyDuration { get; set; }
    //    public string RxNormCode { get; set; }
    //    public string Quantity { get; set; }
    //    public string SIG { get; set; }
    //    public ActiveAuthProvider ActiveAuthProvider { get; set; }
    //    public ActiveDepartment ActiveDepartment { get; set; }
    //}

    //public class MedicationOrder
    //{
    //    public CosmosModel.Pendedorder PendedOrder { get; set; }
    //    public CosmosModel.ActiveOrders ActiveOrder { get; set; }
    //}

    //public class PatientData
    //{
    //    public string PatientId { get; set; }
    //    public string MRN { get; set; }
    //    public string EnterpriseId { get; set; }
    //    public string FHIRID { get; set; }
    //    public string Name { get; set; }
    //    public string ZipCode { get; set;}
    //    public string PrimaryPhone { get; set; }
    //    public string DOB { get; set; }
    //}

    //public class PendAuthProvider
    //{
    //    public string ProviderId { get; set; }
    //    public string ProviderName { get; set; }
    //    public string ProviderSpecialties { get; set; }
    //    public string ProviderFhirId { get; set; }
    //    public string ProviderFhirIdEMP { get; set; }
    //}

    //public class PendedDepartment
    //{
    //    public string DepartmentId { get; set; }
    //    public string DepartmentName { get; set; }
    //    public string DepartmentSpecialty { get; set; }
    //}

    //public class PendedOrder
    //{
    //    public string PendedOrderId { get; set; }
    //    public string MedId { get; set; }
    //    public string MedName { get; set; }
    //    public string PharmacyName { get; set; }
    //    public string PtComment { get; set; }
    //    public string PharmacyAddress { get; set; }
    //    public string Dosage { get; set; }
    //    public string Quantity { get; set; }
    //    public string SIG { get; set; }
    //    public string SupplyDuration { get; set; }
    //    public string OrderEncounterCSN { get; set; }
    //    public string NumRefillsAllowed { get; set; }
    //    public string DeptSpecialty { get; set; }
    //    public bool IsSameDept { get; set; }
    //    public string RxNormCode { get; set; }
    //    public PendAuthProvider PendAuthProvider { get; set; }
    //}

    //public class OutputMessage
    //{
    //    public string id { get; set; }
    //    public string EOWID { get; set; }
    //    public string MessageBody { get; set; }
    //    public string CSN { get; set; }
    //    public string Status { get; set; }
    //    public string MessageType { get; set; }
    //    public string MyChartUserId { get; set; }
    //    public string CDOName { get; set; }
    //    public string EHRName { get; set; }
    //    public string DefaultPool { get; set; }
    //    public string StatusNote { get; set; }
    //    public CosmosModel.PatientData Patient { get; set; }
    //    public string PatientTimeZone { get; set; }
    //    public string Messagesource { get; set; }
    //    public string MsgSubmittedInstant { get; set; }
    //    public bool IsPregnant { get; set; }
    //    public bool IsBreastFeeding { get; set; }
    //    public string PatientEmailId { get; set; }
    //    public string PatientCommPref { get; set; }
    //    public string AssigningAuthority { get; set; }
    //    public List<CosmosModel.Order> Orders { get; set; }
    //}
    //public class OutputMessageCollection
    //{
    //    public APIStatus APIStatus { get; set; }
    //    public int MessageCount { get; set; }
    //    public List<OutputMessage> Messages { get; set; }
    //}
}