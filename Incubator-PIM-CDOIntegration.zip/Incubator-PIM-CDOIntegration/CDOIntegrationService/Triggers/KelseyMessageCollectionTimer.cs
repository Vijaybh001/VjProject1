﻿using System;
using System.Linq;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.DBLayer;
using CDOIntegrationService.Refactor.Models;
using Incubator_OIA_CommonModels;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace CDOIntegrationService.Triggers
{
    public class KelseyMessageCollectionTimer
    {
        private readonly ICdoServiceFactory _cdoFactory;
        private readonly ILogger<KelseyMessageCollectionTimer> _logger;
        private readonly ICosmosService _cosmosService;
        private readonly IConfiguration _configuration;

        public KelseyMessageCollectionTimer(ILogger<KelseyMessageCollectionTimer> log, ICdoServiceFactory cdoFactory, ICosmosService cosmosService, IConfiguration configuration)
        {
            _cdoFactory = cdoFactory;
            _logger = log;
            _cosmosService = cosmosService;
            _configuration = configuration;
        }

        [FunctionName("MessageCollectionTimer")]
        public async Task Run([TimerTrigger("%KelseyTimerTrigger%")]TimerInfo myTimer, ILogger log)
        //public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "MessageCollectionTimer")] HttpRequest request, ILogger log)
        {
            try
            {
                _logger.LogInformation("MessageCollectionTimer started ");

                var cdoName = _configuration.GetValue<string>("PimMessageCollectionCDO");
                var ehrName = _configuration.GetValue<string>("PimMessageCollectionEHR");
                var messageTypes = _configuration.GetValue<string>("PimMessageType");
                var cdoService = _cdoFactory.GetCdoService(cdoName);
                CosmosModel.GetMessagesResponse messageResponse = new();

                var lastProcRecord = await _cosmosService.GetLastProcessedTime(cdoName);
                var req = new MessageCollectionRequest()
                {
                    CDOName = cdoName,
                    EHRName = ehrName,
                    eowAgeD = DateTime.Parse(lastProcRecord.date),
                    eowAgeT = DateTime.Parse(lastProcRecord.time),
                    MessageTypes = messageTypes
                };

                var outputMessageCollection = await cdoService.GetMessages(req);

                await _cosmosService.AddMessagesToCosmos(outputMessageCollection);

                if (outputMessageCollection.Messages.Count > 0)
                {
                    var maxDate = outputMessageCollection.Messages.Max(t => t.MsgSubmittedInstant);

                    await _cosmosService.UpdateMaxDateTime(maxDate, lastProcRecord);
                }

                _logger.LogInformation("MessageCollectionTimer ended");

                //return new OkObjectResult(outputMessageCollection);
            }

            catch (Exception ex)
            {
                _logger.LogError("MessageCollectionTimer failed. {Error}", ex);
                throw;
            }
        }
    }
}

