﻿//using System;
//using Newtonsoft.Json;
//using System.Collections.Generic;
//using CDOIntegrationService.Refactor.Models;

//namespace CDOIntegrationService.Refactor.Models
//{

//    public class InputMessage
//    {
//        public string PatientTimeZone { get; set; }
//        public string MessageBody { get; set; }
//        public string CSN { get; set; }
//        public string Status { get; set; }
//        public string MessageSource { get; set; }
//        public string MsgSubmittedInstant { get; set; }
//        public bool IsPregnant { get; set; }
//        public string EOWID { get; set; }
//        public string MessageType { get; set; }
//        public string DefaultPool { get; set; }
//        public string PatientCommPref { get; set; }
//        public string MCUserID { get; set; }
//        public string PtEmail { get; set; }
//        public bool IsBreastFeeding { get; set; }
//        public string StatusNote { get; set; }
//        public PatientData Patient { get; set; }
//        public List<PendedOrders> PendedOrders { get; set; }
//    }

//    public class PendedOrders
//    {
//        public string ordID { get; set; }
//        public string MedName { get; set; }
//        public string PharmacyName { get; set; }
//        public string Dosage { get; set; }
//        public string Quantity { get; set; }
//        public string SIG { get; set; }
//        public string SupplyDuration { get; set; }
//        public string MedID { get; set; }
//        public string OrderEncounterCSN { get; set; }
//        public string DeptSpecialty { get; set; }
//        public bool IsSameDept { get; set; }
//        public string PtComment { get; set; }
//        public string PharmacyAddress { get; set; }
//        public string NumRefillsAllowed { get; set; }
//        public string RxNormCode { get; set; }
//        public ActiveAuthProvider ActiveAuthProvider { get; set; }
//        public ActiveOrderReceived ActiveOrder { get; set; }
//        public ActiveDepartment ActiveDepartment { get; set; }
//        public PendAuthProvider PendAuthProvider { get; set; }
//    }
//    public class ActiveOrderReceived
//    {
//        public string OrdId { get; set; }
//        public string NumRefillsAllowed { get; set; }
//        public string Department { get; set; }
//        public string DepartmentSpeciality { get; set; }
//        public DateTime? OrderInstant { get; set; }
//        public string OrderEndDate { get; set; }
//        public string OrderEndDateGT30Days { get; set; }
//        public string OrderNoOfRefillAllowed { get; set; }
//        public string SupplyDuration { get; set; }
//        public string NumRefillsRemaining { get; set; }
//        public string RxNormCode { get; set; }
//        public string Quantity { get; set; }
//        public string SIG { get; set; }
//        public ActiveAuthProvider ActiveAuthProvider { get; set; }
//        public ActiveDepartment ActiveDepartment { get; set; }
//    }
//    public class MessageCollection
//    {
//        public APIStatus APIStatus { get; set; }
//        public int MessageCount { get; set; }
//        public List<InputMessage> Messages { get; set; }
//    }
//}

