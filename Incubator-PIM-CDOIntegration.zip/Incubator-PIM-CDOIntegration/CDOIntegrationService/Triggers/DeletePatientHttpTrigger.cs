﻿//using System;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.Azure.WebJobs;
//using Microsoft.Azure.WebJobs.Extensions.Http;
//using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
//using System.Net;
//using System.Threading.Tasks;
//using Microsoft.Extensions.Logging;
//using CDOIntegrationService.Refactor.Models;
//using FluentValidation;
//using Serilog.Context;

//namespace CDOIntegrationService.Triggers
//{
//    public class DeletePatientHttpTrigger
//    {
//        private readonly ICdoServiceFactory _cdoFactory;
//        private readonly ILogger<DeletePatientHttpTrigger> _logger;
//        public DeletePatientHttpTrigger(ILogger<DeletePatientHttpTrigger> log, ICdoServiceFactory cdoFactory)
//        {
//            _cdoFactory = cdoFactory;
//            _logger = log;
//        }
//        [HttpPost]
//        [FunctionName("deletePatient")]
//        [OpenApiOperation(operationId: "deletePatient", tags: new[] { "deletePatient" })]
//        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(PatientRequestModel), Deprecated = false, Description = "Request", Required = true)]
//        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string))]
//        public async Task<IActionResult> deletePatient(
//            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] PatientRequestModel req,
//            ILogger log)
//        {
//            using (LogContext.PushProperty("PatientFhirId", req.PatientFhirId))
//            {
//                try
//                {
//                    if (req == null)
//                        throw new ValidationException("RequestBody cannot be empty");
//                    using (LogContext.PushProperty("PatientFhirId", req.PatientFhirId))
//                    {
//                        _logger.LogInformation("deletePatient: execution started");
//                        var cdoService = _cdoFactory.GetCdoService(req.Identifiers.CDOID);
//                        await cdoService.DeletePatient(req);
//                        _logger.LogInformation("deletePatient: execution finished");
//                        return new OkObjectResult(new ResponseModel()
//                        {
//                            Status = 1
//                        });
//                    }

//                }
//                catch (ValidationException ex)
//                {
//                    _logger.LogCritical("DeletePatientHttpTrigger.deletePatient() failed. Exception: {Error}", ex);
//                    return new BadRequestObjectResult(new ResponseModel()
//                    {
//                        Status = 0,
//                        ErrorMessage = $"DeletePatientHttpTrigger.deletePatient() failed. Exception: {ex.Message}"
//                    });
//                }
//                catch (Exception ex)
//                {
//                    var obj = new ResponseModel()
//                    {
//                        Status = 0,
//                        ErrorMessage = $"DeletePatientHttpTrigger.deletePatient() failed. Exception: {ex.Message}"
//                    };
//                    var result = new OkObjectResult(obj)
//                    {
//                        StatusCode = (int)HttpStatusCode.InternalServerError
//                    };
//                    _logger.LogCritical("DeletePatientHttpTrigger.deletePatient() failed. Exception: {Error}", ex);
//                    return result;
//                }
//            }
//        }
//    }
//}
