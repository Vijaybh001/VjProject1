﻿using System;
using CDOIntegrationService.Refactor.EHRService.Kelsey;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace CDOIntegrationService.Refactor.EHRService
{
    public class EHRFactory: IEHRFactory
	{
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger<EHRFactory> _logger;
        public EHRFactory(IServiceProvider serviceProvider, ILogger<EHRFactory> logger)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
        }

        public IEHRService GetEHRService(string serviceName, bool isMock)
        {
            _logger.LogInformation("EHRFactory.GetEHRService() execution started ");
            switch (serviceName)
            {
                case Constants.EPIC:
                    if (isMock)
                    {
                        _logger.LogInformation($"EHRFactory.GetEHRService() execution ended - {System.DateTime.UtcNow}");
                        return _serviceProvider.GetService<EpicMockService>();
                    }
                    else
                    {
                        _logger.LogInformation($"EHRFactory.GetEHRService() execution ended - {System.DateTime.UtcNow}");
                        return _serviceProvider.GetService<EpicEhrService>();
                    }
                default:
                    throw new Exception($"EHR service type {serviceName} not found");
            }
        }
    }
}

