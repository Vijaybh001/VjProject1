﻿using System;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Abstractions;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Resolvers;
using Newtonsoft.Json.Serialization;

namespace CDOIntegrationService.Refactor.Models
{
    [OpenApiExample(typeof(MessageCollectionRequestExample))]
    public class MessageCollectionRequest
    {
        [OpenApiProperty]
        public string MessageTypes { get; set; }
        [OpenApiProperty]
        public string CDOName { get; set; }
        [OpenApiProperty]
        public string EHRName { get; set; }
        [OpenApiProperty]
        public DateTime eowAgeD { get; set; }
        [OpenApiProperty]
        public DateTime eowAgeT { get; set; }
    }

    public class MessageCollectionRequestExample : OpenApiExample<MessageCollectionRequest>
    {
        public override IOpenApiExample<MessageCollectionRequest> Build(NamingStrategy namingStrategy = null)
        {
            this.Examples.Add(
                 OpenApiExampleResolver.Resolve(
                     "MessageCollectionRequestExample",
                     new MessageCollectionRequest()
                     {
                         MessageTypes = "*",
                         CDOName = "1",
                         EHRName = "allscripts",
                         eowAgeD = new DateTime(),
                         eowAgeT = new DateTime()
                     },
                     namingStrategy
                 ));
            return this;
        }
    }
}