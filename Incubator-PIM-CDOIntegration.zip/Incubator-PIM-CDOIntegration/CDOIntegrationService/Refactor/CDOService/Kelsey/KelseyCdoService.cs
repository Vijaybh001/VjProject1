using System;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor;
using CDOIntegrationService.Refactor.CDOService.Kelsey;
using CDOIntegrationService.Refactor.ConfigService;
using CDOIntegrationService.Refactor.DBLayer;
using CDOIntegrationService.Refactor.Flex;
using CDOIntegrationService.Refactor.MedicationRequestStatusUpdate;
using CDOIntegrationService.Refactor.Models;
using CDOIntegrationService.Refactor.MyChartService;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using static Incubator_OIA_CommonModels.CosmosModel;
using Task = System.Threading.Tasks.Task;

namespace CDOIntegrationService;

public class KelseyCdoService: ICdoService
{
    private readonly IConfiguration _config;
    private readonly ILogger<KelseyCdoService> _logger;
    private readonly IEHRWrapper _ehrWrapperService;
    private readonly IFhirWrapper _fhirWrapperService;
    private readonly ICdoFactory _cdoFactory;
    private readonly ICosmosService _cosmosService;
    private readonly IFlexService _flexService;
    private readonly IMedicationRequestStatusUpdater _medicationRequestStatusUpdater;
    private readonly ICheckMedicationRequestStatus _checkMedicationRequestStatus;
    private readonly KelseyUtils _kelseyUtils;
    private readonly ISendMyChartMessage _sendMyChartMessageService;
    private readonly IAzureConfig _azureConfig;

    public KelseyCdoService(IConfiguration config, ILogger<KelseyCdoService> logger, ICdoFactory cdoFactory , ICosmosService cosmosService, IFlexService flexService, KelseyUtils kelseyUtils, ISendMyChartMessage sendMyChartMessage, IAzureConfig azureConfig)
    {
        _config = config;
        _logger = logger;
        _ehrWrapperService = cdoFactory.GetEhrWrapperService(Constants.KELSEY);
        _fhirWrapperService = cdoFactory.GetFhirWrapperService(Constants.KELSEY);
        _medicationRequestStatusUpdater = cdoFactory.GetMedicationRequestUpdateWrapperService(Constants.KELSEY);
        _checkMedicationRequestStatus = cdoFactory.CheckMedicationRequestStatusWrapperService(Constants.KELSEY);
        _cdoFactory = cdoFactory;
        _cosmosService = cosmosService;
        _flexService = flexService;
        _kelseyUtils = kelseyUtils;
        _sendMyChartMessageService = sendMyChartMessage;
        _azureConfig = azureConfig;
    }

    public async Task<OutputMessageCollection> GetMessages(MessageCollectionRequest req)
    {
        try
        {
            _logger.LogInformation("KelseyCdoService.GetMessages() execution started ");
            var IsMock = _azureConfig.GetValueFromAzureConfig<bool>("IsMock");
            var _messageService = _cdoFactory.GetMessageService(Constants.KELSEY, IsMock);
            var response = await _messageService.GetMessages(req);

            if(response?.Messages != null)
            {
                foreach (var message in response?.Messages)
                {
                    message.OIAMessageLoadTime = DateTime.Now;
                }
            }
            _logger.LogInformation("KelseyCdoService.GetMessages() execution ended ");
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyCdoService.GetMessages() failed. Exception occured: {Error}", ex);
            throw;
        }
    }

    public async Task<SignFinalOrderResponseModel> SignFinalOrder(OutReachRequest req)
    {
        try
        {
            _logger.LogInformation("KelseyCdoService.SignFinalOrder() execution started ");
            var IsMock = _azureConfig.GetValueFromAzureConfig<bool>("IsMock");
            var _signFinalOrder = _cdoFactory.GetSignFinalOrder(Constants.KELSEY, IsMock);
            var response = await _signFinalOrder.SignOrder(req);
            _logger.LogInformation("KelseyCdoService.SignFinalOrder() execution ended ");
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyCdoService.SignFinalOrder() failed. Exception occured: {Error}", ex);
            throw;
        }
    }

    public async Task<MyChartMessageOutputModel> MkoMessages(MyChartMessageInputModel req)
    {
        try
        {
            _logger.LogInformation("KelseyCdoService.MkoMessages() execution started ");
            var isMock = _config.GetValue<bool>("isMock");
            var _mkoMessageService = _cdoFactory.SendMyChartMessage(Constants.KELSEY, isMock);
            var response = await _mkoMessageService.SendMessage(req);

            _logger.LogInformation("KelseyCdoService.MkoMessages() execution ended ");
            return response;

        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyCdoService.MkoMessages() failed. Exception: {Error}", ex);
            throw;
        }
    }

    public async Task<ReturnToProviderResponse> RecommendationMessages(RecommendationInputModel req)
    {
        try
        {
            _logger.LogInformation("KelseyCdoService.RecommendationMessages() execution started ");
            var IsMock = _azureConfig.GetValueFromAzureConfig<bool>("IsMock");
            var recommendation = _cdoFactory.sendRecommendation(Constants.KELSEY, IsMock);
            var response = await recommendation.RecommendationMessages(req);
            _logger.LogInformation("KelseyCdoService.RecommendationMessages() execution ended ");
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyCdoService.RecommendationMessages() failed. Exception: {Error}", ex);
            throw;
        }
    }

    public async Task<bool> ProcessSchedulingTicket(SchedulingTicketRequestModel req)
    {
        //TODO: This async method lacks 'await' operators and will run synchronously.
        try
        {
            _logger.LogInformation("KelseyCdoService.ProcessSchedulingTicket() execution started ");


            //Todo: call schedulerAPI
            //var responseData = JsonConvert.DeserializeObject<SchedulingTicketResponseModel>(path);

            //if (responseData.APIStatus.Status.Equals("Success"))//TODO: Uncomment after real api integration
            _logger.LogInformation("KelseyCdoService.ProcessSchedulingTicket() execution ended ");
            return true;
            
            /*
            {
                var cosmosRecord = await _cosmosService.FetchCosmosRecordByQueryParams(req.patientId, req.CdoName, req.Id, req.EOW);

                var record = cosmosRecord.Orders.Find(order => order.PendedOrder.PendedOrderId == req.pendedOrderId);
                if (record != null && record.OrderSteps.PimOutReachSteps != null && record.OrderSteps.PimOutReachSteps.ProcessSteps != null && record.OrderSteps.PimOutReachSteps.ProcessSteps.SchedulerTicket.Status == "Pending")
                {
                    record.OrderSteps.PimOutReachSteps.ProcessSteps.SchedulerTicket.Status = "Success";
                    record.OrderSteps.PimOutReachSteps.ProcessSteps.SchedulerTicket.CurrentTimestamp = System.DateTime.UtcNow;

                    var containerName = _config.GetValue<string>("CosmosDBAuditContainerInboxRefill");
                    var container = _cosmosService.GetContainer(containerName);
                    await _cosmosService.UpdateAsync(container, cosmosRecord, cosmosRecord.CDOName);
                }
            }
            */

         
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyCdoService.ProcessSchedulingTicket() failed. Exception: {Error}", ex);
            throw;
        }
    }


    public async Task<Bundle> GetPatientRaw(PatientRequestModel req)
    {
        try
        {
            //Pre processsing logic
            //Call Kelsey FhirWrapperService.get patient
            _logger.LogInformation("KelseyCdoService.GetPatientRaw() execution started ");
            var response = await _fhirWrapperService.GetPatientRaw(req);
            _logger.LogInformation("KelseyCdoService.GetPatientRaw() execution ended ");
            //Post processing logic
            //Return Raw Data-- Generic Patient object for all CDO
            return response;
        }
        catch(Exception ex)
        {
            _logger.LogError("KelseyCdoService.GetPatientRaw() failed. Exception occured: {Error}", ex);
            throw;
        }
    }

    public async Task<MyChartMessageOutputModel> SendMyChartMessage(MyChartMessageInputModel req)
    {
        try
        {
            _logger.LogInformation("KelseyCdoService.GetMyChartResponse() execution started ");
            var response = await _sendMyChartMessageService.SendMessage(req);
            _logger.LogInformation("KelseyCdoService.GetMyChartResponse() execution ended ");
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyCdoService.GetMyChartResponse() failed. Exception occured: {Error}", ex);
            throw;
        }
    }

    public async Task<PimResource> GetPatientDetailsFromRaw(PatientRequestModel req)
    {
        try
        {
            //Pre processsing logic
            //Call Kelsey FhirWrapperService.get patient
            _logger.LogInformation("KelseyCdoService.GetPatientDetailsFromRaw() execution started");
            var responseBundle = await _fhirWrapperService.GetPatientRaw(req);
            _logger.LogInformation("KelseyCDOService:GetPatientRaw completed");
            var response = _kelseyUtils.ParsePatientDetails(responseBundle, _logger);

            _logger.LogInformation("KelseyCdoService.GetPatientDetailsFromRaw() execution ended");
            //Post processing logic
            //Return Raw Data-- Generic Patient object for all CDO
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyCdoService.GetPatientDetailsFromRaw() failed. Exception occured: {Error}", ex);
            throw;
        }
    }

    public async Task<bool> SetPatient(PatientRequestModel req)
    {
        try
        {
            _logger.LogInformation("KelseyCdoService.SetPatient() execution started ");

            var isSetPatientMock = _azureConfig.GetValueFromAzureConfig<bool>("IsSetPatientMock"); //TODO: read only needed values. do only for non prod

            var patientData = await _ehrWrapperService.GetPatientData(req.PatientFhirId, isSetPatientMock);

            var result = await _fhirWrapperService.SetBundle(req, patientData, req.PatientFhirId);
            //Return the boolean result
            _logger.LogInformation("KelseyCdoService.SetPatient() execution ended ");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyCdoService.SetPatient() failed. Exception occured: {Error}", ex);
            throw;
        }
    }

    public async Task<bool> DeletePatient(PatientRequestModel req)
    {
        try
        {
            _logger.LogInformation("KelseyCdoService.DeletePatient() execution started ");
            var result = await _fhirWrapperService.DeletePatient(req);
            _logger.LogInformation("KelseyCdoService.DeletePatient() execution ended ");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyCdoService.DeletePatient() failed. Exception occured: {Error}", ex);
            throw;
        }
    }

    public async Task GetMedicationRequestUpdaterService(bool updateForActiveProvider = false)
    {
        try
        {
            _logger.LogInformation("KelseyCdoService.GetMedicationRequestUpdaterService() execution started ");
            await _medicationRequestStatusUpdater.MedicationRequestStatusUpdater(updateForActiveProvider);
            _logger.LogInformation("KelseyCdoService.GetMedicationRequestUpdaterService() execution ended ");
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyCdoService.GetMedicationRequestUpdaterService() failed. Exception occured: {Error}", ex);
            throw;
        }
    }

    public async Task<MRStatusResponseModel> CheckMedicationRequestStatusService(MedicationOrder req)
    {
        try
        {
            _logger.LogInformation("KelseyCdoService.CheckMedicationRequestStatusService() execution started ");
            var result = await _checkMedicationRequestStatus.ProcessPendedOrderStatus(req);
            _logger.LogInformation("KelseyCdoService.CheckMedicationRequestStatusService() execution ended ");
            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyCdoService.CheckMedicationRequestStatusService() failed. Exception occured: {Error}", ex);
            throw;
        }
    }

    public void SendCdsHookA()
    {
        //Utilize Kelsey CDSService
        //_cdsService.SendCdsHookA();
        //To be discussed
        throw new System.NotImplementedException();
    }

    public async Task<string> SignOrder(FlexRequestBody flexRequestBody)
    {
        try
        {
            _logger.LogInformation("KelseyCdoService.SignOrder() execution started ");
            var response = await _flexService.SignOrder(flexRequestBody);
            _logger.LogInformation("KelseyCdoService.SignOrder() execution ended ");
            return response;
        }
        catch(Exception ex)
        {
            _logger.LogError("KelseyCdoService.SignOrder() failed. Exception occured: {Error}", ex);
            throw;
        }
    }

    public async Task<Bundle> GetPatientRawResource(string patientFhirId, string resourceType)
    {
        try
        {
            _logger.LogInformation("KelseyCdoService.GetPatientRawResource() execution started ");
            var patientData = await _ehrWrapperService.GetPatientRawDataByResource(patientFhirId, resourceType);
            _logger.LogInformation("KelseyCdoService.GetPatientRawResource() execution ended ");
            return patientData;
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyCdoService.GetPatientRawResource() failed. Exception occured: {Error}", ex);
            throw;
        }
    }
}