﻿using System;
using CDOIntegrationService.Refactor.Models;
using CDOIntegrationService.Refactor.ReturnToProvider;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using RestSharp;
using Microsoft.Extensions.Configuration;
using AzureFhirFramework.RestClientWrapper;
using AzureFhirFramework.RestClientWrapper.RestPolicy;
using CDOIntegrationService.Refactor.CustomException;
using Incubator_OIA_CommonModels;

namespace CDOIntegrationService.Refactor.MyChartService
{
	public class SendMyChartMessage : ISendMyChartMessage
	{
        private readonly ILogger<SendMyChartMessage> _logger;
        private readonly IConfiguration _config;
        private readonly IRestClientWrapper _restService;
        public SendMyChartMessage(ILogger<SendMyChartMessage> logger, IConfiguration configuration, IRestClientWrapper restClientWrapper)
        {
            _logger = logger;
            _config = configuration;
            _restService = restClientWrapper;
        }
        public async Task<MyChartMessageOutputModel> SendMessage(MyChartMessageInputModel myChartMessageInputModel)
        {
            try
            {
                _logger.LogInformation("SendMyChartMessage.SendMessage() execution started ");
                string url = _config.GetValue<string>("MyChartApiUrl");
                var request = new RestRequest()
                {
                    Method = Method.Post,
                    Resource = url
                };
                request.AddQueryParameter("csn", myChartMessageInputModel.Csn);
                request.AddQueryParameter("msgbody", myChartMessageInputModel.Msgbody);
                request.AddQueryParameter("subject", myChartMessageInputModel.Subject);
                request.AddHeader("Authorization", $"Basic {_config.GetValue<string>("EpicBasicToken")}");
                var response = await _restService.ExecuteRequest(request, Constants.MY_CHART_SERVICE);
                ResponseModel responseModel = new ResponseModel()
                {
                    StatusCode = (int)response.StatusCode,
                    ErrorMessage = response.Content
                };
                if (response.IsSuccessStatusCode)
                {
                    _logger.LogInformation("SendMyChartMessage.SendMessage() fetching send my chart api response");
                    var myChartApiResponse = JsonConvert.DeserializeObject<MyChartMessageOutputModel>(response.Content);
                    _logger.LogInformation("SendMyChartMessage.SendMessage() execution ended");
                    return myChartApiResponse;
                }
                _logger.LogCritical("SendMyChartMessage.SendMessage() failed : {Error}", response.ErrorMessage);
                _logger.LogInformation("SendMyChartMessage.SendMessage() execution ended");
                throw new ResponseCustomException(response, responseModel);
            }
            catch (Exception ex)
            {
                _logger.LogCritical("SendMyChartMessage.SendMessage() failed. Exception: {Error}", ex);
                throw;
            }
        }
    }
}

