﻿using System;
using CDOIntegrationService.Refactor.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Serilog;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using RestSharp;
using Microsoft.Extensions.Configuration;
using AzureFhirFramework.RestClientWrapper;
using AzureFhirFramework.RestClientWrapper.RestPolicy;
using Incubator_OIA_CommonModels;
using CDOIntegrationService.Refactor.CustomException;

namespace CDOIntegrationService.Refactor.ReturnToProvider
{
	public class SendRecommendation:ISendRecommendation
	{
        private readonly ILogger<SendRecommendation> _logger;
        private readonly IConfiguration _config;
        private readonly IRestClientWrapper _restService;
        public SendRecommendation(ILogger<SendRecommendation> logger, IConfiguration config, IRestClientWrapper restService)
        {
            _logger = logger;
            _config = config;
            _restService = restService;
        }
        public async Task<ReturnToProviderResponse> RecommendationMessages(RecommendationInputModel req)
        {
            try
            {
                string url = _config.GetValue<string>("CdoIntegratorSendRecommendationToProvider");
                ReturnToProviderResponse rtpResponse = new ReturnToProviderResponse();
                var request = new RestRequest()
                {
                    Method = Method.Post,
                    Resource = url
                };
                request.AddQueryParameter("EOWID", req.EOWID);
                request.AddQueryParameter("eow805", req.eow805);
                request.AddQueryParameter("Pools", req.Pools);
                if (!string.IsNullOrEmpty(req.ConceptID) && !string.IsNullOrEmpty(req.ConceptValue))
                {
                    request.AddQueryParameter("ConceptID", req.ConceptID);
                    request.AddQueryParameter("ConceptValue", req.ConceptValue);
                }
                request.AddHeader("Authorization", $"Basic {_config.GetValue<string>("EpicBasicToken")}");
                var response = await _restService.ExecuteRequest(request,"Return To Provider");
                ResponseModel responseModel = new ResponseModel()
                {
                    StatusCode = (int)response?.StatusCode,
                    ErrorMessage = response?.Content
                };
                if (response != null && response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    if (!string.IsNullOrEmpty(response.Content))
                    {
                        _logger.LogInformation("ReturnToProviderService.RecommendationMessages() fetching return to provider response");
                        rtpResponse = JsonConvert.DeserializeObject<ReturnToProviderResponse>(response.Content);
                    }
                    else
                    {
                        _logger.LogInformation("ReturnToProviderService.RecommendationMessages() fetching return to provider response is null");
                    }
                }
                else
                {
                    _logger.LogError("KelseyMessageService : GetMessages() : Message collection api Failed");
                    throw new ResponseCustomException(response, responseModel);
                }

                _logger.LogInformation("ReturnToProviderService.RecommendationMessages() execution ended");
                return rtpResponse;
            }
            catch (Exception ex)
            {
                _logger.LogError("SendRecommendation: recommendationMessages() failed. Exception: {Error}", ex);
                throw new Exception(ex.Message);
            }
        }

    }
}

