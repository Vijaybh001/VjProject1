﻿// using System;
// using System.IO;
// using System.Threading.Tasks;
// using Microsoft.AspNetCore.Mvc;
// using Microsoft.Azure.WebJobs;
// using Microsoft.Azure.WebJobs.Extensions.Http;
// using Microsoft.AspNetCore.Http;
// using Microsoft.Azure.WebJobs.Host;
// using Microsoft.Extensions.Logging;
// using Newtonsoft.Json;
// using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
// using Microsoft.Extensions.Configuration;
// using System.Net;
// using CDOIntegrationService.Refactor.Models;
// using CDOIntegrationService.Refactor.SchedulingTicketService;
// using Serilog.Context;
//
// namespace CDOIntegrationService.Triggers
// {
//     public class CreateSchedulingTicketHttpTrigger
//     {
//         private readonly ICdoServiceFactory _cdoFactory;
//         private readonly ILogger<CreateSchedulingTicketHttpTrigger> _logger;
//         private readonly IProcessSchedulingTicket _createSchedulingTicket;
//
//         public CreateSchedulingTicketHttpTrigger(ILogger<CreateSchedulingTicketHttpTrigger> log, ICdoServiceFactory cdoFactory, IProcessSchedulingTicket createSchedulingTicket)
//         {
//             _createSchedulingTicket = createSchedulingTicket;
//             _cdoFactory = cdoFactory;
//             _logger = log;
//         }
//
//         [HttpPost]
//         [FunctionName("CreateSchedulingTicketHttpTrigger")]
//         [OpenApiOperation(operationId: "CreateSchedulingTicketHttpTrigger", tags: new[] { "CreateSchedulingTicketHttpTrigger" })]
//         [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(SchedulingTicketRequestModel), Deprecated = false, Description = "MessageCollectionRequest", Required = true)]
//         [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string))]
//
//         public async Task<IActionResult> createSchedulingTicket(
//             [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)]
//             SchedulingTicketRequestModel req,
//             ILogger log)
//         {
//             using (LogContext.PushProperty("PendedOrderID", req.pendedOrderId))
//             using (LogContext.PushProperty("RequestID", req.Id))
//             using (LogContext.PushProperty("PatientFhirId", req.patientFhirId))
//             using (LogContext.PushProperty("EOWID", req.EOW))
//             {
//                 try
//                 {
//
//
//                     _logger.LogInformation("createSchedulingTicketHttpTrigger: processing started for pendedOrderId: {pendedOrderId}", req.pendedOrderId);
//
//                     if (string.IsNullOrEmpty(req.CdoName))
//                     {
//                         throw new Exception("createSchedulingTicketHttpTrigger:createSchedulingTicket() - Null values supplied as Input");
//                     }
//
//                     var cdoService = _cdoFactory.GetCdoService(req.CdoName);
//                     var response = await cdoService.ProcessSchedulingTicket(req);
//                     OkObjectResult result;
//                     if (response)
//                     {
//                         result = new OkObjectResult(new ResponseModel()
//                         {
//                             Status = 1,
//                             ErrorMessage = "Scheduling Ticket Created Successfully"
//                         });
//                     }
//                     else
//                     {
//                         var obj = new ResponseModel()
//                         {
//                             Status = 0,
//                             ErrorMessage = $"CreateSchedulingTicketHttpTrigger.createSchedulingTicket() failed"
//                         };
//                         result = new OkObjectResult(obj)
//                         {
//                             StatusCode = (int)HttpStatusCode.InternalServerError
//                         };
//                     }
//
//                     _logger.LogInformation("createSchedulingTicketHttpTrigger: processing Finished for pendedOrderId: {pendedOrderId}", req.pendedOrderId);
//                     return result;
//                 }
//                 catch (Exception ex)
//                 {
//                     var obj = new ResponseModel()
//                     {
//                         Status = 0,
//                         ErrorMessage = $"CreateSchedulingTicketHttpTrigger.createSchedulingTicket() failed. Exception: {ex.Message}"
//                     };
//                     var result = new OkObjectResult(obj)
//                     {
//                         StatusCode = (int)HttpStatusCode.InternalServerError
//                     };
//                     _logger.LogCritical("CreateSchedulingTicketHttpTrigger.createSchedulingTicket()  failed. Exception: {Error}", ex);
//
//                     return result;
//                 }
//             }
//         }
//
//     }
// }
