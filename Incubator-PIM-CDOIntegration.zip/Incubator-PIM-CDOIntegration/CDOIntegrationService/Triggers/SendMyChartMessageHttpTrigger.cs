﻿using System;
using CDOIntegrationService.Refactor.Models;
using FluentValidation;
using Hl7.Fhir.Serialization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Serilog.Context;
using System.Net;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor;
using Microsoft.Extensions.Configuration;
using Incubator_OIA_CommonModels;
using CDOIntegrationService.Refactor.CustomException;
using CDOIntegrationService.Refactor.ConfigService;
using Incubator_OIA_CommonModels;

namespace CDOIntegrationService.Triggers
{
	public class SendMyChartMessageHttpTrigger
	{
        private readonly ICdoServiceFactory _cdoFactory;
        private readonly ILogger<SendMyChartMessageHttpTrigger> _logger;
        private readonly IValidator<MyChartMessageInputModel> _validator;
        private readonly IConfiguration _config;
        private readonly IAzureConfig _azureConfig;

        public SendMyChartMessageHttpTrigger(ILogger<SendMyChartMessageHttpTrigger> log, ICdoServiceFactory cdoFactory, IValidator<MyChartMessageInputModel> validator, IConfiguration configuration, IAzureConfig azureConfig)
        {
            _cdoFactory = cdoFactory;
            _logger = log;
            _validator = validator;
            _config = configuration;
            _azureConfig = azureConfig;
        }
        [HttpPost]
        [FunctionName("SendMyChartMessage")]
        [OpenApiOperation(operationId: "SendMyChartMessage", tags: new[] { "SendMyChartMessage" })]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(MyChartMessageInputModel), Deprecated = false, Description = "Request", Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string))]
        public async Task<IActionResult> SendMyChartMessage(
                [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] MyChartMessageInputModel req,
                ILogger log)
        {
            _logger.LogInformation("SendMyChartMessage: execution started");
            using (LogContext.PushProperty("Csn", req?.Csn))
            {
                try
                {
                    if (req == null || string.IsNullOrEmpty(req.Csn))
                        throw new ValidationException("RequestBody cannot be empty");
                    await _validator.ValidateAndThrowAsync(req);
                    var cdoService = _cdoFactory.GetCdoService(Constants.KELSEY);
                    var myChartResponse = await cdoService.MkoMessages(req);
                    MyChartOutputModel myChartOutput = new MyChartOutputModel()
                    {
                        ApiStatusCode = new ResponseModel()
                        {
                            StatusCode = (int)HttpStatusCode.OK
                        },
                        MyChartMessageOutputModel = myChartResponse
                    };

                    _logger.LogInformation("SendMyChartMessage: execution finished");
                    return new OkObjectResult(myChartOutput)
                    {
                        StatusCode = (int)HttpStatusCode.OK
                    };
                }
                catch (ValidationException ex)
                {
                    _logger.LogError("SendMyChartMessage() failed. Exception: {Error}", ex);
                    return new BadRequestObjectResult(new ResponseModel()
                    {
                        StatusCode = (int)HttpStatusCode.BadRequest,
                        ErrorMessage = ex.Message
                    })
                    {
                        StatusCode = (int)HttpStatusCode.BadRequest
                    };
                }
                catch (ResponseCustomException ex)
                {
                    _logger.LogError("SetPatient.SetPatientInfo()failed. Exception: {Error}", ex);
                    return new BadRequestObjectResult(new MyChartOutputModel()
                    {
                        ApiStatusCode = new ResponseModel()
                        {
                            StatusCode = ex.CustomObject.StatusCode,
                            ErrorMessage = $"SetPatient.SetPatientInfo()failed. Exception: {ex.CustomObject.ErrorMessage}"
                        }
                    })
                    {
                        StatusCode = ex.CustomObject.StatusCode
                    };
                }
                catch (Exception ex)
                {
                    var obj = new ResponseModel()
                    {
                        StatusCode = (int)HttpStatusCode.InternalServerError,
                        ErrorMessage = ex.Message
                    };
                    var result = new OkObjectResult(obj)
                    {
                        StatusCode = (int)HttpStatusCode.InternalServerError
                    };
                    _logger.LogError("SendMyChartMessage() failed. Exception: {Ex}", ex);
                    return result;
                }
            }
        }
    }
}

