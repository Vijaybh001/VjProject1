using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor;
using CDOIntegrationService.Refactor.Authentication;
using CDOIntegrationService.Refactor.CustomException;
using CDOIntegrationService.Refactor.Models;
using AzureFhirFramework.RestClientWrapper;
using AzureFhirFramework.RestClientWrapper.RestPolicy;
using Incubator_OIA_CommonModels;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using RestSharp;
using Serilog;
using Serilog.Context;

namespace CDOIntegrationService;

public class EpicEhrService: IEHRService
{
    private readonly IAuthentication _authenticationService;
    private readonly IConfiguration _configuration;
    private readonly ILogger<EpicEhrService> _logger;
    private readonly IRestClientWrapper _restService;

    public EpicEhrService(IAuthFactory authFactory, IConfiguration configuration, ILogger<EpicEhrService> logger, IRestClientWrapper restClientWrapper)
    {
        _authenticationService = authFactory.GetAuthService(Constants.EPIC);
        _logger = logger;
        _configuration = configuration;
        _restService = restClientWrapper;
    }

    public async Task<string> GetEpicResourceByPatient(string patientFhirId, string resourceName)
    {
        using (LogContext.PushProperty("PatientFhirId", patientFhirId))
        {
            try
            {
                _logger.LogInformation("EpicEhrService.GetEpicResourceByPatient() execution started for {resource}", resourceName);

                var firstPageResources = await GetEpicResources(patientFhirId, resourceName);
                var result = new StringBuilder(firstPageResources);

                bool hasNextLink = HasNextLink(result.ToString(), out string nextLinkUrl);
                // todo: use hl7.fhir
                while (hasNextLink)
                {
                    var nextResourceName = ExtractResourceNameFromUrl(nextLinkUrl);
                    var nextPageResources = await GetEpicResources(patientFhirId, nextResourceName);
                    result = AppendData(nextPageResources, result.ToString());
                    hasNextLink = HasNextLink(nextPageResources, out nextLinkUrl);
                }

                _logger.LogInformation("EpicEhrService.GetEpicResourceByPatient() execution ended for resource {resource}", resourceName);
                return result.ToString();
            }
            catch (Exception ex)
            {
                _logger.LogError("EpicEhrService.GetEpicResourceByPatient() failed. Exception: {Error}", ex);
                throw;
            }
        }
    }

    private async Task<string> GetEpicResources(string patientFhirId, string resourceName)
    {
        try
        {
            _logger.LogInformation("EpicEhrService.GetEpicResources() execution started for {resource}", resourceName);

            var url = $"{_configuration.GetValue<string>("EpicBaseURL")}/api/FHIR/R4/{resourceName}";
            var token = await _authenticationService.GetToken();
            var fromDate = DateTime.UtcNow.AddYears(-2).ToString("yyyy-MM-dd");//TODO: add 2 years in the config

            var request = new RestRequest(url, Method.Get);
            request.AddHeader("Authorization", $"Bearer {token}");
            request.AddHeader("Accept", "application/json+fhir");
            request.AddQueryParameter("patient", patientFhirId);
            request.AddQueryParameter("date", $"ge{fromDate}");

            //if (resourceName.Equals(Constants.MEDICATIONREQUEST) || resourceName.StartsWith(Constants.MEDICATIONREQUEST))
            //{
            //    request.AddQueryParameter("status", "active");
            //}
            if (resourceName.Equals(Constants.CONDITION) || resourceName.Equals(Constants.ALLERGYINTOLERANCE) || resourceName.StartsWith(Constants.CONDITION) || resourceName.StartsWith(Constants.ALLERGYINTOLERANCE))
            {
                request.AddQueryParameter("clinical-status", "active");
            }
            if (resourceName.Equals(Constants.OBSERVATION) || resourceName.StartsWith(Constants.OBSERVATION))
            {
                request.AddQueryParameter("category", "laboratory,vital-signs");
            }
            request.AddParameter("client_id", _configuration.GetValue<string>("EpicClientID"));
            request.AddParameter("grant_type", "client_credentials");

            var response = await _restService.ExecuteRequest(request, "Epic");
            ResponseModel responseModel = new ResponseModel()
            {
                StatusCode = (int)response.StatusCode,
                ErrorMessage = response.Content
            };
            if (response.StatusCode != System.Net.HttpStatusCode.OK)
            {
                _logger.LogError("EpicEhrService.GetEpicResources(): {ResourceType} api call failed");
                throw new ResponseCustomException(response, responseModel);
            }
            if (response == null)
            {
                _logger.LogError("EpicEhrService.GetEpicResources() failed for {ResourceType} with response null", resourceName);
                throw new Exception("EpicEhrService.GetEpicResources() failed for " + resourceName + " with response null");
            }
            if (!response.IsSuccessful)
            {
                _logger.LogError("EpicEhrService.GetEpicResources() failed for " + resourceName + " with Http response code : {Error}", response);
                throw new Exception("EpicEhrService.GetEpicResources() failed for " + resourceName + " with failed Http response code");
            }
            if (string.IsNullOrEmpty(response.Content))
            {
                _logger.LogError("EpicEhrService.GetEpicResources() failed for {ResourceType} with empty response", resourceName);
                throw new Exception("Epic response is empty for resource" + resourceName);
            }
            _logger.LogInformation("EpicEhrService.GetEpicResources() executed successfully for {ResourceType}", resourceName);
            return response.Content;
        }
        catch (Exception ex)
        {
            _logger.LogError("EpicEhrService.GetEpicResource() failed. Exception: {Error}", ex);
            throw;
        }
    }

    private bool HasNextLink(string content, out string nextLinkUrl)
    {
        try
        {
            var json = JObject.Parse(content);
            if (json["link"] is JArray links)
            {
                foreach (var link in links)
                {
                    if (link["relation"] != null && link["relation"].ToString().Equals("next", StringComparison.OrdinalIgnoreCase))
                    {
                        nextLinkUrl = link["url"].ToString();
                        return true;
                    }
                }
            }
            else
            {
                _logger.LogInformation("EpicEhrService.HasNextLink(): json[\"link\"] is null");
            }
            nextLinkUrl = null;
            return false;
        }
        catch (Exception ex)
        {
            _logger.LogError("An error occurred in HasNextLink method. Exception: {Error}", ex.Message);
            throw;
        }
    }

    private string ExtractResourceNameFromUrl(string url)
    {
        try
        {
            var parts = url.Split('/');
            return parts.Last();
        }
        catch (Exception ex)
        {
            _logger.LogError("An error occurred in ExtractResourceNameFromUrl method. Exception: {Error}", ex.Message);
            throw;
        }
    }

    private StringBuilder AppendData(string pageData, string firstPageData)
    {
        try
        {
            _logger.LogInformation("EpicEhrService.AppendData() Appending Data started");

            var currentPage = JObject.Parse(pageData);
            var firstPage = JObject.Parse(firstPageData);
            if (currentPage["entry"] is JArray currentPageEntries && firstPage["entry"] is JArray firstPageEntries)
            {
                firstPageEntries.Merge(currentPageEntries);
            }
            _logger.LogInformation("EpicEhrService.AppendData() Data appended successfully.");
            return new StringBuilder(firstPage.ToString());
        }
        catch (Exception ex)
        {
            _logger.LogError("EpicEhrService.AppendData() An error occurred in AppendData. Exception thrown: {Error}", ex.Message);
            throw;
        }
    }

    public async Task<string> GetPatientDataForMRUpdater(string patientFhirId, string resourceName)
    {
        using (LogContext.PushProperty("PatientFhirId", patientFhirId))
        {
            try
            {
                _logger.LogInformation("EpicEhrService.GetMedicationRequestForMRUpdater() execution started for {resource} ", resourceName);

                var url = $"{_configuration.GetValue<string>("EpicBaseURL")}/api/FHIR/R4/{resourceName}";
                var token = await _authenticationService.GetToken();
                var fromDate = DateTime.UtcNow.AddYears(-2).ToString("yyyy-MM-dd");//TODO: add 2 years in the config

                var request = new RestRequest(url, Method.Get);
                request.AddHeader("Authorization", $"Bearer {token}");
                request.AddHeader("Accept", "application/json+fhir");
                request.AddQueryParameter("patient", patientFhirId);
                request.AddQueryParameter("date", $"ge{fromDate}");

                if (resourceName.Equals("Observation"))
                {
                    request.AddQueryParameter("category", "laboratory,vital-signs");
                }
                request.AddParameter("client_id", _configuration.GetValue<string>("EpicClientID"));
                request.AddParameter("grant_type", "client_credentials");

                var response = await _restService.ExecuteRequest(request, "GetPatientDataForMRUpdater");
                if (response == null)
                {
                    _logger.LogInformation("EpicEhrService.GetMedicationRequestForMRUpdater() failed for {ResourceType} with response null", resourceName);
                }
                if (!response.IsSuccessful)
                {
                    _logger.LogInformation("EpicEhrService.GetMedicationRequestForMRUpdater() failed for " + resourceName + " with Http response code : {Error}", response);
                }
                if (string.IsNullOrEmpty(response.Content))
                {
                    _logger.LogInformation("EpicEhrService.GetMedicationRequestForMRUpdater() failed for {ResourceType} with empty response", resourceName);
                }
                _logger.LogInformation("EpicEhrService.GetMedicationRequestForMRUpdater() execution ended for resource {resource}", resourceName);
                return response.Content;
            }
            catch (Exception ex)
            {
                _logger.LogError("EpicEhrService.GetMedicationRequestForMRUpdater() failed. Exception: {Error}", ex);
                throw;
            }
        }
    }

    public async Task<bool> GetEhrHealth()
    {
        try
        {
            _logger.LogInformation("EpicEhrService.GetEhrHealth() execution started ");

            var token = await _authenticationService.GetToken();
            var url = $"{_configuration.GetValue<string>("EpicBaseURL")}/api/FHIR/R4/Patient/healthcheck";
            var request = new RestRequest(url, Method.Get);
            request.AddHeader("Authorization", $"Bearer {token}");
            request.AddHeader("Accept", "application/json+fhir");
            request.AddParameter("client_id", _configuration.GetValue<string>("EpicClientID"));
            request.AddParameter("grant_type", "client_credentials");

            var response = await _restService.ExecuteRequest(request, "GetEhrHealth");
            _logger.LogInformation("EpicEhrService.GetEhrHealth() execution ended ");
            if (response.IsSuccessStatusCode || response.Content.Contains("resourceType"))
            {
                _logger.LogInformation("EpicEhrService.GetEhrHealth() execution ended ");
                return true;
            }
            else
            {
                _logger.LogCritical("EpicEhrService.GetEhrHealth() failed with status code : {StatusCode}", response.StatusDescription);
                return false;
            }
        }
        catch (Exception ex)
        {
            _logger.LogCritical("EpicEhrService.GetEhrHealth() failed. Exception: {Error}", ex.Message);
            return false;
        }
    }

    public async Task<string> GetEpicResourceById(string resourceFhirId, string resourceName)
    {
        using (LogContext.PushProperty("ResourceFhirId", resourceFhirId))
        {
            try
            {
                _logger.LogInformation("EpicEhrService.GetEpicResource() execution started for {resource} ", resourceName);

                var url = $"{_configuration.GetValue<string>("EpicBaseURL")}/api/FHIR/R4/{resourceName}/{resourceFhirId}";
                var token = await _authenticationService.GetToken();

                var request = new RestRequest(url, Method.Get);
                request.AddHeader("Authorization", $"Bearer {token}");
                request.AddHeader("Accept", "application/json+fhir");
                request.AddParameter("client_id", _configuration.GetValue<string>("EpicClientID"));
                request.AddParameter("grant_type", "client_credentials");

                var response = await _restService.ExecuteRequest(request, "Epic");
                ResponseModel responseModel = new ResponseModel()
                {
                    StatusCode = (int)response.StatusCode,
                    ErrorMessage = response.Content
                };
                if (response.StatusCode != System.Net.HttpStatusCode.OK)
                {
                    _logger.LogError("EpicEhrService.GetEpicResource() : {ResourceType} api call failed");
                    throw new ResponseCustomException(response, responseModel);
                }
                if (response == null)
                {
                    _logger.LogError("EpicEhrService.GetEpicResource() failed for {ResourceType} with response null", resourceName);
                    throw new Exception("EpicEhrService.GetEpicResource() failed for " + resourceName + " with response null");
                }
                if (!response.IsSuccessful)
                {
                    _logger.LogError("EpicEhrService.GetEpicResource() failed for " + resourceName + " with Http response code : {Error}", response);
                    throw new Exception("EpicEhrService.GetEpicResource() failed for " + resourceName + " with failed Http response code");
                }
                if (string.IsNullOrEmpty(response.Content))
                {
                    _logger.LogError("EpicEhrService.GetEpicResource() failed for {ResourceType} with empty response", resourceName);
                    throw new Exception("Epic response is empty for resource" + resourceName);
                }

                _logger.LogInformation("EpicEhrService.GetEpicResource() execution ended for resource {resource}", resourceName);
                return response.Content;
            }
            catch (Exception ex)
            {
                _logger.LogError("EpicEhrService.GetEpicResource() failed. Exception: {Error}", ex);
                throw;
            }
        }
    }

    public async Task<string> GetPatientData(string patientFhirId, string resourceType, EhrFetchType ehrFetchType)
    {
        return ehrFetchType switch
        {
            EhrFetchType.ById => await GetEpicResourceById(patientFhirId, resourceType),
            EhrFetchType.ByPatient => await GetEpicResourceByPatient(patientFhirId, resourceType),
            _ => throw new ArgumentException("Argument is invalid", nameof(ehrFetchType)),
        };
    }
}