﻿using CDOIntegrationService;
using CDOIntegrationService.Refactor;
using CDOIntegrationService.Refactor.Models;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;

namespace UnitTesting_CDO
{
    public class KelseyFhirTests
	{
		private readonly KelseyFhirWrapper _wrapper;
        private readonly Mock<ILogger<KelseyFhirWrapper>> _loggerMock;
		private readonly Mock<IFhirCrudService> _fhirService;
        private readonly Mock<FhirUtils> _fhirUtils;

        public KelseyFhirTests()
		{
			_fhirService = new();
			_loggerMock = new();
            _fhirUtils = new();
            _wrapper = new(_fhirService.Object, _loggerMock.Object, _fhirUtils.Object);
		}
        [Fact]
        public async System.Threading.Tasks.Task KelseyFhirSetBundle_NotNull()
        {
            // Arrange
            var input1 = new PatientRequestModel()
            {
                PatientFhirId = "PIMS-Hypertension-Patient1",
                Identifiers = new()
                {
                    EOW="12345",
                    AssigningAuthority="Epic",
                    CDOID="Kelsey"
                }
            };
            var input2 = new Bundle();
            var input3 = "id";
            var bundle = new Bundle();

            _fhirService.Setup(x => x.UpsertPatientData(It.IsAny<PatientRequestModel>(), It.IsAny<FhirBundleData>())).ReturnsAsync(bundle);
            //_fhirService.Setup(x => x.DeleteEverything(It.IsAny<PatientRequestModel>(), It.IsAny<bool>(), It.IsAny<bool>())).ReturnsAsync(bundle);

            //Act
            var response = await _wrapper.SetBundle(input1, input2, input3);
            Assert.True(response);

        }
        [Fact]
        public async System.Threading.Tasks.Task KelseyFhirSetBundle_Error()
        {
            // Arrange
            var input1 = new PatientRequestModel();
            Bundle? input2 = null;
            var input3 = "";
            var bundle = new Bundle();

            _fhirService.Setup(x => x.UpsertPatientData(It.IsAny<PatientRequestModel>(), It.IsAny<FhirBundleData>())).ReturnsAsync(bundle);
            _fhirService.Setup(x => x.DeleteEverything(It.IsAny<PatientRequestModel>(), It.IsAny<bool>(), It.IsAny<bool>())).ReturnsAsync(bundle);

            //Act
            //var response = await _wrapper.SetBundle(input1, input2, input3);
            var exception = await Record.ExceptionAsync(async () => await _wrapper.SetBundle(input1, input2, input3));
            Assert.IsType<Exception>(exception);
        }

        [Fact]
        public async System.Threading.Tasks.Task KelseyFhirGetPatientEverything_NotNull()
        {
            // Arrange
            var input1 = new PatientRequestModel();

            _fhirService.Setup(x => x.GetPatientEverythingDetails(It.IsAny<PatientRequestModel>())).ReturnsAsync(new Bundle());

            //Act
            var response = await _wrapper.GetPatientRaw(input1);
            Assert.NotNull(response);

        }
    }
}

