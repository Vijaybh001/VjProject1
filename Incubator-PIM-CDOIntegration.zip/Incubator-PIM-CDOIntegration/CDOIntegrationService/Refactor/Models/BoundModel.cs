﻿using System;
namespace CDOIntegrationService.Refactor.Models
{
	public class BoundModel
	{
        public string Start { get; set; }
    }
}
