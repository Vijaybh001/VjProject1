﻿using System;
namespace CDOIntegrationService.Refactor.Models
{
    public class ReferenceModel
    {
        public string Reference { get; set; }
        public string Display { get; set; }
    }
}

