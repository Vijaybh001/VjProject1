﻿using System;
using System.Collections.Generic;
using FhirServiceLibrary;
using Hl7.Fhir.Model;

namespace CDOIntegrationService.Refactor.Models
{
	public class FhirUpsertBody
	{
		public Patient PatientData { get; set; }
		public List<FhirCrudIdentifier> Identifiers { get; set; }
	}
}

