﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.ConfigService;
using CDOIntegrationService.Refactor.DBLayer;
using CDOIntegrationService.Refactor.EHRService.Kelsey;
using CDOIntegrationService.Refactor.Models;
using Hl7.Fhir.Model;
using Hl7.Fhir.Serialization;
using Incubator_OIA_CommonModels;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Serilog.Context;

namespace CDOIntegrationService.Refactor.MedicationRequestStatusUpdate
{
    public class KelseyMedicationRequestStatusUpdate : IMedicationRequestStatusUpdater
    {
        private readonly IConfiguration _config;
        private readonly ICosmosService _cosmosService;
        private readonly IEHRFactory _eHRFactory;
        private readonly ILogger<KelseyMedicationRequestStatusUpdate> _logger;
        private readonly IAzureConfig _azureConfig;

        public KelseyMedicationRequestStatusUpdate(ICosmosService cosmosService, IConfiguration config, IEHRFactory eHRFactory, ILogger<KelseyMedicationRequestStatusUpdate> logger, IAzureConfig azureConfig)
        {
            _cosmosService = cosmosService;
            _config = config;
            _eHRFactory = eHRFactory;
            _logger = logger;
            _azureConfig = azureConfig;
        }

        public async System.Threading.Tasks.Task MedicationRequestStatusUpdater(bool updateForActiveProvider)
        {
            try
            {
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.MedicationRequestStatusUpdater() execution started ");
                int batchSize = _config.GetValue<int>("MRUpdaterBatchSize");
                List<string> activeProviderList = null;
               
                if (updateForActiveProvider)
                {
                    activeProviderList = await _cosmosService.FetchActiveProviders();
                }

                List<CosmosModel.CosmosData> result = await _cosmosService.FetchCosmosRecordWithPendedMedicationRequest(batchSize, activeProviderList, updateForActiveProvider);

                await ProcessCosmosRecords(result);

                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.MedicationRequestStatusUpdater() execution ended ");
            }
            catch (Exception ex)
            {
                _logger.LogError($"MedicationRequestStatusUpdate: CheckMedicationRequestStatus(): An error occurred in CheckMedicationRequestStatus: {ex.Message}");
                throw;
            }
        }

        private async System.Threading.Tasks.Task ProcessCosmosRecords(List<CosmosModel.CosmosData> result)
        {
            _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ProcessCosmosRecords() execution started ");
            foreach (var cosmosData in result)
            {
                if (cosmosData.Orders == null || !cosmosData.Orders.Any())
                {
                    _logger.LogInformation("MedicationRequestStatusUpdate.CheckMedicationRequestStatus(): Skipping CosmosData record due to null or empty Orders. RecordId: {RecordId}", cosmosData.id.Replace(Environment.NewLine, ""));
                    continue;
                }
                using (LogContext.PushProperty("RequestID", cosmosData.id))
                {
                    await ProcessPendedOrderStatus(cosmosData);
                    await UpdateMedicationRequestStatusInCosmos(cosmosData);
                }
            }
            _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ProcessCosmosRecords() execution ended ");
        }

        private async System.Threading.Tasks.Task ProcessPendedOrderStatus(CosmosModel.CosmosData cosmosData)
        {
            _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ProcessPendedOrderStatus() execution started ");
            foreach (var pendedOrder in cosmosData.Orders)
            {
                if (pendedOrder.PendedOrder == null)
                {
                    _logger.LogInformation("MedicationRequestStatusUpdate.ProcessPendedOrderStatus(): Skipping pended order due to null PendedOrder. RecordId: {RecordId}", cosmosData.id.Replace(Environment.NewLine, ""));
                    continue;
                }

                var patientFhirId = cosmosData.Patient?.FHIRID;
                var pendedOrderId = pendedOrder.PendedOrder.PendedOrderId;

                if (string.IsNullOrEmpty(patientFhirId) || string.IsNullOrEmpty(pendedOrderId))
                {
                    _logger.LogInformation("MedicationRequestStatusUpdate.ProcessPendedOrderStatus(): Skipping order due to null or empty PatientFhirId or PendedOrderId. RecordId: {RecordId}", cosmosData.id.Replace(Environment.NewLine, ""));
                    continue;
                }
                using (LogContext.PushProperty("PendedOrderId", pendedOrder.PendedOrder))
                {
                    await ValidatePendedMedicationRequest(cosmosData, patientFhirId, pendedOrderId);
                }
            }
            _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ProcessPendedOrderStatus() execution ended ");
        }

        private async System.Threading.Tasks.Task ValidatePendedMedicationRequest(CosmosModel.CosmosData cosmosData, string patientFhirId, string pendedOrderId)
        {
            _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ValidatePendedMedicationRequest() execution started ");
            var medicationRequest = await GetMedicationsFromEpic(patientFhirId);

            if (medicationRequest != null && medicationRequest.Count > 0)
            {
                var medReq = FindPendedMedicationRequest(pendedOrderId, medicationRequest);
                if (medReq != null)
                {
                    await UpdateMedicationRequestStatus(pendedOrderId, cosmosData, medReq);
                }
                else
                {
                    _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ValidatePendedMedicationRequest(): PendedMedRequest not found");
                }
            }
            _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ValidatePendedMedicationRequest() execution ended ");
        }

        private async Task<List<MedicationRequest>> GetMedicationsFromEpic(string patientFhirId)
        {
            try
            {
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.GetMedicationsFromEpict() execution started ");
                _logger.LogInformation("MedicationRequestStatusUpdate.GetMedicationsFromEpic(): Getting medications from Epic for PatientFhirId: {PatientFhirId} - {DateTime}", patientFhirId.Replace(Environment.NewLine, ""), DateTime.UtcNow);
                var IsMock = _azureConfig.GetValueFromAzureConfig<bool>("IsMock");
                var ehrService = _eHRFactory.GetEHRService(Constants.EPIC, IsMock);

                if (ehrService == null || string.IsNullOrEmpty(patientFhirId))
                {
                    _logger.LogWarning("MedicationRequestStatusUpdate.GetMedicationsFromEpic(): EHR Service or patientFhirId is null for PatientFhirId: {PatientFhirId}", patientFhirId.Replace(Environment.NewLine, ""));
                    return new List<MedicationRequest>();
                }

                //var patientMedReqData = await ehrService.GetMedRequest(patientFhirId);
                var patientMedReqData = await ehrService.GetPatientDataForMRUpdater(patientFhirId, Constants.MEDICATIONREQUEST);
                var fhirData = ParseFhirData(patientMedReqData);

                if (fhirData == null || fhirData.MedRequest == null)
                {
                    _logger.LogWarning("MedicationRequestStatusUpdate.GetMedicationsFromEpic(): FHIR Data or MedRequest is null for PatientFhirId: {PatientFhirId}", patientFhirId.Replace(Environment.NewLine, ""));
                    return new List<MedicationRequest>();
                }

                var medications = new List<MedicationRequest>();

                foreach (var entry in fhirData.MedRequest.Entry)
                {
                    if (entry?.Resource is MedicationRequest medResource)
                    {
                        medications.Add(medResource);
                    }
                }
                _logger.LogInformation("MedicationRequestStatusUpdate.GetMedicationsFromEpic(): Successfully fetched medications from Epic for PatientFhirId: {PatientFhirId} - {DateTime}", patientFhirId.Replace(Environment.NewLine, ""), DateTime.UtcNow);
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.GetMedicationsFromEpict() execution ended ");
                return medications;
            }
            catch (Exception ex)
            {
                _logger.LogWarning($"MedicationRequestStatusUpdate.GetMedicationsFromEpic(): An error occurred in GetMedicationsFromEpic: {ex.Message}");
                return new List<MedicationRequest>();
            }
        }

        private MedicationRequest FindPendedMedicationRequest(string pendedOrderId, List<MedicationRequest> medications)
        {
            try
            {
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.FindPendedMedicationRequest() execution started ");
                _logger.LogInformation("MedicationRequestStatusUpdate: FindPendedMedicationRequest(): Finding pended medication request for PendedOrderId: {PendedOrderId}", pendedOrderId.Replace(Environment.NewLine, ""));
                var validOids = _config.GetValue<string>("ValidOids");
                var oids = validOids.Split(',').Select(s => s.Trim()).ToList();

                if (medications == null)
                {
                    _logger.LogInformation("MedicationRequestStatusUpdate: FindPendedMedicationRequest(): Medications list is null for PendedOrderId: {PendedOrderId}", pendedOrderId.Replace(Environment.NewLine, ""));
                    return null;
                }

                var matchingMedication = medications.FirstOrDefault(medication =>
                    medication?.Identifier?.Any(identifier =>
                        oids.Contains(identifier.System) && identifier.Value == pendedOrderId
                    ) ?? false
                );

                if (matchingMedication != null)
                {
                    _logger.LogInformation("MedicationRequestStatusUpdate: FindPendedMedicationRequest(): Found pended medication request for PendedOrderId: {PendedOrderId}", pendedOrderId.Replace(Environment.NewLine, ""));
                }
                else
                {
                    _logger.LogInformation("MedicationRequestStatusUpdate: FindPendedMedicationRequest(): No matching pended medication request found for PendedOrderId: {PendedOrderId}", pendedOrderId.Replace(Environment.NewLine, ""));
                }
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.FindPendedMedicationRequest() execution ended ");
                return matchingMedication;
            }
            catch (Exception ex)
            {
                _logger.LogError($"MedicationRequestStatusUpdate: FindPendedMedicationRequest(): An error occurred in FindPendedMedicationRequest: {ex.Message}");
                return null;
            }
        }

        private System.Threading.Tasks.Task UpdateMedicationRequestStatus(string pendedOrderId, CosmosModel.CosmosData cosmosRecord, MedicationRequest medicationRequest)
        {
            try
            {
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.UpdateMedicationRequestStatus() execution started ");
                if (cosmosRecord != null)
                {
                    var order = cosmosRecord.Orders?.Find(order => order.PendedOrder?.PendedOrderId == pendedOrderId);

                    if (order != null && order.PendedOrder != null && order.PendedOrder.CurrentMedicationStatus != null)
                    {
                        var currentMedStatus = order.PendedOrder.CurrentMedicationStatus?.Status;

                        if (currentMedStatus == null)
                        {
                            order.PendedOrder.CurrentMedicationStatus.PendedMedicationRequestFhirId = medicationRequest.Id;// TODO null check
                            order.PendedOrder.CurrentMedicationStatus.Status = new CosmosModel.MedicationStatus
                            {
                                CurrentStatus = Constants.COMPLETESTATUS,
                                CurrentDateTime = DateTime.UtcNow
                            };
                        }
                        else
                        {
                            _logger.LogInformation("KelseyMedicationRequestStatusUpdate.UpdateMedicationRequestStatus(): Invalid order record");
                        }
                    }
                }
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.UpdateMedicationRequestStatus() execution ended ");
            }

            catch (Exception ex)
            {
                _logger.LogError($"MedicationRequestStatusUpdate: UpdateMedicationRequestStatus(): An error occurred in UpdateMedicationRequestStatus: {ex.Message}");
                throw;
            }

            return System.Threading.Tasks.Task.CompletedTask;
        }

        private async System.Threading.Tasks.Task UpdateMedicationRequestStatusInCosmos(CosmosModel.CosmosData cosmosRecord)
        {
            _logger.LogInformation("KelseyMedicationRequestStatusUpdate.UpdateMedicationRequestStatusInCosmos() execution started ");
            try
            {
                bool isPreconditionFailed = false;
                do
                {
                    isPreconditionFailed = false;
                    Container container = null;
                    UpsertAsyncResponseModel response = null;
                    if (cosmosRecord != null)
                    {
                        var containerName = _config.GetValue<string>("CosmosDBAuditContainerInboxRefill");
                        var dbName = _config.GetValue<string>("CosmosDBAudit");

                        container = _cosmosService.GetContainer(containerName, dbName);
                        try
                        {
                            response = await _cosmosService.UpdateMedicationRequestStatusForRecord(cosmosRecord, cosmosRecord.CDOName);
                            if (response != null && response.CosmosExceptionType == Constant.CosmosExceptionType.PreconditionFailed)
                            {
                                if (container != null)
                                {
                                    isPreconditionFailed = true;
                                    continue;
                                }
                                throw new Exception("MedicationRequestStatusUpdate : UpdateMedicationRequestStatusInCosmos() : Cosmos Container is null");

                            }
                            _logger.LogInformation("MedicationRequestStatusUpdate: UpdateMedicationRequestStatusInCosmos(): Medication Request Status updated.");
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError("MedicationRequestStatusUpdate: UpdateMedicationRequestStatusInCosmos(): Exception Occurred in Updating MedicationRequestStatus {Exception}", ex);
                            throw;
                        }
                        if (response != null && response.ItemResponse.StatusCode == HttpStatusCode.OK)
                        {
                            _logger.LogInformation("MedicationRequestStatusUpdate : UpdateMedicationRequestStatusInCosmos() : Cosmos Record Updated Successfully");
                        }
                        else
                        {
                            _logger.LogError("MedicationRequestStatusUpdate : UpdateMedicationRequestStatusInCosmos() : Cosmos Record Update Failed ");
                            throw new Exception("MedicationRequestStatusUpdate : UpdateMedicationRequestStatusInCosmos() : Cosmos Record Update Failed");
                        }
                    }
                }
                while (isPreconditionFailed);
            }
            catch (Exception ex)
            {
                _logger.LogError($"MedicationRequestStatusUpdate: UpdateMedicationRequestStatusInCosmos(): An error occurred in UpdateMedicationRequestStatusInCosmos: {ex.Message}");
                throw;
            }

            _logger.LogInformation("KelseyMedicationRequestStatusUpdate.UpdateMedicationRequestStatusInCosmos() execution ended ");
        }

        private FhirData ParseFhirData(string patientMedReqResult)
        {
            try
            {
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ParseFhirData() execution started ");
                var fhirData = new FhirData();
                var parser = new FhirJsonParser();
                if (!string.IsNullOrEmpty(patientMedReqResult))
                {
                    fhirData.MedRequest = parser.Parse<Bundle>(patientMedReqResult);
                }
                else
                {
                    _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ParseFhirData(): patientMedReqResult is empty");
                }
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ParseFhirData() execution ended ");
                return fhirData;
            }
            catch (Exception ex)
            {
                _logger.LogWarning($"MedicationRequestStatusUpdate: ParseFhirData(): An error occurred in ParseFhirData: {ex.Message}");
                throw;
            }
        }
    }
}
