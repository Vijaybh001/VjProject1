﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using System.Net;
using CDOIntegrationService.Refactor.Models;
using FluentValidation;
using Hl7.Fhir.Serialization;
using Serilog.Context;
using Incubator_OIA_CommonModels;
using CDOIntegrationService.Refactor.CustomException;
using static Hl7.Fhir.Model.VerificationResult;
using Hl7.Fhir.Model;
using System.Text.Json;
using YamlDotNet.Serialization;

namespace CDOIntegrationService
{
    public class GetPatientRawResourceHttpTrigger
    {
        private readonly ICdoServiceFactory _cdoFactory;
        private readonly ILogger<GetPatientRawResourceHttpTrigger> _logger;
        private readonly IValidator<PatientRequestModel> _validator;
        public GetPatientRawResourceHttpTrigger(ILogger<GetPatientRawResourceHttpTrigger> log, ICdoServiceFactory cdoFactory, IValidator<PatientRequestModel> validator)
        {
            _cdoFactory = cdoFactory;
            _logger = log;
            _validator = validator;
        }
        [HttpPost]
        [FunctionName("GetPatientRawResource")]
        [OpenApiOperation(operationId: "GetPatientRawResource", tags: new[] { "GetPatientRawResource" })]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(PatientRequestModel), Deprecated = false, Description = "Request", Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string))]
        public async Task<IActionResult> GetPatientRawResource(
                [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] PatientRequestModel req,
                ILogger log)
        {

            try
            {
                if (req == null)
                    throw new ValidationException("RequestBody cannot be empty");

                await _validator.ValidateAndThrowAsync(req);
                using (LogContext.PushProperty("PatientFhirId", req.PatientFhirId))
                using (LogContext.PushProperty("CdoId", req.Identifiers.CDOID))
                {
                    _logger.LogInformation("GetPatientRawResource: execution started");
                    var cdoService = _cdoFactory.GetCdoService(req.Identifiers.CDOID);
                    var resourceData = await cdoService.GetPatientRawResource(req.PatientFhirId, req.ResourceType);

                    var serializer = new FhirJsonSerializer();
                    string jsonPatientData = null;

                    if (resourceData != null)
                        jsonPatientData = serializer.SerializeToString(resourceData);

                    ContentResult result = new()
                    {
                        ContentType = "application/json",
                        Content = jsonPatientData,
                        StatusCode = 200
                    };

                    _logger.LogInformation("GetPatientRawResource: execution finished");

                    return result;
                }
            }
            catch (ValidationException ex)
            {
                _logger.LogError("GetPatientRawResourceHttpTrigger.GetPatientRawResource() failed. Exception: {Error}", ex);
                return new BadRequestObjectResult(new ResponseModel()
                {
                    StatusCode = (int)HttpStatusCode.BadRequest,
                    ErrorMessage = ex.Message
                })
                {
                    StatusCode = (int)HttpStatusCode.BadRequest
                };
            }
            catch (ResponseCustomException ex)
            {
                _logger.LogError("GetPatientRawResourceHttpTrigger.GetPatientRawResource() failed. Exception: {Error}", ex);
                return new BadRequestObjectResult(new GetPatientRawOutputModel()
                {
                    APIStatusCode = new ResponseModel()
                    {
                        StatusCode = ex.CustomObject.StatusCode,
                        ErrorMessage = $"GetPatientRawResourceHttpTrigger.GetPatientRawResource() failed. Exception: {ex.CustomObject.ErrorMessage}"
                    }
                })
                {
                    StatusCode = ex.CustomObject.StatusCode
                };
            }
            catch (Exception ex)
            {
                var obj = new ResponseModel()
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    ErrorMessage = ex.Message
                };
                var result = new OkObjectResult(obj)
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
                _logger.LogError("GetPatientRawResourceHttpTrigger.GetPatientRawResource() failed. Exception: {Error}", ex);
                return result;
            }

        }
    }
}
