﻿using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.Cosmos;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.Models;
using System.Collections.Generic;
using Incubator_OIA_CommonModels;
using static Incubator_OIA_CommonModels.CosmosModel;
using Hl7.Fhir.Utility;
using System.ComponentModel;
using Container = Microsoft.Azure.Cosmos.Container;
using Serilog.Context;
using System.Threading;
using System.Linq;

namespace CDOIntegrationService.Refactor.DBLayer
{
    public class CosmosService : ICosmosService
    {
        private readonly CosmosClient _cosmosClient;
        private readonly IConfiguration _config;
        private readonly ILogger<CosmosService> _logger;

        public CosmosService(CosmosClient cosmosClient, IConfiguration config, ILogger<CosmosService> logger)
        {
            _cosmosClient = cosmosClient;
            _config = config;
            _logger = logger;
        }

        public Container GetContainer(string containerName, string dbName)
        {
            try
            {
                _logger.LogInformation("CosmosService.GetContainer() execution started ");

                if (string.IsNullOrEmpty(containerName) || string.IsNullOrEmpty(dbName))
                    throw new Exception("ContainerName / DBName is empty");

                var container = _cosmosClient.GetContainer(dbName, containerName);
                _logger.LogInformation("CosmosService.GetContainer() execution ended ");

                return container;
            }
            catch (Exception ex)
            {
                _logger.LogError("CdoServiceFactory.GetContainer() failed. Exception: {Error}", ex);
                throw;
            }
        }

        public async Task<ItemResponse<T>> UpdateAsync<T>(Container container, T data, string partitionKey)
        {
            try
            {
                _logger.LogInformation("CosmosService.UpdateAsync() execution started ");

                var upsertResponse = await container.UpsertItemAsync(data, new PartitionKey(partitionKey));

                _logger.LogInformation("CosmosService.UpdateAsync() execution ended ");
                return upsertResponse;
            }
            catch (Exception ex)
            {
                _logger.LogError("CosmosDbService.UpdateAsync() failed. Exception: {Error}", ex);
                throw;
            }
        }

        public async Task<CosmosData> FetchCosmosRecordByQueryParams(string id, string cdoName)
        {
            try
            {
                _logger.LogInformation("CosmosService.FetchCosmosRecordByQueryParams() execution started ");

                var containerName = _config.GetValue<string>("CosmosDBAuditContainerInboxRefill");
                var dbName = _config.GetValue<string>("CosmosDBAudit");

                var container = GetContainer(containerName, dbName);
                var data = await container.ReadItemAsync<CosmosData>(id, new PartitionKey(cdoName));

                _logger.LogInformation("CosmosService.FetchCosmosRecordByQueryParams() execution ended ");
                return data;
            }
            catch (Exception ex)
            {
                _logger.LogError("CosmosService.FetchCosmosRecordByQueryParams() failed. Exception: {Error}", ex);
                throw;
            }
        }

        public async Task<List<CosmosData>> FetchCosmosRecordWithPendedMedicationRequest(int batchSize, List<string> activeProviderList, bool updateForActiveProvider)
        {
            try
            {
                _logger.LogInformation("CosmosService.FetchCosmosRecordWithPendedMedicationRequest() execution started ");

                var containerName = _config.GetValue<string>("CosmosDBAuditContainerInboxRefill");
                var dbName = _config.GetValue<string>("CosmosDBAudit");
                var cdoName = _config.GetValue<string>("PimMessageCollectionCDO");

                var container = GetContainer(containerName, dbName);
                var resultList = new List<CosmosModel.CosmosData>();

                var query = GetPendedMedRequestQuery(activeProviderList, updateForActiveProvider, cdoName, batchSize);

                var iterator = container.GetItemQueryIterator<CosmosModel.CosmosData>(new QueryDefinition(query));

                using (var semaphore = new SemaphoreSlim(_config.GetValue<int>("MRUpdaterThreadLimit")))
                {
                    while (iterator.HasMoreResults)
                    {
                        var response = await iterator.ReadNextAsync();
                        var tasks = new List<Task>();
                        foreach (var item in response)
                        {
                            await semaphore.WaitAsync();
                            var localItem = item;
                            tasks.Add(Task.Run(async () =>
                            {
                                try
                                {
                                    // Update the LastModified field with the current time
                                    localItem.LastModified = DateTime.UtcNow;
                                    await container.UpsertItemAsync(localItem, new PartitionKey(localItem.CDOName));

                                    // Fetch the document individually to get the ETag
                                    _logger.LogInformation("CosmosService.FetchCosmosRecordForActiveProviders(): Fetching record with ID {RecordId} for ETag retrieval", localItem.id.Replace(Environment.NewLine, ""));
                                    var documentResponse = await container.ReadItemAsync<CosmosModel.CosmosData>(localItem.id, new PartitionKey(localItem.CDOName));

                                    localItem.RecordETag = documentResponse.ETag;
                                    lock (resultList)
                                    {
                                        resultList.Add(localItem);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    _logger.LogError("Error processing record with ID {RecordId}: {Error}", localItem.id.Replace(Environment.NewLine, ""), ex);
                                }
                                finally
                                {
                                    semaphore.Release();
                                }
                            }));
                        }

                        await Task.WhenAll(tasks);
                    }
                }
                _logger.LogInformation("CosmosService.FetchCosmosRecordWithPendedMedicationRequest() execution ended ");
                return resultList;
            }
            catch (Exception ex)
            {
                _logger.LogError("CosmosService.FetchCosmosRecordWithPendedMedicationRequest() failed. Exception: {Error}", ex);
                throw;
            }
        }

        private string GetPendedMedRequestQuery(List<string> activeProviderList, bool updateForActiveProvider, string cdoName, int batchSize)
        {
            var baseQuery = "SELECT TOP " + batchSize + " * FROM c " +
                            "WHERE ARRAY_LENGTH(c.Orders) > 0 " +
                            "AND ARRAY_LENGTH(ARRAY (SELECT VALUE 1 FROM o IN c.Orders WHERE o.PendedOrder.CurrentMedicationStatus.Status.CurrentStatus = 'Completed')) != ARRAY_LENGTH(c.Orders) " +
                            "AND EXISTS(SELECT VALUE 1 FROM o IN c.Orders WHERE IS_DEFINED(o.PimODEEngineOutput) AND o.PimODEEngineOutput != null) " +
                            "AND NOT EXISTS(SELECT VALUE 1 FROM o IN c.Orders WHERE IS_DEFINED(o.ProviderDecision) AND o.ProviderDecision != null) " +
                            "AND c.CDOName = '" + cdoName + "' ";

            if (updateForActiveProvider && activeProviderList.Any())
            {
                var providerIdEmpFilter = string.Join(", ", activeProviderList.Select(id => $"'{id}'"));

                return baseQuery +
                       $"AND EXISTS(SELECT VALUE 1 FROM o IN c.Orders WHERE o.PendedOrder.PendAuthProvider.ProviderFhirIdEMP IN ({providerIdEmpFilter})) " +
                       "ORDER BY c._ts";
            }

            return baseQuery + "ORDER BY c._ts";
        }

        public async Task<List<string>> FetchActiveProviders()
        {
            try
            {
                _logger.LogInformation("CosmosService.FetchActiveProviders() execution started");

                var activeProviderContainerName = _config.GetValue<string>("CosmosDBAuditActiveProviderList");
                var dbName = _config.GetValue<string>("CosmosDBAudit");
                var container = GetContainer(activeProviderContainerName, dbName);

                var ProviderLastActiveThresholdHours = _config.GetValue<int>("ProviderLastActiveThresholdHours");
                var durationOffset = DateTime.UtcNow.AddHours(-ProviderLastActiveThresholdHours);

                var activeProviderQuery = new QueryDefinition(
                    "SELECT DISTINCT VALUE p.ProviderFhirIdEmp FROM p WHERE p.LastActive >= @durationOffset")
                    .WithParameter("@durationOffset", durationOffset);

                var activeProviderIdList = new List<string>();
                var activeProviderIterator = container.GetItemQueryIterator<string>(activeProviderQuery);

                while (activeProviderIterator.HasMoreResults)
                {
                    var response = await activeProviderIterator.ReadNextAsync();
                    activeProviderIdList.AddRange(response);
                }

                if (!activeProviderIdList.Any())
                {
                    _logger.LogInformation("No active providers found in the last {ProviderLastActiveThresholdHours} hours.", ProviderLastActiveThresholdHours);
                }

                _logger.LogInformation("CosmosService.FetchActiveProviders() execution ended");
                return activeProviderIdList;
            }
            catch (Exception ex)
            {
                _logger.LogError("CosmosService.FetchActiveProviders() failed. Exception: {Error}", ex);
                throw;
            }
        }

        public async Task<UpsertAsyncResponseModel> UpdateMedicationRequestStatusForRecord(CosmosData cosmosRecord, string partitionKey)
        {
            var upsertAsyncResponseModel = new UpsertAsyncResponseModel();
            try
            {
                _logger.LogInformation("CosmosService.UpdateMedicationRequestStatusForRecord() execution started ");
                var containerName = _config.GetValue<string>("CosmosDBAuditContainerInboxRefill");
                var dbName = _config.GetValue<string>("CosmosDBAudit");

                var container = GetContainer(containerName, dbName);
                var requestOptions = new ItemRequestOptions { IfMatchEtag = cosmosRecord.RecordETag };
                var response = await container.UpsertItemAsync(cosmosRecord, new PartitionKey(partitionKey), requestOptions);
                upsertAsyncResponseModel.ItemResponse = response;

                _logger.LogInformation("CosmosService.UpdateMedicationRequestStatusForRecord() execution ended ");
                return upsertAsyncResponseModel;
            }
            catch (CosmosException ex) when (ex.StatusCode == System.Net.HttpStatusCode.PreconditionFailed)
            {
                _logger.LogError("CosmosService.UpdateMedicationRequestStatusForRecord() : Failed to add the request. Status code: {StatusCode}", ex.StatusCode);
                upsertAsyncResponseModel.CosmosExceptionType = Constant.CosmosExceptionType.PreconditionFailed;
                return upsertAsyncResponseModel;
            }
            catch (Exception ex)
            {
                _logger.LogCritical("CosmosService.UpdateMedicationRequestStatusForRecord() Exception Occured {Exception}", ex);
                throw;
            }
        }

        public async Task<TransactionEOW> GetLastProcessedTime(string cdoName)
        {
            try
            {
                _logger.LogInformation("CosmosService.GetLastProcessedTime() started ");

                var dbName = _config.GetValue<string>("CosmosDBConfigurationDB");
                var containerName = _config.GetValue<string>("CosmosDBConfigurationContainerTaskAggregator");

                var container = GetContainer(containerName, dbName);

                var lastProcRecord = await container.ReadItemAsync<TransactionEOW>(cdoName, new PartitionKey(cdoName));

                _logger.LogInformation("CosmosService.GetLastProcessedTime() ended ");

                return lastProcRecord;
            }

            catch (Exception ex)
            {
                _logger.LogCritical("CosmosService.GetLastProcessedTime() Exception Occured {Exception}", ex);
                throw;
            }
        }

        public async Task AddMessagesToCosmos(OutputMessageCollection outputMessageCollection)
        {
            try
            {
                _logger.LogInformation("CosmosService.AddMessagesToCosmos() started ");

                var containerName = _config.GetValue<string>("CosmosDBAuditContainerInboxRefill");
                var dbName = _config.GetValue<string>("CosmosDBAudit");

                var container = GetContainer(containerName, dbName);
                using (var semaphore = new SemaphoreSlim(_config.GetValue<int>("CDOThreadLimitToAddItemToCosmos")))
                {
                    var tasks = outputMessageCollection.Messages.Select(async element =>
                    {
                        await semaphore.WaitAsync();
                        try
                        {
                            await AddItemToCosmos(container, element, element.CDOName);

                        }
                        finally
                        {
                            semaphore.Release();
                        }
                    });

                    await Task.WhenAll(tasks);

                    _logger.LogInformation("CosmosService.AddMessagesToCosmos() ended ");
                }
            }

            catch (Exception ex)
            {
                _logger.LogError("CosmosService: AddMessagesToCosmos(): Failed to add the records. {Error}", ex);
                throw;
            }
        }

        private async Task AddItemToCosmos<T>(Container container, T item, string partitionKey)
        {
            try
            {
                _logger.LogInformation("CosmosService.AddItemToCosmos() started ");

                await container.CreateItemAsync(item, new PartitionKey(partitionKey));

                _logger.LogInformation("CosmosService.AddItemToCosmos() ended ");
            }

            catch (CosmosException ex) when (ex.StatusCode == System.Net.HttpStatusCode.Conflict)
            {
                _logger.LogError("CosmosService: AddItemToCosmos(): Failed to add the request. {Error}", ex);
            }

            catch (Exception ex)
            {
                _logger.LogError("CosmosService: AddItemToCosmos(): Failed to add the request. {Error}", ex);
                throw;
            }
        }

        public async Task UpdateMaxDateTime(string maxDateString, TransactionEOW lastProcRecord)
        {
            try
            {
                _logger.LogInformation("CosmosService.UpdateMaxDateTime(): started");

                var maxDate = DateTime.Parse(maxDateString);

                lastProcRecord.date = maxDate.ToString("MM/dd/yyyy");
                lastProcRecord.time = maxDate.ToString("HH:mm:ss");

                _logger.LogInformation("CosmosService: UpdateMaxDateTime() : Max Date is: {date}", maxDate);

                var dbName = _config.GetValue<string>("CosmosDBConfigurationDB");
                var containerName = _config.GetValue<string>("CosmosDBConfigurationContainerTaskAggregator");

                var container = GetContainer(containerName, dbName);

                await container.UpsertItemAsync(lastProcRecord, new PartitionKey(lastProcRecord.id));

                _logger.LogInformation("CosmosService.UpdateMaxDateTime(): ended");
            }
            catch (Exception ex)
            {
                _logger.LogError("CosmosService: UpdateMaxDateTime(): exception occured: {Error}", ex);
                throw;
            }
        }
    }
}

