﻿using System;
using Incubator_OIA_CommonModels;
using Newtonsoft.Json;

namespace CDOIntegrationService.Refactor.Models
{
    public class ReturnToProviderOutputModel
    {
        public ResponseModel ApiStatusCode { get; set; }
        public ReturnToProviderResponse ReturnToProviderResponse { get; set; }
    }
    public class ReturnToProviderResponse
    {
        [JsonProperty("eowFwdID")]
        public string EOWFWDID { get; set; }

        [JsonProperty("Status")]
        public string Status { get; set; }
    }
}

