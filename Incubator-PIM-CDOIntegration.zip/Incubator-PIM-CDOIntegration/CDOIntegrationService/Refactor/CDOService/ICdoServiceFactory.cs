namespace CDOIntegrationService;

public interface ICdoServiceFactory
{
    ICdoService GetCdoService(string cdoName);
}