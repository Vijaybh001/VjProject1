﻿using CDOIntegrationService.Refactor.Models;
using System.Collections.Generic;
using Incubator_OIA_CommonModels;

namespace CDOIntegrationService.Refactor.MessageService
{
    public interface IProcessMessageData
	{
        CosmosModel.OutputMessageCollection MapMessageData(List<InputMessage> message, MessageCollectionRequest req);

    }
}

