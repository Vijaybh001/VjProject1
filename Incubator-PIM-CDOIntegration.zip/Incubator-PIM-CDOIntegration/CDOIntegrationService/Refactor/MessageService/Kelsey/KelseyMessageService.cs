using System;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using CDOIntegrationService.Refactor.Models;
using System.Threading.Tasks;
using RestSharp;
using Microsoft.Extensions.Configuration;
using CDOIntegrationService.Refactor.RestLayer.BasicAuthClient;
using Incubator_OIA_CommonModels;
using CDOIntegrationService.Refactor.CustomException;

namespace CDOIntegrationService.Refactor.MessageService;

public class KelseyMessageService: IMessageService
{
    private readonly ILogger<KelseyMessageService> _logger;
    private readonly IProcessMessageData _processMessageData;
    private readonly IConfiguration _config;
    private readonly BasicAuthRestClient _restClient;

    public KelseyMessageService(ILogger<KelseyMessageService> logger, IProcessMessageData processMessageData, IConfiguration configuration, BasicAuthRestClient restClient)
    {
        _logger = logger;
        _processMessageData = processMessageData;
        _config = configuration;
        _restClient = restClient;
    }

    public async Task<CosmosModel.OutputMessageCollection> GetMessages(MessageCollectionRequest req)
    {
        try
        {
            _logger.LogInformation("KelseyMessageService.GetMessages() execution started ");

            var messageCollectionApi = _config.GetValue<string>("EpicMessageCollectionApi");
            CosmosModel.OutputMessageCollection processMessage = new();
            var request = new RestRequest
            {
                Method = Method.Get,
                Resource = messageCollectionApi
            };
            request.AddHeader("Authorization", $"Basic {_config.GetValue<string>("EpicBasicToken")}");
            request.AddQueryParameter("messageTypes", req.MessageTypes);
            request.AddQueryParameter("pools", _config.GetValue<string>("EpicPools"));
            request.AddQueryParameter("statuses", _config.GetValue<string>("EpicStatuses"));
            request.AddQueryParameter("priorities", _config.GetValue<string>("EpicPriorities"));
            request.AddQueryParameter("eowAgeD", req.eowAgeD.ToString("MM/dd/yyyy"));
            request.AddQueryParameter("eowAgeT", req.eowAgeT.ToString("HH:mm:ss"));

            var response = await _restClient.ExecuteRequest(request, "GetMessages Api");

            ResponseModel responseModel = new()
            {
                StatusCode = (int)response.StatusCode,
                ErrorMessage = response.Content
            };
            if (response.IsSuccessStatusCode)
            {
                if (response != null && !string.IsNullOrEmpty(response.Content))
                {
                    var responseData = JsonConvert.DeserializeObject<GetMessagesResponse>(response.Content);
                    if (responseData.Messages != null)
                    {
                        var messageCount = responseData.Messages.Count;
                        _logger.LogInformation("KelseyMessageService : GetMessages() : No of Message received from Messagecollection api {messageCount}", messageCount);
                        processMessage = _processMessageData.MapMessageData(responseData.Messages, req);
                    }
                    else
                    {
                        _logger.LogInformation("KelseyMessageService : GetMessages() : Message collection api Response count is null");
                    }
                }
                else
                {
                    _logger.LogInformation("KelseyMessageService : GetMessages() : Message collection api Response is null");

                }
            }
            else
            {
                _logger.LogError("KelseyMessageService : GetMessages() : Message collection api Failed");
                throw new ResponseCustomException(response, responseModel);
            }
            _logger.LogInformation("KelseyMessageService.GetMessages() execution ended ");

            return processMessage;
        }
        catch (Exception ex)
        {
            _logger.LogCritical("KelseyMessageService : GetMessages() failed. Exception occured: {Error}", ex);
            throw;
        }
    }
}