﻿using System;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using Azure.Core;
using CDOIntegrationService.Refactor.Models;
using Hl7.Fhir.Model;

namespace CDOIntegrationService.Refactor.EHRService.Kelsey
{
    public class KelseyEHRUtils
    {
        private void TrimFhirIdentifier(Bundle bundle, string resourceType)
        {
            if (bundle == null || bundle.Entry == null)
                return;
            foreach (var entry in bundle.Entry)
            {
                if (entry.Resource != null && entry.Resource is not OperationOutcome && !string.IsNullOrEmpty(entry.Resource.Id))
                {
                    if (entry.Resource.Id.Length > Constants.FHIR_ID_LENGTH)
                    {
                        //entry.Resource.Id = Guid.NewGuid().ToString();
                        throw new Exception("Resource ID " + entry.Resource.Id + " length is greater than " + Constants.FHIR_ID_LENGTH + " for Resource: " + resourceType);
                    }
                }
            }
        }
        public void ValidateEpicData(FhirData fhirData)
        {
            try
            {
                if (fhirData == null)
                    throw new Exception("Empty Fhir data");

                if (fhirData.Patient != null && !string.IsNullOrEmpty(fhirData.Patient.Id))
                {
                    if (fhirData.Patient.Id.Length > Constants.FHIR_ID_LENGTH)
                    {
                        //fhirData.Patient.Id = Guid.NewGuid().ToString();
                        throw new Exception("Patient resource ID length is greater than " + Constants.FHIR_ID_LENGTH);
                    }
                }
                TrimFhirIdentifier(fhirData.Appointment, "Appointment");
                TrimFhirIdentifier(fhirData.Condition, "Condition");
                TrimFhirIdentifier(fhirData.Encounter, "Encounter");
                TrimFhirIdentifier(fhirData.MedRequest, "MedicationRequest");
                TrimFhirIdentifier(fhirData.Observation, "Observation");
                TrimFhirIdentifier(fhirData.AllergyIntolerance, "AllergyIntolerance");
                TrimFhirIdentifier(fhirData.Location, "Location");
                TrimFhirIdentifier(fhirData.ServiceRequest, "ServiceRequest");
            }
            catch
            {
                throw;
            }
        }

        public MedicationRequest AddMedicationtoMedrequest(MedicationRequest medRequestResource, Medication medication)
        {
            if (medication.Code != null && medication.Code.Coding != null)
            {
                CodeableConcept ccMedication = new CodeableConcept();

                foreach (var coding in medication.Code.Coding)
                {
                    ccMedication.Coding.Add(new Coding { System = coding.System, Code = coding.Code, Display = coding.Display });
                }
                ccMedication.Text = medication.Code.Text;
                medRequestResource.Medication = ccMedication;
            }
            return medRequestResource;
        }

        public string ConvertToDatetime(string inputDate)
        {
            var datePattern = @"yyyy-MM-ddThh:mm:sszzz";
            return DateTime.Parse(inputDate).ToString(datePattern);
        }

        public List<KeyValuePair<string, string>> GetParams(string resourceType, string patientFhirId)
        {
            var list = new List<KeyValuePair<string, string>>();
            switch (resourceType)
            {
                case "Patient":
                    return list;
                case "Appointment":
                    list.Add(new KeyValuePair<string, string>("patient", patientFhirId));
                    return list;
                case "Condition":
                    list.Add(new KeyValuePair<string, string>("patient", patientFhirId));
                    return list;
                case "Encounter":
                    list.Add(new KeyValuePair<string, string>("patient", patientFhirId));
                    return list;
                case "MedicationRequest":
                    list.Add(new KeyValuePair<string, string>("patient", patientFhirId));
                    return list;
                case "Observation":
                    list.Add(new KeyValuePair<string, string>("patient", patientFhirId));
                    list.Add(new KeyValuePair<string, string>("category", "laboratory,vital-signs"));
                    return list;
                case "AllergyIntolerance":
                    list.Add(new KeyValuePair<string, string>("patient", patientFhirId));
                    return list;
                case "Medication":
                    return list;
                case "Location":
                    return list;
                case "ServiceRequest":
                    return list;
                default:
                    return list;
            }
        }
    }
}

