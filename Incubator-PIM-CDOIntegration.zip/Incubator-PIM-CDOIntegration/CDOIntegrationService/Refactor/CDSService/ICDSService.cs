namespace CDOIntegrationService;

public interface ICDSService
{
    void OrderSign(string patientId);
}