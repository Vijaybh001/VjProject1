﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Configuration;
using System.Net;
using CDOIntegrationService.Refactor.Models;
using Serilog.Context;
using CDOIntegrationService.Refactor;
using static Incubator_OIA_CommonModels.CosmosModel;
using FluentValidation;
using Incubator_OIA_CommonModels;
using CDOIntegrationService.Refactor.CustomException;

namespace CDOIntegrationService
{
    public class SignFinalOrderHttpTrigger
    {
        private readonly ILogger<SignFinalOrderHttpTrigger> _logger;
        private readonly ICdoServiceFactory _cdoFactory;
        private readonly IValidator<OutReachRequest> _validator;
        public SignFinalOrderHttpTrigger(ILogger<SignFinalOrderHttpTrigger> log, IValidator<OutReachRequest> validator, ICdoServiceFactory cdoFactory)
        {
            _logger = log;
            _validator = validator;
            _cdoFactory = cdoFactory;
        }
        [HttpPost]
        [FunctionName("SignFinalOrder")]
        [OpenApiOperation(operationId: "SignFinalOrderHttpTrigger", tags: new[] { "SignFinalOrderHttpTrigger" })]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(OutReachRequest), Deprecated = false, Description = "SignFinalOrder", Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string))]

        public async Task<IActionResult> SignFinalOrder(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] OutReachRequest req, ILogger log)
        {
            using (LogContext.PushProperty("PendedOrderID", req.PendedOrderId))
            {
                try
                {
                    if (req == null)
                        throw new ValidationException("RequestBody cannot be empty");

                    await _validator.ValidateAndThrowAsync(req);
                    using (LogContext.PushProperty("CdoId", req.CDOName))
                    {
                        _logger.LogInformation("SignFinalOrderHttpTrigger : SignFinalOrder() execution started ");
                        var cdoService = _cdoFactory.GetCdoService(req.CDOName);
                        var data = await cdoService.SignFinalOrder(req);
                        SignFinalOrderResponseModel response = new SignFinalOrderResponseModel();
                        if (data.signPendedRefillOrder != null)
                        {
                            response = new SignFinalOrderResponseModel()
                            {
                                APIStatusCode = new ResponseModel
                                {
                                    StatusCode = data.APIStatusCode.StatusCode
                                }
                            };
                        }
                        else
                        {
                            _logger.LogInformation("SignFinalOrderHttpTrigger : SignFinalOrder() SignPendedRefillOrder Response is null");
                        }
                        _logger.LogInformation("SignFinalOrderHttpTrigger : SignFinalOrder() execution ended");
                        return new OkObjectResult(data)
                        {
                            StatusCode = data.APIStatusCode.StatusCode
                        };
                    }
                }
                catch (ResponseCustomException ex)
                {
                    _logger.LogError("SignFinalOrderHttpTrigger.SignFinalOrder() failed. Exception: {Error}", ex);
                    return new BadRequestObjectResult(new SignFinalOrderResponseModel()
                    {
                        APIStatusCode = new ResponseModel()
                        {
                            StatusCode = ex.CustomObject.StatusCode,
                            ErrorMessage = $"SignFinalOrderHttpTrigger.SignFinalOrder() failed. Exception: {ex.CustomObject.ErrorMessage}"
                        }
                    })
                    {
                        StatusCode = ex.CustomObject.StatusCode
                    };
                }
                catch (Exception ex)
                {
                    var obj = new ResponseModel()
                    {
                        StatusCode = (int)HttpStatusCode.InternalServerError,
                        ErrorMessage = $"SignFinalOrderHttpTrigger.SignFinalOrder() failed. Exception: {ex.Message}"
                    };
                    var result = new OkObjectResult(obj)
                    {
                        StatusCode = (int)HttpStatusCode.InternalServerError
                    };
                    _logger.LogCritical("SignFinalOrderHttpTrigger.SignFinalOrder() failed. Exception: {Error}", ex);
                    return result;
                }
            }

        }
    }
}
