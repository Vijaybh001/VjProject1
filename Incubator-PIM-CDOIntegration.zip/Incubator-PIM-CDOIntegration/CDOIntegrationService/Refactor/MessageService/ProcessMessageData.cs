﻿using System;
using CDOIntegrationService.Refactor.Models;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using FluentValidation;
using System.Linq;
using System.Web;
using Serilog.Context;
using Incubator_OIA_CommonModels;
using System.Globalization;
using static Incubator_OIA_CommonModels.CosmosModel;
using Microsoft.Extensions.Configuration;

namespace CDOIntegrationService.Refactor.MessageService
{
    public class ProcessMessageData : IProcessMessageData
    {
        private readonly ILogger<KelseyMessageService> _logger;
        private readonly IValidator<InputMessage> _validator;
        private readonly IValidator<PendedOrders> _validatorOrders;
        private readonly IConfiguration _configuration;

        public ProcessMessageData(ILogger<KelseyMessageService> logger, IValidator<InputMessage> validator, IValidator<PendedOrders> validatorOrders, IConfiguration configuration)
        {
            _logger = logger;
            _validator = validator;
            _validatorOrders = validatorOrders;
            _configuration = configuration;
        }

        public OutputMessageCollection MapMessageData(List<InputMessage> cdoMessageList, MessageCollectionRequest req)
        {
            try
            {
                _logger.LogInformation("ProcessMessageData.MapMessageData() execution started ");

                List<CosmosData> messages = new();
                foreach (var message in FilterMessages(cdoMessageList))
                {
                    if (IsMsgSubmittedInstantParsedSuccessFully(message.MsgSubmittedInstant))
                    {
                        var IsMsgPropertiesValid = IsInputMessageValid(message);

                        using (LogContext.PushProperty("RequestID", message.EOWID + "_" + req.CDOName))
                        {
                            var order = message.PendedOrders.Select(AddOrder);
                            CosmosData tempMsg = new()
                            {
                                id = message.EOWID + "_" + req.CDOName,
                                EOWID = message.EOWID,
                                MessageBody = message.MessageBody,
                                CSN = message.CSN,
                                Status = message.Status,
                                MessageType = message.MessageType,
                                MyChartUserId = message.MCUserID,
                                CDOName = req.CDOName,
                                EhrName = req.EHRName,
                                Patient = message.Patient,
                                PatientTimeZone = message.PatientTimeZone,
                                Messagesource = message.MessageSource,
                                MsgSubmittedInstant = message.MsgSubmittedInstant,
                                IsPregnant = message.IsPregnant,
                                IsBreastFeeding = message.IsBreastFeeding,
                                PatientEmailId = message.PtEmail,
                                PatientCommPref = message.PatientCommPref,
                                AssigningAuthority = "DummyAuthority",
                                DefaultPool = message.DefaultPool,
                                StatusNote = message.StatusNote,
                                IsMessageValid = IsMsgPropertiesValid,
                                IsSetPatientSuccess = null,
                                Orders = order.ToList()
                            };
                            messages.Add(tempMsg);
                        }
                    }
                }
                var messageResponse = new OutputMessageCollection()
                {
                    Messages = messages.OrderBy(x => x.MsgSubmittedInstant).ToList(),
                    MessageCount = messages.Count
                };
                _logger.LogInformation("ProcessMessageData.MapMessageData() execution ended ");
                return messageResponse;
            }
            catch (Exception ex)
            {
                _logger.LogError("ProcessMessageData : ProcessMessage() failed. Exception occured: {Error}", ex);
                throw;
            }
        }

        private bool IsMsgSubmittedInstantParsedSuccessFully(string msgSubmittedInstant)
        {
            if (DateTime.TryParseExact(msgSubmittedInstant, "MM/dd/yyyy HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out _))
            {
                _logger.LogInformation("IsMsgSubmittedInstantParsedSuccessFully : MsgSubmittedInstant Parsed Successfully");
                return true;
            }
            _logger.LogInformation("IsMsgSubmittedInstantParsedSuccessFully : MsgSubmittedInstant is not valid : Parsed unsuccessful");
            return false;
        }

        private Order AddOrder(PendedOrders pendedOrder)
        {
            var IsOrderValid = _validatorOrders.Validate(pendedOrder);
            using (LogContext.PushProperty("PendedOrderID", pendedOrder.ordID))
            {
                _logger.LogInformation("ProcessMessageData.AddOrder() execution started ");
                var OrderData = new Order()
                {
                    IsOrderValid = IsOrderValid.IsValid,
                    PendedOrder = new Pendedorder()
                    {
                        PendedOrderId = pendedOrder.ordID,
                        MedId = pendedOrder.MedID,
                        MedName = pendedOrder.MedName,
                        PharmacyName = pendedOrder.PharmacyName,
                        PtComment = pendedOrder.PtComment,
                        PharmacyAddress = pendedOrder.PharmacyAddress,
                        Dosage = pendedOrder.Dosage,
                        Quantity = pendedOrder.Quantity,
                        ExpireDate = pendedOrder.ExpireDate,
                        Sig = pendedOrder.SIG,
                        SupplyDuration = pendedOrder.SupplyDuration,
                        OrderEncounterCSN = pendedOrder.OrderEncounterCSN,
                        NumRefillsAllowed = pendedOrder.NumRefillsAllowed,
                        DeptSpecialty = pendedOrder.DeptSpecialty,
                        IsSameDept = pendedOrder.IsSameDept,
                        RxNormCode = pendedOrder.RxNormCode,
                        PendAuthProvider = pendedOrder.PendAuthProvider,
                    },
                    ActiveOrder = new ActiveOrder()
                    {
                        ActiveOrderId = pendedOrder.ActiveOrder.OrdId,
                        OrderInstant = pendedOrder.ActiveOrder.OrderInstant,
                        OrderEndDate = pendedOrder.ActiveOrder.OrderEndDate,
                        OrderEndDateGT30Days = pendedOrder.ActiveOrder.OrderEndDateGT30Days,
                        OrderNoOfRefillAllowed = pendedOrder.ActiveOrder.NumRefillsAllowed,
                        SupplyDuration = pendedOrder.ActiveOrder.SupplyDuration,
                        NumRefillsAllowed = pendedOrder.ActiveOrder.NumRefillsAllowed,
                        RxNormCode = pendedOrder.ActiveOrder.RxNormCode,
                        Quantity = pendedOrder.ActiveOrder.Quantity,
                        SIG = pendedOrder.ActiveOrder.SIG,
                        ActiveAuthProvider = pendedOrder.ActiveAuthProvider,
                        ActiveDepartment = pendedOrder.ActiveDepartment
                    }
                };
                return OrderData;
            }
        }

        private bool IsInputMessageValid(InputMessage inputMessage)
        {
            using (LogContext.PushProperty("EOWID", inputMessage.EOWID))
            {
                _logger.LogInformation("ProcessMessageData.IsInputMessageValid() execution started ");
                var validationResp = _validator.Validate(inputMessage);
                if (!validationResp.IsValid)
                {
                    _logger.LogWarning("Message {MessageId} was skipped. Reason: {ErrorMessage}", HttpUtility.HtmlEncode(inputMessage.EOWID), validationResp.ToString());
                    return false;
                }
                _logger.LogInformation("ProcessMessageData.IsInputMessageValid() execution ended ");
                return true;
            }
        }

        private List<InputMessage> FilterMessages(List<InputMessage> cdoMessageList)
        {
            try
            {
                _logger.LogInformation("MessageCollectionTimer.FilterMessages() started ");

                var orderedMessageList = cdoMessageList.OrderBy(x => DateTime.ParseExact(x.MsgSubmittedInstant, "MM/dd/yyyy HH:mm:ss", CultureInfo.InvariantCulture));
                var orderedPreferredList = orderedMessageList.Take(_configuration.GetValue<int>("TAProcessMessageLimit")).ToList();
                var lastInstantTimeString = orderedPreferredList.LastOrDefault()?.MsgSubmittedInstant;

                if (lastInstantTimeString != null)
                {
                    DateTime lastInstantTime = DateTime.ParseExact(lastInstantTimeString, "MM/dd/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                    var filteredList = orderedMessageList.Skip(_configuration.GetValue<int>("TAProcessMessageLimit")).Where(x => DateTime.ParseExact(x.MsgSubmittedInstant, "MM/dd/yyyy HH:mm:ss", CultureInfo.InvariantCulture) == lastInstantTime).ToList();
                    orderedPreferredList.AddRange(filteredList);
                }
                else
                {
                    _logger.LogCritical("MessageCollectionTimer : FilterMessages() : lastInstantTimeString is null");
                }

                if (orderedPreferredList.Any())
                {
                    _logger.LogInformation("MessageCollectionTimer : FilterMessages() : sorted messages count : {SortedMessageCount}", orderedPreferredList.Count);

                    string CommaSeparatedSortedMessageListString = string.Join(',', orderedPreferredList.Select(x => x.EOWID));
                    _logger.LogInformation("MessageCollectionTimer : ProcessMessages() : sorted messages from message collection batch : {CommaSeparatedSortedMessageListString}", CommaSeparatedSortedMessageListString);
                }
                else
                {
                    _logger.LogInformation("MessageCollectionTimer : FilterMessages() : No records to process");
                }

                return orderedPreferredList;
            }

            catch (Exception ex)
            {
                _logger.LogError("MessageCollectionTimer.FilterMessages() failed. {Error}", ex);
                throw;
            }
        }
    }
}
