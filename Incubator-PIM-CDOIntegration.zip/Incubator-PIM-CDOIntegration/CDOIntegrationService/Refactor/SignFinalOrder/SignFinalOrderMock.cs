﻿using System;
using System.IO;
using System.Net;
using System.Reflection;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.MessageService;
using CDOIntegrationService.Refactor.Models;
using Incubator_OIA_CommonModels;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using static Incubator_OIA_CommonModels.CosmosModel;

namespace CDOIntegrationService.Refactor.SignFinalOrder
{
	public class SignFinalOrderMock : ISignFinalOrder
	{
        private readonly ILogger<SignFinalOrderMock> _logger;
        private readonly IBlobServices _blobServices;
        private readonly IProcessMessageData _processMessageData;
        public SignFinalOrderMock(ILogger<SignFinalOrderMock> logger, IBlobServices blobServices, IProcessMessageData processMessageData)
        {
            _logger = logger;
            _blobServices = blobServices;
            _processMessageData = processMessageData;
        }
        public Task<SignFinalOrderResponseModel> SignOrder(OutReachRequest req)
        {
            //TODO: This async method lacks 'await' operators and will run synchronously.
            try
            {
                _logger.LogInformation("SignFinalOrderMock.SignOrder() execution started ");
                var binDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                var rootDirectory = Path.GetFullPath(Path.Combine(binDirectory, ".."));
                var path = File.ReadAllText(rootDirectory + "/MockData/signfinalOrderMock.json");

                var responseData = JsonConvert.DeserializeObject<Models.SignPendedRefillOrder>(path);
                responseData.OIARetOrdID = req.PendedOrderId;
                responseData.eowID = req.EOWID;
                responseData.refillNumRefills = req.NoOfRefill.ToString();
                _logger.LogInformation("SignFinalOrderMock.SignOrder() execution ended ");
                return Task.FromResult(new SignFinalOrderResponseModel
                {
                    APIStatusCode = new ResponseModel
                    {
                        StatusCode = (int)HttpStatusCode.OK
                    },
                    signPendedRefillOrder = responseData
                });
            }
            catch (Exception ex)
            {
                _logger.LogError("SignFinalOrderMock.SignOrder() failed. Exception: {Error}", ex);
                throw;
            }
        }
    }
}

 