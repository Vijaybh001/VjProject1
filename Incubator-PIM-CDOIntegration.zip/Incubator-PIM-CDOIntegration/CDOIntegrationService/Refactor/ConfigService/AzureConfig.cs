﻿using System;
using System.Threading.Tasks;
using Azure.Core;
using Azure.Identity;
using CDOIntegrationService.Refactor.ConfigService;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;

namespace CDOIntegrationService.Refactor.AzureConfig
{
	public class AzureConfig : IAzureConfig
    {
        private IConfiguration config { get; set; }

        public T GetValueFromAzureConfig<T>(string key)
        {
            var _configuration = new ConfigurationBuilder()
                .SetBasePath(Environment.CurrentDirectory)
                .AddJsonFile("local.settings.json", true)
                .AddEnvironmentVariables()
                .Build();

            var env = _configuration["CurrentEnvironment"];
            var builder = new ConfigurationBuilder();
#if DEBUG

            var tenantId = _configuration["TENANT_ID"];
            var clientId = _configuration["CLIENT_ID"];
            var clientSecret = _configuration["CLIENT_SECRET"];

            TokenCredential servicePrincipal = new ClientSecretCredential(tenantId, clientId, clientSecret);

            config = builder.AddAzureAppConfiguration(options =>
            {

                options.Connect(new(_configuration["AZConfigEndpoint"].ToString()), servicePrincipal)
                    .Select(KeyFilter.Any, LabelFilter.Null)
                    .Select(KeyFilter.Any, env);
                options.ConfigureKeyVault(vault =>
                {
                    vault.SetCredential(servicePrincipal);
                });

            }).Build();

#else
            config = builder.AddAzureAppConfiguration(options =>
                {
                    options.Connect(new Uri(_configuration["AZConfigEndpoint"]), new ManagedIdentityCredential())
                    .Select(KeyFilter.Any, LabelFilter.Null)
                    .Select(KeyFilter.Any, env);
                    options.ConfigureKeyVault(vault =>
                    {
                        vault.SetCredential(new DefaultAzureCredential());
                    });
                }).Build();
#endif
            return config.GetValue<T>(key);
        }
    }
}

