﻿using Incubator_OIA_CommonModels;
using Microsoft.Azure.Cosmos;

namespace CDOIntegrationService.Refactor.Models
{
    public class UpsertAsyncResponseModel
    {
        public ItemResponse<CosmosModel.CosmosData> ItemResponse { get; set; }
        public Constant.CosmosExceptionType CosmosExceptionType { get; set; }
    }
}

