using System;
using CDOIntegrationService.Refactor;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace CDOIntegrationService;

public class CdoServiceFactory : ICdoServiceFactory
{
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<CdoServiceFactory> _logger;

    public CdoServiceFactory(IServiceProvider serviceProvider, ILogger<CdoServiceFactory> logger)
    {
        _serviceProvider = serviceProvider;
        _logger = logger;
    }
    
    public ICdoService GetCdoService(string cdoName)
    {
        _logger.LogInformation("CdoServiceFactory.GetCdoService() execution started ");
        _logger.LogInformation("CdoServiceFactory.GetCdoService() execution ended ");
        return cdoName switch
        {
            Constants.KELSEY => _serviceProvider.GetService<KelseyCdoService>(),
            _ => throw new Exception("Invalid CDO Type"),
        };
    }
}