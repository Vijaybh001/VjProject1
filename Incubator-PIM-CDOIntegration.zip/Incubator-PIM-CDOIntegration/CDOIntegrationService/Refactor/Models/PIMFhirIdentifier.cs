﻿using System;
namespace CDOIntegrationService.Refactor.Models
{
	public class PIMFhirIdentifier
	{
		public string EOW { get; set; }
		public string CDOID { get; set; }
#nullable enable
		public string? AssigningAuthority { get; set; }
	}
}

