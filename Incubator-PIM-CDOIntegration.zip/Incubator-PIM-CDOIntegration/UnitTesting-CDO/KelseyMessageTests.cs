﻿using System;
using System.Reflection;
using CDOIntegrationService;
using CDOIntegrationService.Refactor.CDOService.Kelsey;
using CDOIntegrationService.Refactor.DBLayer;
using CDOIntegrationService.Refactor.Flex;
using CDOIntegrationService.Refactor.MessageService;
using CDOIntegrationService.Refactor.Models;
using CDOIntegrationService.Refactor.MyChartService;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using Incubator_OIA_CommonModels;
using CDOIntegrationService.Refactor.ConfigService;

namespace UnitTesting_CDO
{
    public class KelseyMessageTests
    {
        private readonly Mock<IMessageService> _messageService;
        private readonly Mock<ILogger<KelseyCdoService>> _logger;
        private readonly IConfiguration _config;
        private readonly KelseyCdoService _cdoService;
        private readonly Mock<ICdoFactory> _cdoFactory;
        private readonly Mock<ICosmosService> _cosmosService;
        private readonly Mock<IFlexService> _flexMock;
        private readonly Mock<ISendMyChartMessage> _myChartMock;
        private readonly Mock<KelseyUtils> _kelseyUtils;
        private readonly Mock<IAzureConfig> _azureConfig;

        public KelseyMessageTests()
        {
            _messageService = new();
            _logger = new();
            _config = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string>
            {
                { "isMock", "True"}
            }).Build();
            _cdoFactory = new();
            _cosmosService = new();
            _flexMock = new();
            _kelseyUtils = new();
            _azureConfig = new Mock<IAzureConfig>();
            _myChartMock = new Mock<ISendMyChartMessage>();
            //_cdoFactory.Setup(x => x.GetCdsService(It.IsAny<string>())).Returns(new Mock<EpicCDSService>().Object);
            //_cdoFactory.Setup(x => x.GetEhrWrapperService(It.IsAny<string>())).Returns(new Mock<KelseyEHRWrapper>().Object);
            _cdoFactory.Setup(x => x.GetMessageService(It.IsAny<string>(), It.IsAny<bool>())).Returns(_messageService.Object);
            //_cdoFactory.Setup(x => x.GetFhirWrapperService(It.IsAny<string>())).Returns(new Mock<KelseyFhirWrapper>().Object);
            _cdoService = new(_config, _logger.Object, _cdoFactory.Object, _cosmosService.Object, _flexMock.Object, _kelseyUtils.Object, _myChartMock.Object, _azureConfig.Object);
        }
        //TODO:Fix UT
        [Fact]
        public async Task KelseyCdo_GetMessages_NotNull()
        {
            //Arrange
            var input = new MessageCollectionRequest();
            //_cdoIntegration = new KelseyCdoService(_configuration.Object, _loggerMock.Object, _cdoFactory.Object, _cosmosService.Object);
            _messageService.Setup(x => x.GetMessages(It.IsAny<MessageCollectionRequest>())).ReturnsAsync(new CosmosModel.OutputMessageCollection());
            _azureConfig.Setup(x=>x.GetValueFromAzureConfig<bool>(It.IsAny<String>())).Returns(true);

            //Act
            var response = await _cdoService.GetMessages(input);

            //Assert
            Assert.NotNull(response);
        }
    }
}