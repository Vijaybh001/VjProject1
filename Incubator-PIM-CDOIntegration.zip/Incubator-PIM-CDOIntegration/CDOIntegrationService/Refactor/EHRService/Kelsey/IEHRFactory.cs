﻿using System;
namespace CDOIntegrationService.Refactor.EHRService.Kelsey
{
	public interface IEHRFactory
	{
		IEHRService GetEHRService(string serviceName, bool isMock);
	}
}

