using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.Models;
using AzureFhirFramework.RestClientWrapper;
using AzureFhirFramework.RestClientWrapper.RestPolicy;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using RestSharp;

namespace CDOIntegrationService.Refactor.Authentication;

public class EpicAuthentication: IAuthentication
{
    private readonly IConfiguration _configuration;
    private readonly ILogger<EpicAuthentication> _logger;
    private readonly IRestClientWrapper _restService;
    private readonly IMemoryCache _cache;

    public EpicAuthentication(IConfiguration config, ILogger<EpicAuthentication> logger, IRestClientWrapper restClientWrapper, IMemoryCache memoryCache)
    {
        _configuration = config;
        _logger = logger;
        _restService = restClientWrapper;
        _cache = memoryCache;
    }
    private async Task<EpicToken> CreateEpicToken()
    {
        try
        {
            _logger.LogInformation("EpicAuthentication.CreateEpicToken() execution started ");
            var url = $"{_configuration.GetValue<string>("EpicBaseURL")}/oauth2/token";
            var request = new RestRequest(url, Method.Post);
            request.AddParameter("response_type", "code");
            request.AddParameter("client_id", _configuration.GetValue<string>("EpicClientID"));
            request.AddParameter("grant_type", "client_credentials");
            request.AddParameter("client_assertion_type", "urn:ietf:params:oauth:client-assertion-type:jwt-bearer");
            request.AddParameter("client_assertion", CreateJWT());

            var response = await _restService.ExecuteRequest(request, "EpicToken");
            if (!response.IsSuccessful)
                throw new Exception(response.Content);
            if (string.IsNullOrEmpty(response.Content))
                throw new Exception("Epic Token Response is empty");

            var tokenObj = JsonConvert.DeserializeObject<EpicToken>(response.Content);
            _logger.LogInformation("EpicAuthentication.CreateEpicToken() execution ended ");
            return tokenObj;
        }
        catch (Exception ex)
        {
            _logger.LogError("EpicAuthentication.CreateEpicToken() failed. Exception: {Error}", ex);
            throw;
        }
    }
    private string CreateJWT()
    {
        try
        {
            _logger.LogInformation("EpicAuthentication.CreateJWT() execution started ");
            var privateKey = _configuration.GetValue<string>("EpicRSAPrivateKey");
            Regex privateKeyRegex = new(@"-----(BEGIN|END) PRIVATE KEY-----[\W]*");
            privateKey = privateKeyRegex.Replace(privateKey, "");
            var newPrivateKey = Convert.FromBase64String(privateKey);

            using RSA rsa = RSA.Create();
            rsa.ImportPkcs8PrivateKey(newPrivateKey, out _);

            var signingCredentials = new SigningCredentials(new RsaSecurityKey(rsa), SecurityAlgorithms.RsaSha256)
            {
                CryptoProviderFactory = new CryptoProviderFactory { CacheSignatureProviders = false }
            };

            var unixTimeSeconds = new DateTimeOffset(DateTime.Now.AddSeconds(240)).ToUnixTimeSeconds();
            var jwt = new JwtSecurityToken(
            claims: new Claim[] {
                        new Claim(JwtRegisteredClaimNames.Iss, _configuration.GetValue<string>("EpicClientID")),
                new Claim(JwtRegisteredClaimNames.Sub, _configuration.GetValue<string>("EpicClientID")),
                        new Claim(JwtRegisteredClaimNames.Exp, unixTimeSeconds.ToString(), ClaimValueTypes.Integer64),
                        new Claim(JwtRegisteredClaimNames.Aud, $"{_configuration.GetValue<string>("EpicBaseURL")}/oauth2/token"),
                        new Claim(JwtRegisteredClaimNames.Jti, System.Guid.NewGuid().ToString())
                },
                signingCredentials: signingCredentials
            );

            string token = new JwtSecurityTokenHandler().WriteToken(jwt);
            _logger.LogInformation("EpicAuthentication.CreateJWT() execution ended ");
            return token;
        }
        catch (Exception ex)
        {
            _logger.LogError("EpicAuthentication.CreateJWT() failed. Exception: {Error}", ex);
            throw;
        }
    }

    public void RefreshToken()
    {
        _logger.LogInformation("EpicAuthentication.RefreshToken() execution started ");
        _logger.LogInformation("EpicAuthentication.RefreshToken() execution ended ");
    }

    public async Task<string> GetToken()
    {
        try
        {
            _logger.LogInformation("EpicAuthentication.GetToken() execution started ");
            if (!_cache.TryGetValue("EpicToken", out string token))
            {
                var tokenObj = await CreateEpicToken();
                if (string.IsNullOrEmpty(tokenObj.access_token))
                    throw new Exception("Epic Token is empty");
                var cacheOptions = new MemoryCacheEntryOptions()
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(tokenObj.expires_in)
                };
                token = tokenObj.access_token;
                _cache.Set("EpicToken", token, cacheOptions);
            }
            _logger.LogInformation("EpicAuthentication.GetToken() execution ended ");
            return token;
        }
        catch(Exception ex)
        {
            _logger.LogError("EpicAuthentication.GetToken() failed. Exception: {Error}", ex);
            throw;
        }
    }
}
