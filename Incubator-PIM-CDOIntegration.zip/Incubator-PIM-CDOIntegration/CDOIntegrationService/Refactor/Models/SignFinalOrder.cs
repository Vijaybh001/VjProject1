﻿using System;
using Incubator_OIA_CommonModels;

namespace CDOIntegrationService.Refactor.Models
{
    public class SignPendedRefillOrder
    {
        public string OIARetOrdID { get; set; }
        public string Status { get; set; }
        public string ordSignedStatus { get; set; }
        public string actOrdStatus { get; set; }
        public string eowID { get; set; }
        public string eowStatus { get; set; }
        public string refillEncID { get; set; }
        public string refillEncStatus { get; set; }
        public string refillSIG { get; set; }
        public string refillNumRefills { get; set; }
    }
    public class SignFinalOrderResponseModel
    {
        public ResponseModel APIStatusCode { get; set; }
        public SignPendedRefillOrder signPendedRefillOrder { get; set; }
    }
}

