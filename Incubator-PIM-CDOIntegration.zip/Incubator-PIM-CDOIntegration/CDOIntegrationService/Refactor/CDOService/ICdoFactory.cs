using CDOIntegrationService.Refactor.MedicationRequestStatusUpdate;
using CDOIntegrationService.Refactor.MessageService;
using CDOIntegrationService.Refactor.Models;
using CDOIntegrationService.Refactor.MyChartService;
using CDOIntegrationService.Refactor.ReturnToProvider;
using CDOIntegrationService.Refactor.SchedulingTicketService;
using CDOIntegrationService.Refactor.SignFinalOrder;

namespace CDOIntegrationService;

public interface ICdoFactory
{
    IEHRWrapper GetEhrWrapperService(string CdoName);
    IFhirWrapper GetFhirWrapperService(string CdoName);
    IMedicationRequestStatusUpdater GetMedicationRequestUpdateWrapperService(string CdoName);
    ICheckMedicationRequestStatus CheckMedicationRequestStatusWrapperService(string CdoName);
    ICDSService GetCdsService(string CdoName);
    IMessageService GetMessageService(string CdoName, bool isMock);
    IProcessSchedulingTicket processSchedulingTicket(SchedulingTicketRequestModel req, string cdoName);
    ISendRecommendation sendRecommendation(string CdoName, bool isMock);
    ISendMyChartMessage SendMyChartMessage(string CdoName, bool isMock);
    ISignFinalOrder GetSignFinalOrder(string CdoName, bool isMock);
}