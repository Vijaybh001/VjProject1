﻿using System;
using System.Collections.Generic;

namespace CDOIntegrationService.Refactor.Models
{
    public class APIStatus
    {
        public string StatusCode { get; set; }
        public string Status { get; set; }
        public string StatusMessage { get; set; }
    }

    public class MkoPatientMessageResponseModel
	{
        public APIStatus APIStatus { get; set; }
    }
}

