﻿using System;
using Hl7.Fhir.Model;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Configuration;
using CDOIntegrationService.Refactor.DBLayer;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using System.Globalization;
using System.Collections;
using Serilog.Context;

namespace CDOIntegrationService
{
    public class FhirResourceConverter : IFhirResourceConverter
    {
        private readonly IConfiguration _config;
        private readonly ILogger<FhirResourceConverter> _logger;

        public FhirResourceConverter(IConfiguration config, ILogger<FhirResourceConverter> logger)
        {
            _config = config;
            _logger = logger;
        }


        public Bundle ConvertAppointmentToEncounter(Bundle appointmentBundle, Bundle encounterBundle)
        {
            _logger.LogInformation("FhirResourceConverter.ConvertAppointmentToEncounter() execution started ");
            foreach (var entry in appointmentBundle.Entry)
            {
                if (entry.Resource is Appointment appointmentResource)
                {
                    _logger.LogInformation("FhirResourceConverter.ConvertAppointmentToEncounter() Appointment resource found for AppointmentID: {0}  and Appointment Start: {1}",  appointmentResource.Id, appointmentResource.Start);
                    var todaysDate = DateTime.UtcNow;//TODO: Get the time zone from config rather then doing utc now
                    var futureDate = todaysDate.AddDays(Convert.ToInt16(_config.GetValue<string>("ApptToEncPeriod")));
                    if (appointmentResource.Start >= todaysDate && appointmentResource.Start <= futureDate)
                    {
                        var encounter = ConvertToEncounter(appointmentResource);
                        encounterBundle.AddResourceEntry(encounter, _config.GetValue<string>("PimFhirServerUrl") + "/Encounter/" + encounter.Id);
                        _logger.LogInformation("FhirResourceConverter.ConvertAppointmentToEncounter() Appointment converted to Encounter for AppointmentID: {0}  and Appointment Start: {1}",  appointmentResource.Id, appointmentResource.Start);
                    }
                    else
                    {
                        _logger.LogInformation("FhirResourceConverter.ConvertAppointmentToEncounter() Appointment doesn't need to be converted to Encounter for AppointmentID: {0}  and Appointment Start: {1}", appointmentResource.Id, appointmentResource.Start);
                    }
                }
            }
            _logger.LogInformation("FhirResourceConverter.ConvertAppointmentToEncounter() execution ended ");
            return encounterBundle;
        }

        private Encounter ConvertToEncounter(Appointment appointment)
        {
            using (LogContext.PushProperty("AppointmentId", appointment.Id))
            {
                _logger.LogInformation("FhirResourceConverter.ConvertToEncounter() execution started ");
                var encounterResource = new Encounter();
                encounterResource.Id = "ae" + appointment.Id;
                encounterResource.Identifier = appointment.Identifier;
                encounterResource.Participant = ConvertParticipant(appointment.Participant, "Practitioner/");
                encounterResource.Period = MapPeriod(appointment, "Practitioner/");
                encounterResource.Subject = ConvertSubject(appointment.Participant, "Patient/");
                encounterResource.Location = ConvertLocation(appointment.Participant, "Location/");
                encounterResource.Status = MapStatuses(appointment.Status);
                encounterResource.Class = CreateClass();
                encounterResource.Type = CreateType();
                _logger.LogInformation("FhirResourceConverter.ConvertToEncounter() execution ended ");
                return encounterResource;
            }
        }

        private List<Encounter.ParticipantComponent> ConvertParticipant(List<Appointment.ParticipantComponent> participants, string actorReferenceType)
        {
            try
            {
                _logger.LogInformation("FhirResourceConverter.ConvertParticipant() execution started ");
                var apptPractitioner = participants.FirstOrDefault(x => x.Actor.Reference != null && x.Actor.Reference.Contains(actorReferenceType));
                if (apptPractitioner == null)
                {
                    throw new Exception("Participant.Actor.reference is null");
                }
                var encParticipantList = new List<Encounter.ParticipantComponent>();
                encParticipantList.Add(new Encounter.ParticipantComponent()
                {
                    Individual = apptPractitioner.Actor,
                    Period = apptPractitioner.Period,
                    Type = apptPractitioner.Type
                });
                _logger.LogInformation("FhirResourceConverter.ConvertParticipant() execution ended ");
                return encParticipantList;
            }
            catch (Exception ex)
            {
                _logger.LogError("FhirResourceConverter.ConvertParticipant() execution failed with exception: {error}", ex);
                return null;
            }
        }

        private Period MapPeriod(Appointment appointment, string actorReferenceType)
        {
            try
            {
                _logger.LogInformation("FhirResourceConverter.MapPeriod() execution started ");
                var apptPractitioner = appointment.Participant.FirstOrDefault(x => x.Actor.Reference != null && x.Actor.Reference.Contains(actorReferenceType));
                if (apptPractitioner == null)
                {
                    throw new Exception("Participant.Actor.reference is null");
                }
                var targetPeriod = apptPractitioner.Period;

                //var targetPeriod = new Period()
                //{
                //    Start = appointment.Start.ToString(),
                //    End = appointment.End.ToString()
                //};
                _logger.LogInformation("FhirResourceConverter.MapPeriod() execution ended ");
                return targetPeriod;
            }
            catch (Exception ex)
            {
                _logger.LogError("FhirResourceConverter.MapPeriod() execution failed with exception: {error}", ex);
                return null;
            }
        }

        private ResourceReference ConvertSubject(List<Appointment.ParticipantComponent> participants, string actorReferenceType)
        {
            try
            {
                _logger.LogInformation("FhirResourceConverter.ConvertSubject() execution started ");
                var participant = participants.FirstOrDefault(x => x.Actor.Reference != null && x.Actor.Reference.Contains(actorReferenceType));
                if (participant == null)
                {
                    throw new Exception("Participant.Actor.reference is null");
                }
                var obj = new ResourceReference()
                {
                    Reference = participant.Actor.Reference,
                    Display = participant.Actor.Display
                };
                _logger.LogInformation("FhirResourceConverter.ConvertSubject() execution ended ");
                return obj;
            }
            catch (Exception ex)
            {
                _logger.LogError("FhirResourceConverter.ConvertSubject() execution failed with exception: {error}", ex);
                throw;
            }
        }

        private List<Encounter.LocationComponent> ConvertLocation(List<Appointment.ParticipantComponent> participants, string actorReferenceType)
        {
            try
            {
                _logger.LogInformation("FhirResourceConverter.ConvertLocation() execution started ");
                var participant = participants.FirstOrDefault(x => x.Actor.Reference != null && x.Actor.Reference.Contains(actorReferenceType));
                if (participant == null)
                {
                    throw new Exception("Participant.Actor.reference is null");
                }
                var objList = new List<Encounter.LocationComponent>();
                objList.Add(new Encounter.LocationComponent
                {
                    Location = new ResourceReference()
                    {
                        Reference = participant.Actor.Reference,
                        Display = participant.Actor.Display
                    }
                });
                _logger.LogInformation("FhirResourceConverter.ConvertLocation() execution ended ");
                return objList;
            }
            catch (Exception ex)
            {
                _logger.LogError("FhirResourceConverter.ConvertLocation() execution failed with exception: {error}", ex);
                throw;
            }
        }

        private Encounter.EncounterStatus MapStatuses(Appointment.AppointmentStatus? status)
        {
            switch (status)
            {
                case Appointment.AppointmentStatus.Proposed:
                    return Encounter.EncounterStatus.Planned;
                case Appointment.AppointmentStatus.Pending:
                    return Encounter.EncounterStatus.Planned;
                case Appointment.AppointmentStatus.Booked:
                    return Encounter.EncounterStatus.Planned;
                case Appointment.AppointmentStatus.Arrived:
                    return Encounter.EncounterStatus.InProgress;
                case Appointment.AppointmentStatus.Fulfilled:
                    return Encounter.EncounterStatus.Finished;
                case Appointment.AppointmentStatus.Cancelled:
                    return Encounter.EncounterStatus.Cancelled;
                case Appointment.AppointmentStatus.Noshow:
                    return Encounter.EncounterStatus.Cancelled;
                case Appointment.AppointmentStatus.EnteredInError:
                    return Encounter.EncounterStatus.EnteredInError;
                case Appointment.AppointmentStatus.CheckedIn:
                    return Encounter.EncounterStatus.InProgress;
                case Appointment.AppointmentStatus.Waitlist:
                    return Encounter.EncounterStatus.Unknown;
                default:
                    return Encounter.EncounterStatus.Unknown;
            }

        }


        private Coding CreateClass()
        {
            _logger.LogInformation("FhirResourceConverter.CreateClass() execution started ");
            var targetCoding = new Coding()
            {
                System = "urn:oid:1.2.840.114350.1.72.1.7.7.10.696784.13260",
                Code = "5",
                Display = "Appointment"
            };
            _logger.LogInformation("FhirResourceConverter.CreateClass() execution ended ");
            return targetCoding;
        }

        private List<CodeableConcept> CreateType()
        {
            _logger.LogInformation("FhirResourceConverter.CreateType() execution started ");
            var codingList = new List<Coding>();
            codingList.Add(new Coding()
            {
                System = "urn:oid:1.2.840.114350.1.13.131.3.7.10.698084.30",
                Code = "50",
                Display = "Appointment"
            });

            var targetCodeableConceptList = new List<CodeableConcept>();
            targetCodeableConceptList.Add(new CodeableConcept()
            {
                Coding = codingList,
                Text = "Appointment"
            });
            _logger.LogInformation("FhirResourceConverter.CreateType() execution ended ");
            return targetCodeableConceptList;
        }
    }
}

