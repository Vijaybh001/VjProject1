﻿using System;
using CDOIntegrationService.Refactor.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net;
using System.Threading.Tasks;
using Serilog.Context;
using FluentValidation;
using Incubator_OIA_CommonModels;
using CDOIntegrationService.Refactor.CustomException;

namespace CDOIntegrationService.Triggers
{
    public class SendRecommendationToProvider
    {
        private readonly ICdoServiceFactory _cdoFactory;
        private readonly ILogger<SendRecommendationToProvider> _logger;
        private readonly IValidator<RecommendationInputModel> _validator;
        public SendRecommendationToProvider(ILogger<SendRecommendationToProvider> log, ICdoServiceFactory cdoFactory, IValidator<RecommendationInputModel> validator)
        {
            _cdoFactory = cdoFactory;
            _logger = log;
            _validator = validator;
        }

        [HttpPost]
        [FunctionName("SendRecommendationToProviderHttpTrigger")]
        [OpenApiOperation(operationId: "SendRecommendationToProvider", tags: new[] { "SendRecommendationToProvider" })]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(RecommendationInputModel), Deprecated = false, Description = "RecommendationInputModel", Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string))]
        public async Task<IActionResult> sendRecommendation(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] RecommendationInputModel req,
            ILogger log)
        {
            try
            {
                if (req == null)
                    throw new ValidationException("SendRecommendationToProvider.sendRecommendation() RequestBody cannot be empty");

                await _validator.ValidateAndThrowAsync(req);
                using (LogContext.PushProperty("EOWID", req.EOWID))
                {
                    _logger.LogInformation("SendRecommendationToProvider.sendRecommendation(): execution started for CDOID: " + req.CDOName);
                    var cdoService = _cdoFactory.GetCdoService(req.CDOName);
                    var data = await cdoService.RecommendationMessages(req);
                    ReturnToProviderOutputModel returnToProviderOutput = new ReturnToProviderOutputModel()
                    {
                        ApiStatusCode = new ResponseModel()
                        {
                            StatusCode = (int)HttpStatusCode.OK
                        },
                        ReturnToProviderResponse = data
                    };
                    _logger.LogInformation("SendRecommendationToProvider.sendRecommendation(): execution ended for CDOID: " + req.CDOName);
                    return new OkObjectResult(returnToProviderOutput)
                    {
                        StatusCode = (int)HttpStatusCode.OK
                    };
                }
            }
            catch (ValidationException ex)
            {
                _logger.LogError("SendRecommendationToProvider.sendRecommendation() failed. Exception: {Error}", ex);
                return new BadRequestObjectResult(new ResponseModel()
                {
                    StatusCode = 0,
                    ErrorMessage = $"SendRecommendationToProvider.sendRecommendation() failed. Exception: {ex.Message}"
                });
            }
            catch (ResponseCustomException ex)
            {
                _logger.LogError("SetPatient.SetPatientInfo()failed. Exception: {Error}", ex);
                return new BadRequestObjectResult(new MyChartOutputModel()
                {
                    ApiStatusCode = new ResponseModel()
                    {
                        StatusCode = ex.CustomObject.StatusCode,
                        ErrorMessage = $"SetPatient.SetPatientInfo()failed. Exception: {ex.CustomObject.ErrorMessage}"
                    }
                })
                {
                    StatusCode = ex.CustomObject.StatusCode
                };
            }
            catch (Exception ex)
            {
                var obj = new ResponseModel()
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    ErrorMessage = $"SendRecommendationToProvider.sendRecommendation() failed. Exception: {ex.Message}"
                };
                var result = new OkObjectResult(obj)
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
                _logger.LogError("SendRecommendationToProvider.sendRecommendation() failed. Exception: {Error}", ex);
                return result;
            }
        }
    }
}