﻿using System;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.Models;

namespace CDOIntegrationService.Refactor.Flex
{
	public interface IFlexService
	{
        Task<string> SignOrder(FlexRequestBody flexRequestBody);
	}
}

