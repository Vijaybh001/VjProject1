﻿using System;
using System.Threading.Tasks;
using AzureFhirFramework.RestClientWrapper;
using AzureFhirFramework.RestClientWrapper.RestPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Polly.CircuitBreaker;
using RestSharp;
using RestSharp.Authenticators;

namespace CDOIntegrationService.Refactor.RestLayer.BasicAuthClient
{
    public class BasicAuthRestClient : IRestClientWrapper
    {
        private readonly RestClient _restClient;
        private readonly ILogger<BasicAuthRestClient> _logger;
        private readonly IRestPolicyManager _restPolicyManager;
        private readonly IConfiguration _config;

        public BasicAuthRestClient(ILogger<BasicAuthRestClient> logger, IRestPolicyManager restPolicyManager, IConfiguration configuration)
        {
            _logger = logger;
            _config = configuration;
            _restClient = CreateBasicAuthClient();
            _restPolicyManager = restPolicyManager;
        }
        public async Task<RestResponse> ExecuteRequest(RestRequest request, string serviceName)
        {
            try
            {
                _logger.LogInformation("BasicAuthRestClient.ExecuteRequest() execution started ");
                var policy = _restPolicyManager.GetPolicy(serviceName);
                //var circuitBreaker = _restPolicyManager.GetCircuitBreaker(serviceName);
                //if (circuitBreaker.CircuitState == CircuitState.Open)
                //    throw new Exception($"{serviceName} is currently unavailable");
                var response = await policy.ExecuteAsync(async () =>
                {
                    return await _restClient.ExecuteAsync(request);
                });

                if (!response.IsSuccessful)
                {
                    _logger.LogError("RestClientWrapper.ExecuteRequest() failed. {Service} {Uri} failed with {StatusCode} {Error} {Content}", serviceName, response.ResponseUri, response.StatusCode, response.ErrorException, response.Content);
                }
                _logger.LogInformation("BasicAuthRestClient.ExecuteRequest() execution ended ");
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError("RestClientWrapper.ExecuteRequest failed. Exception occured: {Error}", ex);
                throw;
            }
        }

        private RestClient CreateBasicAuthClient()
        {
            _logger.LogInformation("BasicAuthRestClient.CreateBasicAuthClient() execution started ");
            var userName = _config.GetValue<string>("EpicUserName");
            var password = _config.GetValue<string>("EpicPassword");
            var options = new RestClientOptions();
            options.Authenticator = new HttpBasicAuthenticator(userName, password);
            var client = new RestClient(options);
            _logger.LogInformation("BasicAuthRestClient.CreateBasicAuthClient() execution ended ");
            return client;
        }


        public async Task<RestResponse> ExecuteRequest(RestRequest request)
        {
            try
            {
                _logger.LogInformation("BasicAuthRestClient.ExecuteRequest() execution started ");
                _logger.LogInformation("BasicAuthRestClient.ExecuteRequest() execution ended ");
                return await _restClient.ExecuteAsync(request);
            }
            catch (Exception ex)
            {
                _logger.LogError("RestClientWrapper.ExecuteRequest failed. Exception occured: {Error}", ex);
                throw;
            }
        }
    }
}

