﻿using System;
using CDOIntegrationService.Refactor.Models;
using FluentValidation;

namespace CDOIntegrationService.Validation
{
	public class MyChartRequestValidator : AbstractValidator<MyChartMessageInputModel>
	{
        public MyChartRequestValidator()
        {
            RuleFor(x => x.Csn).NotEmpty().NotNull().WithMessage("CSN cannot be empty");
            RuleFor(x => x.Msgbody).NotEmpty().NotNull().WithMessage("MsgBody cannot be empty");
            RuleFor(x => x.Subject).NotEmpty().NotNull().WithMessage("Subject cannot be empty");
        }
    }
}

