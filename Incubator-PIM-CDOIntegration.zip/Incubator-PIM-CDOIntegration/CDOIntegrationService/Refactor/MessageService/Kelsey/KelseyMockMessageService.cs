using System;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Serilog;
using CDOIntegrationService.Refactor.Models;
using System.Threading.Tasks;
using Incubator_OIA_CommonModels;

namespace CDOIntegrationService.Refactor.MessageService;

public class KelseyMockMessageService : IMessageService
{
    private readonly ILogger<KelseyMockMessageService> _logger;
    private readonly IBlobServices _blobServices;
    private readonly IProcessMessageData _processMessageData;

    public KelseyMockMessageService(ILogger<KelseyMockMessageService> logger, IBlobServices blobServices, IProcessMessageData processMessageData)
    {
        _logger = logger;
        _blobServices = blobServices;
        _processMessageData = processMessageData;
    }
    public async Task<CosmosModel.OutputMessageCollection> GetMessages(MessageCollectionRequest req)
    {
        try
        {
            _logger.LogInformation("KelseyMockMessageService.GetMessages() execution started ");

            var res = await _blobServices.FetchBlobData(@$"Kelsey/MessageCollectionMockResponse/MessageCollectionMockResponse.json");
            var responseData = JsonConvert.DeserializeObject<GetMessagesResponse>(res);
            var processMessage = _processMessageData.MapMessageData(responseData.Messages, req);
            _logger.LogInformation("KelseyMockMessageService.GetMessages() execution ended ");
            return processMessage;
        }
        catch (Exception ex)
        {
            _logger.LogError(" KelseyMockMessageService: GetMessages() failed. Exception: {Error}", ex);
            throw;
        }
    }
}