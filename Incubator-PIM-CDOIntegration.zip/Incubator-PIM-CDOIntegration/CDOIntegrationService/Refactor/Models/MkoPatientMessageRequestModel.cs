﻿using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Abstractions;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Resolvers;
using Newtonsoft.Json.Serialization;

namespace CDOIntegrationService.Refactor.Models
{
    [OpenApiExample(typeof(PatientMessageRequest))]
    public class MkoPatientMessageRequestModel
    {
        [OpenApiProperty]
        public string MyChartUserId { get; set; }
        [OpenApiProperty]
        public string Subject { get; set; }
        [OpenApiProperty]
        public string MessageBody { get; set; }
        [OpenApiProperty]
        public string PatientFhirId { get; set; }
        [OpenApiProperty]
        public string PendedOrderId { get; set; }
        [OpenApiProperty]
        public string CDOName { get; set; }
        [OpenApiProperty]
        public string EOWID { get; set; }
    }

    public class PatientMessageRequest : OpenApiExample<MkoPatientMessageRequestModel>
    {
        public override IOpenApiExample<MkoPatientMessageRequestModel> Build(NamingStrategy namingStrategy = null)
        {
            this.Examples.Add(
                 OpenApiExampleResolver.Resolve(
                     "PatientMessageRequest",
                     new MkoPatientMessageRequestModel()
                     {
                         MyChartUserId = "1234",
                         Subject = "Refill Subject",
                         MessageBody = "Body",
                         PatientFhirId = "123ed",
                         PendedOrderId = "1234",
                         CDOName = "1",
                         EOWID = "Epic",
                     },
                     namingStrategy
                 ));
            return this;
        }
    }
}

