﻿using System;
using static Incubator_OIA_CommonModels.CosmosModel;
using System.Threading.Tasks;

namespace CDOIntegrationService.Refactor.MessageService.Kelsey
{
	public interface IKelseyMessageCollection
	{
        Task<OutputMessageCollection> RunMessageCollection();

    }
}

