﻿using System;
using Incubator_OIA_CommonModels;
using RestSharp;

namespace CDOIntegrationService.Refactor.CustomException
{
    public class ResponseCustomException : Exception
    {
        public ResponseModel CustomObject { get; }
        public ResponseCustomException()
        {
        }
        public ResponseCustomException(RestResponse message, ResponseModel customObj) : base(message.Content)
        {
            CustomObject = customObj;
        }
    }
}

