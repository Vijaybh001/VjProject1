﻿using System;
using CDOIntegrationService.Refactor.Models;
using FluentValidation;

namespace CDOIntegrationService.Validation
{
	public class SendRecommendationValidator : AbstractValidator<RecommendationInputModel>
    {
		public SendRecommendationValidator()
		{
            RuleFor(x => x.CDOName).NotEmpty().NotNull().WithMessage("CDOID cannot be empty");
            RuleFor(x => x.EOWID).NotEmpty().NotNull().WithMessage("EOWID cannot be empty");
            //RuleFor(x => x.eow805).NotEmpty().NotNull().WithMessage("EOW805 cannot be empty");
            RuleFor(x => x.Pools).NotEmpty().NotNull().WithMessage("POOLS cannot be empty");
            //RuleFor(x => x.ConceptID).NotEmpty().NotNull().WithMessage("CONCEPT ID cannot be empty");
            //RuleFor(x => x.ConceptValue).NotEmpty().NotNull().WithMessage("CONCEPT VALUE cannot be empty");
        }
	}
}

