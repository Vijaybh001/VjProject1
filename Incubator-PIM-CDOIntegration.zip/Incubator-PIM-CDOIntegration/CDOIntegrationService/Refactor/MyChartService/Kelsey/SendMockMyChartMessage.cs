﻿using System;
using CDOIntegrationService.Refactor.Models;
using Newtonsoft.Json;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace CDOIntegrationService.Refactor.MyChartService
{
    public class SendMockMyChartMessage : ISendMyChartMessage
    {
        private readonly ILogger<SendMockMyChartMessage> _logger;
        public SendMockMyChartMessage(ILogger<SendMockMyChartMessage> logger)
        {
            _logger = logger;
        }
        public Task<MyChartMessageOutputModel> SendMessage(MyChartMessageInputModel myChartMessageInputModel)
        {
            //TODO: This async method lacks 'await' operators and will run synchronously.
            try
            {
                _logger.LogInformation("SendMockMyChartMessage.SendMessage() execution started ");
                var binDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                var rootDirectory = Path.GetFullPath(Path.Combine(binDirectory, ".."));
                var path = File.ReadAllText(rootDirectory + "/MockData/MkoPatientMessagesMock.json");

                var responseData = JsonConvert.DeserializeObject<MyChartMessageOutputModel>(path);
                _logger.LogInformation("SendMockMyChartMessage.SendMessage() execution ended ");
                return Task.FromResult(responseData);

            }
            catch (Exception ex)
            {
                _logger.LogError("SendMockMyChartMessage.SendMessage() failed. Exception: {Error}", ex);
                throw;
            }
        }
    }
}