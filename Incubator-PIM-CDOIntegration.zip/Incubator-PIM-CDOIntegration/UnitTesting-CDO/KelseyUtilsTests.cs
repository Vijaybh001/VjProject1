﻿using CDOIntegrationService;
using CDOIntegrationService.Refactor;
using CDOIntegrationService.Refactor.CDOService.Kelsey;
using CDOIntegrationService.Refactor.EHRService.Kelsey;
using CDOIntegrationService.Refactor.Models;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Logging;
using Moq;

namespace UnitTesting_CDO
{
    public class KelseyUtilsTests
	{
        private readonly Mock<ILogger<KelseyCdoService>> _loggerMock;
        private readonly KelseyEHRUtils _kelseyEHRUtils;
        private readonly KelseyUtils _kelseyUtils;
        public KelseyUtilsTests()
		{
            _loggerMock = new();
            _kelseyEHRUtils = new();
            _kelseyUtils = new();
        }
        [Fact]
        public void KelseyEHRUtils_ProcessFhirData_NotNull()
        {
            // Arrange
            var input = new FhirData()
            {
                Patient = new Patient(),
                Appointment = new Bundle(),
                Condition = new Bundle(),
                Encounter = new Bundle(),
                MedRequest = new Bundle(),
                Observation = new Bundle()
            };
            //Act
            _kelseyEHRUtils.ValidateEpicData(input);
            //Assert
            Assert.NotNull(input);
        }
        [Fact]
        public void KelseyEHRUtils_ProcessFhirData_Null()
        {
            // Arrange
            var input1 = new FhirData()
            {
                Patient = null,
                Appointment = null,
                Condition = null,
                Encounter = null,
                MedRequest = null,
                Observation = null
            };
            //Act
            _kelseyEHRUtils.ValidateEpicData(input1);
            //Assert
            Assert.NotNull(input1);
        }
        [Fact]
        public void KelseyUtils_ParsePatientDetails_NotNull()
        {
            // Arrange
            var input1 = new Bundle();
            Bundle? input2 = null;
            //Act
            var response = _kelseyUtils.ParsePatientDetails(input1, _loggerMock.Object);
            //var response2 = KelseyUtils.ParsePatientDetails(input2);
            //Assert
            Assert.NotNull(response);
            var exception = Record.Exception(() => _kelseyUtils.ParsePatientDetails(input2, _loggerMock.Object));
            Assert.IsType<NullReferenceException>(exception);
        }
        [Fact]
        public void KelseyUtils_ParsePatientDetails_Error()
        {
            // Arrange
            Bundle? input2 = null;
            //Assert

            var exception2 = Record.Exception(() => _kelseyUtils.ParsePatientDetails(input2, _loggerMock.Object));
            Assert.IsType<NullReferenceException>(exception2);
        }
    }
}

