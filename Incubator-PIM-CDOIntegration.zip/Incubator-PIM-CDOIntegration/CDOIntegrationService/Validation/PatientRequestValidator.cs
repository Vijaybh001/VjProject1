﻿using CDOIntegrationService.Refactor.Models;
using FluentValidation;

namespace CDOIntegrationService.Validation
{
    public class PatientRequestValidator: AbstractValidator<PatientRequestModel>
	{
		public PatientRequestValidator(IValidator<PIMFhirIdentifier> validator)
		{
            RuleFor(x => x.PatientFhirId).NotEmpty().WithMessage("PatientFhirId cannot be empty");
            //RuleFor(x => x.PatientMRN).NotEmpty().WithMessage("PatientMRN cannot be empty");
			RuleFor(x => x.Identifiers).SetValidator(validator);
		}
	}
}

