﻿using System;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.MedicationRequestStatusUpdate;
using CDOIntegrationService.Refactor.Models;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace CDOIntegrationService.Triggers
{
    public class MRActiveProviderStatusUpdaterTimer
    {
        private readonly ICdoServiceFactory _cdoFactory;
        private readonly ILogger<MRActiveProviderStatusUpdaterTimer> _logger;
        private readonly IConfiguration _config;

        public MRActiveProviderStatusUpdaterTimer(ILogger<MRActiveProviderStatusUpdaterTimer> log, ICdoServiceFactory cdoFactory, IConfiguration config)
        {
            _logger = log;
            _cdoFactory = cdoFactory;
            _config = config;
        }

        [FunctionName("MRActiveProviderStatusUpdaterTimer")]
        public async Task RunMRActiveProviderStatusUpdaterTimer([TimerTrigger("%MRActiveProviderTimerTriggerFrequency%")] TimerInfo myTimer, ILogger log)
        {
            try
            {
                _logger.LogInformation("RunMRActiveProviderStatusUpdaterTimer() execution started ");

                var cdoService = _cdoFactory.GetCdoService(_config.GetValue<string>("PimMessageCollectionCDO"));
                await cdoService.GetMedicationRequestUpdaterService(true);

                _logger.LogInformation("RunMRActiveProviderStatusUpdaterTimer() execution ended ");
            }
            catch (ValidationException ex)
            {
                _logger.LogError($"ValidationException Occurred for RunMRActiveProviderStatusUpdaterTimer. Exception: {ex.Message}", ex);
            }
            catch (Exception ex)
            {
                _logger.LogCritical($"Exception Occurred for RunMRActiveProviderStatusUpdaterTimer. Exception: {ex.Message}", ex);
                throw;
            }
        }
    }
}

