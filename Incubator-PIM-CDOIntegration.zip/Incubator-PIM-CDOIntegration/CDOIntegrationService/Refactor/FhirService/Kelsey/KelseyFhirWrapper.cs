using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor;
using CDOIntegrationService.Refactor.Models;
using Hl7.Fhir.Model;
using Hl7.Fhir.Serialization;
using Microsoft.Extensions.Logging;
using Serilog.Context;

namespace CDOIntegrationService;

public class KelseyFhirWrapper: IFhirWrapper
{
    private readonly IFhirCrudService _fhirCrudService;
    private readonly ILogger<KelseyFhirWrapper> _logger;
    private readonly FhirUtils _fhirUtils;

    public KelseyFhirWrapper(IFhirCrudService fhirCrudService, ILogger<KelseyFhirWrapper> logger, FhirUtils fhirUtils)
    {
        _fhirCrudService = fhirCrudService;
        _logger = logger;
        _fhirUtils = fhirUtils;
    }

    public async Task<Bundle> GetPatientRaw(PatientRequestModel req)
    {
        try
        {
            _logger.LogInformation("KelseyFhirWrapper.GetPatientRaw() execution started ");
            var response = await _fhirCrudService.GetPatientEverythingDetails(req);
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyFhirWrapper.GetPatientRaw() failed. Exception: {Error}", ex);
            throw;
        }
    }

    public async Task<bool> SetBundle(PatientRequestModel req, Bundle data, string fhirId)
    {
        using (LogContext.PushProperty("PatientFhirId", fhirId))
        {
            try
            {
                _logger.LogInformation("KelseyFhirWrapper.SetBundle() execution started ");
                if (string.IsNullOrEmpty(fhirId))
                {
                    _logger.LogError($"KelseyFhirWrapper.SetBundle() FhirID is empty");
                    throw new Exception("FhirID is empty");
                }
                if (data == null)
                {
                    _logger.LogError($"KelseyFhirWrapper.SetBundle() Fhir Data is null");
                    throw new Exception("Fhir Data is null");
                }

                await _fhirCrudService.DeleteEverything(req, true, true);

                //var options = new JsonSerializerOptions().ForFhir(ModelInfo.ModelInspector);
                var identifiers = _fhirUtils.CreateIdentifier(req);

                await _fhirCrudService.UpsertPatientData(req, new FhirBundleData()
                {
                    FhirBundle = data,
                    Identifiers = identifiers,
                    FhirPatientId = fhirId,
                    CdoPatientId = fhirId
                });
                return true;
            }
            catch (AggregateException ex)
            {
                foreach (var exception in ex.InnerExceptions)
                {
                    _logger.LogError("KelseyFhirWrapper.SetBundle() failed. Exception: {Error}", exception.Message);
                }
                // if exception occurs, delete all data for the patient
                await _fhirCrudService.DeleteEverything(req, true, true);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError("KelseyFhirWrapper.SetBundle() failed. Exception: {Error}", ex);
                await _fhirCrudService.DeleteEverything(req, true, true);
                throw;
            }
        }
    }

    public async Task<bool> DeletePatient(PatientRequestModel req)
    {
        try
        {
            _logger.LogInformation("KelseyFhirWrapper.DeletePatient() execution started ");
            var deleteData = await _fhirCrudService.DeleteEverything(req, true, true);
            _logger.LogInformation("KelseyFhirWrapper.DeletePatient() execution ended ");
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError("KelseyFhirWrapper.DeletePatient() failed. Exception: {Error}", ex);
            throw;
        }
    }

    //public async Task<string> UpsertPatient(PatientRequestModel req, Patient data)
    //{
    //    try
    //    {
    //        _logger.LogInformation("KelseyFhirWrapper.SetBundle() execution started ");//TODO: log should be for UpsertPatient not set bundle
    //        if (data == null)
    //        {
    //            _logger.LogInformation($"KelseyFhirWrapper.UpsertPatient() : Patient data is null");
    //            throw new Exception("Patient data is null");
    //        }

    //        var deleteData = await _fhirCrudService.DeleteEverything(req, true, true);
    //        if (!deleteData)
    //        {
    //            _logger.LogInformation($"KelseyFhirWrapper.UpsertPatient() : Deletion of data prior to set bundle failed");
    //            throw new Exception("Deletion of data prior to set bundle failed");
    //        }

    //        var patient = await _fhirCrudService.UpsertPatient(req, data);
    //        _logger.LogInformation("KelseyFhirWrapper.SetBundle() execution ended ");//TODO: log should be for UpsertPatient not set bundle
    //        return patient;
    //    }
    //    catch (Exception ex)
    //    {
    //        _logger.LogError("KelseyFhirWrapper.UpsertPatient() failed. Exception: {Error}", ex);
    //        throw;
    //    }
    //}
}