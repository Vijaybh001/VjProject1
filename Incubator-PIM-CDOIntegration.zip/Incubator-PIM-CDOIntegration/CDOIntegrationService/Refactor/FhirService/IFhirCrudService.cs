using CDOIntegrationService.Refactor.Models;
using Hl7.Fhir.Model;
using System.Threading.Tasks;

namespace CDOIntegrationService;

public interface IFhirCrudService
{
    //Task<string> UpsertPatient(PatientRequestModel req, Patient data);
    Task<Bundle> GetPatientEverythingDetails(PatientRequestModel req);
    //Task<string> SetBundle(PatientRequestModel req, FhirBundleData bundleData);
    Task<Bundle> UpsertPatientData(PatientRequestModel req, FhirBundleData bundleData);
    Task<Bundle> DeleteEverything(PatientRequestModel req, bool IsFhirIdDelete, bool DeleteAll);
    Task<bool> GetFhirHealth();
    Task<bool> GetUpsertFhirHealth();
    Task<Bundle> GetResourceById(string resourceId, string resourceType);
    Task<bool> GetDeleteFhirHealth();
}