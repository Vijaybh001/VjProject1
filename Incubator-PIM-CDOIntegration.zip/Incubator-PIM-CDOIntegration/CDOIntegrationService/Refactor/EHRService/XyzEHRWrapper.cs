using System;
using System.Linq;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.Authentication;
using CDOIntegrationService.Refactor.Models;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace CDOIntegrationService;

public class XyzEHRWrapper: IEHRWrapper
{
    private IEHRService _ehrservice;
    //private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<XyzEHRWrapper> _logger;
    private readonly IConfiguration _config;

    public XyzEHRWrapper(IServiceProvider serviceProvider, IConfiguration configuration, ILogger<XyzEHRWrapper> logger)
    {
        var _services = serviceProvider.GetServices<IEHRService>();
        _ehrservice = _services.First(o => o.GetType() == typeof(AllscriptEhrService));
        _logger = logger;
        _config = configuration;
    }

    Task<Bundle> IEHRWrapper.GetPatientData(string patientID, bool isMock)
    {
        throw new NotImplementedException();
    }

    public async Task<Bundle> GetPatientRawDataByResource(string patientID, string resourceType)
    {
        //TODO: This async method lacks 'await' operators
        throw new NotImplementedException();
    }
}