﻿//using System;
//using System.Collections.Generic;
//using Newtonsoft.Json;

//namespace CDOIntegrationService.Refactor.Models
//{
//    public class PatientTokenData
//    {
//        public string id { get; set; }
//        public string PatientMRN { get; set; }
//        public string CDOName { get; set; }
//        public string PatientFhirID { get; set; }
//        public List<EmailConfig> Emailconfiguration { get; set; }
//    }

//    public class TokenData
//    {
//        public string _DbStoredKey { get; set; }
//        public bool _isUnsubscribe { get; set; }
//    }

//    public class EmailConfig
//    {
//        public string Email { get; set; }
//        public bool IsUnsubscribe { get; set; }
//        public string UnsubscribeToken { get; set; }
//    }

//    public class ActiveAuthProviders
//    {
//        public string ProviderId { get; set; }
//        public string ProviderName { get; set; }
//        public string ProviderSpecialties { get; set; }
//        public string ProviderFhirId { get; set; }
//        public string ProviderFhirIdEMP { get; set; }
//    }

//    public class ActiveDepartments
//    {
//        public string DepartmentId { get; set; }
//        public string DepartmentName { get; set; }
//        public string DepartmentSpecialty { get; set; }
//    }

//    public class ActiveMedList
//    {
//        public List<string> code { get; set; }
//        public string Name { get; set; }
//        public string SupplyCompletionDate { get; set; }
//    }

//    public class ActiveOrders
//    {
//        public string OrderId { get; set; }
//#nullable enable
//        public DateTime? OrderInstant { get; set; }
//#nullable disable
//        public string OrderEndDate { get; set; }
//        public string OrderEndDateGT30Days { get; set; }
//        public string NumRefillsAllowed { get; set; }
//        public string OrderNoOfRefillAllowed { get; set; }
//        public string SupplyDuration { get; set; }
//        public string RxNormCode { get; set; }
//        public string Quantity { get; set; }
//        public string SIG { get; set; }
//        public ActiveAuthProvider ActiveAuthProvider { get; set; }
//        public ActiveDepartment ActiveDepartment { get; set; }
//    }

//    public class CategoryProcessor
//    {
//        public List<ProcessStep> ProcessSteps { get; set; }
//    }

//    public class LastVisitInformation
//    {
//        public string StartTime { get; set; }
//        public string EndTime { get; set; }
//        public string ProviderName { get; set; }
//    }

//    public class MessageProcessor
//    {
//        public List<ProcessStep> ProcessSteps { get; set; }
//    }

//    public class Order
//    {
//        public OrderSteps OrderSteps { get; set; }
//        public Pendedorder PendedOrder { get; set; }
//        public ActiveOrders ActiveOrder { get; set; }
//        public string PimIntent { get; set; }
//        public string PimCategory { get; set; }
//        public ProviderDecision ProviderDecision { get; set; }
//        public List<PimMessageMedicine> PimMessageMedicines { get; set; }
//        public string IsSameServicelineMedication { get; set; }
//        public List<ActiveMedList> ActiveMedList { get; set; }
//        public bool? PimIsCategoryValid { get; set; }
//        public bool? PimIsDURValid { get; set; }
//        public int PimTotalPass { get; set; }
//        public int PimTotalFail { get; set; }
//        public LastVisitInformation LastVisitInformation { get; set; }
//        public PimCommonRuleActionOutput PimCommonRuleActionOutput { get; set; }
//        public PimODEEngineOutput PimODEEngineOutput { get; set; }
//        public bool? IsSIGValid { get; set; }
//        public bool PimOverallRecommendation { get; set; }
//        public PimCDSRecommendationMessage PimCDSRecommendationMessage { get; set; }
//#nullable enable
//        public ProviderUIData? PimProviderUIData { get; set; }
//        public bool? IsDaysSupplyValid { get; set; }
//        public int? RefillDuration { get; set; }
//    }

//#nullable disable
//    public class ProviderUIData
//    {
//        public QuantRefillData Bridge { get; set; }
//        public QuantRefillData Full { get; set; }
//        public decimal DaysSupply { get; set; }
//    }
//    public class QuantRefillData
//    {
//        public int NoOfRefill { get; set; }
//        public string Quantity { get; set; }
//    }

//    public class ProviderDecision
//    {
//        public string RefillType { get; set; }
//        public string VisitType { get; set; }
//        public int NoOfRefill { get; set; }
//        public string Quantity { get; set; }
//        public int? RefillDuration { get; set; }
//        public string Message { get; set; }
//    }

//    public class OrderSteps
//    {
//        public MessageProcessor MessageProcessor { get; set; }
//        public CategoryProcessor CategoryProcessor { get; set; }
//        public PimOutReachStep PimOutReachSteps { get; set; }
//    }

//    public class PimOutReachStep
//    {
//        public OutReachSteps ProcessSteps { get; set; }
//    }

//    public class OutReachSteps
//    {
//        public FlexOutputModel FlexOutput { get; set; }
//        public IsSentOutreachModel MkoPortalMessage { get; set; }
//        public IsSentOutreachModel TicklerEmail { get; set; }
//        public IsSentOutreachModel SchedulerTicket { get; set; }
//    }

//    public class FlexOutputModel
//    {
//        public bool Status { get; set; }
//#nullable enable
//        public string? Message { get; set; }
//        public DateTime? CurrentTimestamp { get; set; }
//    }

//    public class IsSentOutreachModel
//    {
//#nullable enable
//        public string? Status { get; set; }
//        public string? Message { get; set; }
//        public DateTime? CurrentTimestamp { get; set; }
//    }
//#nullable disable
//    public class Patients
//    {
//        public string PatientId { get; set; }
//        public string MRN { get; set; }
//        public string EnterpriseId { get; set; }
//        public string FHIRID { get; set; }
//        public string Name { get; set; }
//        public string ZipCode { get; set; }
//        public string PrimaryPhone { get; set; }
//        public string DOB { get; set; }
//    }

//    public class PendAuthProviders
//    {
//        public string ProviderId { get; set; }
//        public string ProviderName { get; set; }
//        public string ProviderSpecialties { get; set; }
//        public string ProviderFhirId { get; set; }
//        public string ProviderFhirIdEMP { get; set; }
//    }

//    public class CurrentMedicationStatus
//    {
//        public string PendedMedicationRequestFhirId { get; set; }
//        public string ActiveMedicationRequestFhirId { get; set; }
//#nullable enable
//        public MedicationStatus? Status { get; set; }
//    }

//#nullable disable
//    public class MedicationStatus
//    {
//        public string CurrentStatus { get; set; }
//        public DateTime CurrentDateTime { get; set; }
//    }

//    public class Pendedorder
//    {
//        public string PendedOrderId { get; set; }
//        public string MedId { get; set; }
//        public string MedName { get; set; }
//        public string PharmacyName { get; set; }
//        public string PtComment { get; set; }
//        public string PharmacyAddress { get; set; }
//        public string Dosage { get; set; }
//        public string Quantity { get; set; }
//        public string Sig { get; set; }
//        public string SupplyDuration { get; set; }
//        public DateTime? ExpireDate { get; set; }
//        public string OrderEncounterCSN { get; set; }
//        public string NumRefillsAllowed { get; set; }
//        public string DeptSpecialty { get; set; }
//        public bool IsSameDept { get; set; }
//        public string RxNormCode { get; set; }
//        public CurrentMedicationStatus currentMedicationStatus { get; set; }
//        public PendAuthProviders PendAuthProvider { get; set; }
//    }

//    public class PimCDSRecommendationMessage
//    {
//        public string FhirId { get; set; }
//    }

//    public class PimCommonRuleActionOutput
//    {
//        public bool IsRulesSucceeded { get; set; }
//        public int RefillDuration { get; set; }
//        public object Suggestions { get; set; }
//        public object DelegateUsername { get; set; }
//        public bool CriteriaSatisfied { get; set; }
//        public object CriteriaPassed { get; set; }
//        public object CriteriaFailed { get; set; }
//        public List<RulesCondition> RulesConditions { get; set; }
//        public object SupportData { get; set; }
//    }

//    public class PimMessageMedicine
//    {
//        public string MedicineName { get; set; }
//        public string RxNorm { get; set; }
//    }

//    public class PimODEEngineOutput
//    {
//        public string Release { get; set; }
//        public bool IsRulesSucceeded { get; set; }
//        public int RefillDuration { get; set; }
//        public string RefillType { get; set; }
//        public string VisitType { get; set; }
//        public string Message { get; set; }
//        public PimClass PIMClass { get; set; }
//        public List<RulesCondition> RulesConditions { get; set; }
//    }

//    public class PimClass
//    {
//        public string MedClass { get; set; }
//        public string SubClass { get; set; }
//        public string DoseForm { get; set; }
//    }

//    public class PimRecommendation
//    {
//        public bool IsRecommendationSent { get; set; }
//        public object Message { get; set; }
//    }

//    public class PimStep
//    {
//        public string CurrentStep { get; set; }
//        public DateTime TimeStamp { get; set; }
//        public string Message { get; set; }
//    }

//    public class ProcessStep
//    {
//        public string ProcessName { get; set; }
//        public bool Status { get; set; }
//        public object Message { get; set; }
//        public string Response { get; set; }
//    }

//    public class CosmosData
//    {
//        public string id { get; set; }
//        public string EOWID { get; set; }
//        public string MessageBody { get; set; }
//        public string CSN { get; set; }
//        public string Status { get; set; }
//        public string MessageType { get; set; }
//        public int? MyChartUserId { get; set; }
//        public string CDOName { get; set; }
//        public string EhrName { get; set; }
//        public string DefaultPool { get; set; }
//        public string StatusNote { get; set; }
//        public Patients Patient { get; set; }
//        public string PatientTimeZone { get; set; }
//        public string Messagesource { get; set; }
//        public DateTime MsgSubmittedInstant { get; set; }
//        public bool IsPregnant { get; set; }
//        public bool IsBreastFeeding { get; set; }
//        public string PatientEmailId { get; set; }
//        public string PatientCommPref { get; set; }
//        public string AssigningAuthority { get; set; }
//        public DateTime AggregatorTime { get; set; }
//        public List<PimStep> PimSteps { get; set; }
//        public List<Order> Orders { get; set; }
//        public PimRecommendation PimRecommendation { get; set; }
//        public string RecordETag { get; set; }
//        public DateTime LastModified { get; set; }
//    }

//    public class RulesCondition
//    {
//        public string Condition { get; set; }
//        public string Assertion { get; set; }
//        public string DisplayText { get; set; }
//        public bool Status { get; set; }
//        public string id { get; set; }
//        public object SupportingData { get; set; }
//    }

//    public class OutReachRequest
//    {
//        public string id { get; set; }
//        public string PendedOrderId { get; set; }
//        public int? RefillDuration { get; set; }
//        public string RefillType { get; set; }
//#nullable enable
//        public string? VisitType { get; set; }
//#nullable disable
//        public string Message { get; set; }
//        public string CDOName { get; set; }
//        public string EOWID { get; set; }
//        public int NoOfRefill { get; set; }
//        public string Quantity { get; set; }
//    }
//}