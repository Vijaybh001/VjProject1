using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using System.Net;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using CDOIntegrationService.Refactor.Models;
using FluentValidation;
using Serilog.Context;
using Incubator_OIA_CommonModels;
using CDOIntegrationService.Refactor.CustomException;
namespace CDOIntegrationService.Triggers
{
    public class SetPatientHttpTrigger
    {
        private readonly ICdoServiceFactory _cdoFactory;
        private readonly ILogger<SetPatientHttpTrigger> _logger;
        private readonly IValidator<PatientRequestModel> _validator;
        public SetPatientHttpTrigger(ILogger<SetPatientHttpTrigger> log, ICdoServiceFactory cdoFactory, IValidator<PatientRequestModel> validator)
        {
            _cdoFactory = cdoFactory;
            _logger = log;
            _validator = validator;
        }
        [HttpPost]
        [FunctionName("setPatientInfov2")]
        [OpenApiOperation(operationId: "setPatientInfov2", tags: new[] { "setPatientInfov2" })]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(PatientRequestModel), Deprecated = false, Description = "Request", Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string))]
        public async Task<IActionResult> setPatientInfov2(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] PatientRequestModel req,
            ILogger log)
        {
            using (LogContext.PushProperty("PatientFhirId", req.PatientFhirId))
            using (LogContext.PushProperty("EOWID", req.Identifiers.EOW))
            {

                try
                {
                    if (req == null)
                        throw new ValidationException("RequestBody cannot be empty");

                    _validator.ValidateAndThrow(req);
                    using (LogContext.PushProperty("PatientFhirId", req.PatientFhirId))
                    using (LogContext.PushProperty("CdoId", req.Identifiers.CDOID))
                    {
                        _logger.LogInformation("setPatientInfov2: execution started");
                        var cdoService = _cdoFactory.GetCdoService(req.Identifiers.CDOID);
                        await cdoService.SetPatient(req);
                        _logger.LogInformation("setPatientInfov2: execution finished");
                        return new OkObjectResult(new SetPatientOutputModel()
                        {
                            APIStatusCode = new ResponseModel()
                            {
                                StatusCode = (int)HttpStatusCode.OK
                            }
                        })
                        {
                            StatusCode = (int)HttpStatusCode.OK
                        };
                    }

                }
                catch (ValidationException ex)
                {
                    _logger.LogCritical("SetPatient.SetPatientInfo() failed. Exception: {Error}", ex);
                    return new BadRequestObjectResult(new ResponseModel()
                    {
                        StatusCode = (int)HttpStatusCode.BadRequest,
                        ErrorMessage = $"SetPatient.SetPatientInfo() failed. Exception: {ex.Message}"
                    })
                    {
                        StatusCode = (int)HttpStatusCode.BadRequest
                    };
                }
                catch (ResponseCustomException ex)
                {
                    _logger.LogError("SetPatient.SetPatientInfo() failed. Exception: {Error}", ex);
                    return new BadRequestObjectResult(new SetPatientOutputModel()
                    {
                        APIStatusCode = new ResponseModel()
                        {
                            StatusCode = ex.CustomObject.StatusCode,
                            ErrorMessage = $"SetPatient.SetPatientInfo() failed. Exception: {ex.CustomObject.ErrorMessage}"
                        }
                    })
                    {
                        StatusCode = ex.CustomObject.StatusCode
                    };
                }
                catch (Exception ex)
                {
                    var obj = new ResponseModel()
                    {
                        StatusCode = (int)HttpStatusCode.InternalServerError,
                        ErrorMessage = $"SetPatient.SetPatientInfo() failed. Exception: {ex.Message}"
                    };
                    var result = new OkObjectResult(obj)
                    {
                        StatusCode = (int)HttpStatusCode.InternalServerError
                    };
                    _logger.LogCritical("SetPatient.SetPatientInfo() failed. Exception: {Error}", ex);
                    return result;
                }
            }
        }
    }
}
