﻿using System.Reflection.Metadata;
using CDOIntegrationService;
using CDOIntegrationService.Refactor;
using CDOIntegrationService.Refactor.Models;
using FhirServiceLibrary;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Logging;
using Moq;

namespace UnitTesting_CDO
{
    public class FhirCrudServiceTests
    {
        private readonly PatientRawRequest request = new()
        {
            ResourceType = "*",
            Identifiers = new()
            {
                new()
                {
                    Name = "PatientMRN",
                    Value = "erXuFYUfucBZaryVksYEcMg3"
                },
                new()
                {
                    Name = "CDO",
                    Value = "Kelsey"
                },
                new()
                {
                    Name = "EOW",
                    Value = "12345"
                },
                new()
                {
                    Name = "AssigningAuthority",
                    Value = "Epic"
                }
            }
        };
        private readonly PatientRequestModel req = new()
        {
            PatientFhirId= "PIMS-Hypertension-Patient1",
            EHRName = "Epic",
            Identifiers = new()
            {
                CDOID = "Kelsey"
            },
            ResourceType = "*"
        };

        [Fact]
        public async System.Threading.Tasks.Task GetPatientEverythingDetails_ValidInput_ReturnsResult()
        {
            // Arrange
            var loggerMock = new Mock<ILogger<FhirCrudService>>();
            var fhirServiceMock = new Mock<IFhirService>();
            var fhirUtils = new Mock<FhirUtils>();
            var expectedOp = new Bundle();

            var loggerFactoryMock = new Mock<ILoggerFactory>();
            loggerFactoryMock.Setup(x => x.CreateLogger(It.IsAny<string>())).Returns(loggerMock.Object);

            var fhirCrudService = new FhirCrudService(
                logger: loggerFactoryMock.Object.CreateLogger<FhirCrudService>(),
                fhirService: fhirServiceMock.Object,
                fhirUtils: fhirUtils.Object);

            fhirServiceMock.Setup(x => x.GetPatientEverythingById(It.IsAny<PatientRawRequest>()))
                           .ReturnsAsync(new Bundle());

            // Act
            var result = await fhirCrudService.GetPatientEverythingDetails(req);

            // Assert
            Assert.Equal(expectedOp, result);
        }


        [Fact]
        public async System.Threading.Tasks.Task UpsertPatient_ValidInput_ReturnsResult()
        {
            // Arrange
            var loggerMock = new Mock<ILogger<FhirCrudService>>();
            var fhirServiceMock = new Mock<IFhirService>();
            var fhirUtils = new Mock<FhirUtils>();

            var loggerFactoryMock = new Mock<ILoggerFactory>();
            loggerFactoryMock.Setup(x => x.CreateLogger(It.IsAny<string>())).Returns(loggerMock.Object);

            var fhirCrudService = new FhirCrudService(
                logger: loggerFactoryMock.Object.CreateLogger<FhirCrudService>(),
                fhirService: fhirServiceMock.Object,
                fhirUtils: fhirUtils.Object);
            var bundleData = new FhirBundleData
            {
                FhirPatientId = "patientId"
            };

            // Act
            var result = await fhirCrudService.UpsertPatientData(req, bundleData);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async System.Threading.Tasks.Task DeleteEverything_ValidInput_ReturnsResult()
        {
            // Arrange
            var loggerMock = new Mock<ILogger<FhirCrudService>>();
            var fhirServiceMock = new Mock<IFhirService>();
            var fhirUtils = new Mock<FhirUtils>();

            var loggerFactoryMock = new Mock<ILoggerFactory>();
            loggerFactoryMock.Setup(x => x.CreateLogger(It.IsAny<string>())).Returns(loggerMock.Object);

            var fhirCrudService = new FhirCrudService(
                logger: loggerFactoryMock.Object.CreateLogger<FhirCrudService>(),
                fhirService: fhirServiceMock.Object,
                fhirUtils: fhirUtils.Object);

            bool isFhirIdDelete = true;
            bool deleteAll = true;
            var bundle = new Bundle();

            fhirServiceMock.Setup(x => x.DeletePatientById(It.IsAny<PatientRawRequest>(), deleteAll, isFhirIdDelete)).ReturnsAsync(bundle);

            // Act
            var result = await fhirCrudService.DeleteEverything(req, isFhirIdDelete, deleteAll);

            // Assert
            Assert.Equal(bundle, result);
        }

    }
}
