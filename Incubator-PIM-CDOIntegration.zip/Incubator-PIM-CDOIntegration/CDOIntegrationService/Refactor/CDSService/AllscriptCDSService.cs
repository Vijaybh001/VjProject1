namespace CDOIntegrationService;

public class AllscriptCDSService:ICDSService
{
    public void OrderSign(string patientId)
    {
        throw new System.NotImplementedException();
    }
}