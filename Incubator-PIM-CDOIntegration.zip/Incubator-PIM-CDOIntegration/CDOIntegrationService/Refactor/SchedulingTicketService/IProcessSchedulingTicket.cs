﻿using System;
using CDOIntegrationService.Refactor.Models;
using System.Threading.Tasks;

namespace CDOIntegrationService.Refactor.SchedulingTicketService
{
	public interface IProcessSchedulingTicket
	{
        Task processSchedulingTicket(SchedulingTicketRequestModel req);
    }
}

