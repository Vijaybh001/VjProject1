﻿using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Abstractions;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Resolvers;
using Newtonsoft.Json.Serialization;
namespace CDOIntegrationService.Refactor.Models
{
    [OpenApiExample(typeof(PatientRequestExample))]
    public class PatientRequestModel
    {
        public string PatientFhirId { get; set; }
        [OpenApiProperty]
        public string ResourceType { get; set; }
        [OpenApiProperty]
        public string EHRName { get; set; }
        [OpenApiProperty]
        public PIMFhirIdentifier Identifiers { get; set; }
    }

    public class PatientRequestExample : OpenApiExample<PatientRequestModel>
    {
        public override IOpenApiExample<PatientRequestModel> Build(NamingStrategy namingStrategy = null)
        {
            this.Examples.Add(
                 OpenApiExampleResolver.Resolve(
                     "PatientRequestExample",
                     new PatientRequestModel()
                     {
                         //PatientMRN= "erXuFYUfucBZaryVksYEcMg3",
                         ResourceType = "*",
                         //CDOID = "Kelsey",
                         EHRName = "Epic",
                         //EOW="1234",
                     },
                     namingStrategy
                 ));
            return this;
        }
    }
}