﻿using System;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Abstractions;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Resolvers;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace CDOIntegrationService.Refactor.Models
{
    [OpenApiExample(typeof(PatientMessageRequest))]
    public class RecommendationInputModel
    {
        [JsonProperty("EOWID")]
        public String EOWID;

        [JsonProperty("CDONAME")]
        public String CDOName;

        [JsonProperty("eow805")]
        public String eow805;

        [JsonProperty("Pools")]
        public String Pools;

        [JsonProperty("ConceptID")]
        public String ConceptID;

        [JsonProperty("ConceptValue")]
        public String ConceptValue;
    }
}

