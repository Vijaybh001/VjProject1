﻿using System;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.Models;
using AzureFhirFramework.RestClientWrapper;
using AzureFhirFramework.RestClientWrapper.RestPolicy;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;

namespace CDOIntegrationService.Refactor.Authentication
{
	public class FlexAuthentication: IAuthentication
	{
        private readonly IConfiguration _configuration;
        private readonly ILogger<FlexAuthentication> _logger;
        private readonly IRestClientWrapper _restService;
        private readonly IMemoryCache _cache;

        public FlexAuthentication(IConfiguration config, ILogger<FlexAuthentication> logger, IRestClientWrapper restClientWrapper, IMemoryCache memoryCache)
		{
            _configuration = config;
            _logger = logger;
            _restService = restClientWrapper;
            _cache = memoryCache;
        }

        private async Task<FlexToken> CreateFlexToken()
        {
            try
            {
                _logger.LogInformation("FlexAuthentication.CreateFlexToken() execution started ");

                var url = $"{_configuration.GetValue<string>("FlexBaseURL")}/authz/oauth/token";
                var request = new RestRequest(url, Method.Post);

                var reqParams = new
                {
                    client_id = _configuration.GetValue<string>("FlexClientID"),
                    grant_type = "client_credentials",
                    client_secret = _configuration.GetValue<string>("FlexClientSecret"),
                    redirect_uri = "https://www.google.com/",
                    scope = "user/MedicationRequest.create"
                };
                request.AddObject(reqParams);

                var response = await _restService.ExecuteRequest(request, "FlexToken");

                if (!response.IsSuccessful)
                {
                    _logger.LogError("FlexAuthentication.CreateFlexToken() failed. {Status} {Content} {Error}", response.StatusCode, response.Content, response.ErrorException);
                    throw new Exception(response.Content);
                }
                if (string.IsNullOrEmpty(response.Content))
                    throw new Exception("Flex Token Response is empty");
                var tokenObj = JsonConvert.DeserializeObject<FlexToken>(response.Content);

                _logger.LogInformation("FlexAuthentication.CreateFlexToken() execution ended ");
                return tokenObj;
            }
            catch (Exception ex)
            {
                _logger.LogError("FlexAuthentication.CreateFlexToken() failed. Exception: {Error}", ex);
                throw;
            }
        }

        public async Task<string> GetToken()
        {
            try
            {
                _logger.LogInformation("FlexAuthentication.GetToken() execution started ");
                if (!_cache.TryGetValue("FlexToken", out string token))
                {
                    var tokenObj = await CreateFlexToken();
                    if (string.IsNullOrEmpty(tokenObj.access_token))
                        throw new Exception("Flex Token is empty");
                    var cacheOptions = new MemoryCacheEntryOptions()
                    {
                        AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(tokenObj.expires_in)
                    };
                    token = tokenObj.access_token;
                    _cache.Set("FlexToken", token, cacheOptions);
                }
                _logger.LogInformation("FlexAuthentication.GetToken() execution ended ");
                return token;
            }
            catch (Exception ex)
            {
                _logger.LogError("FlexAuthentication.GetToken() failed. Exception: {Error}", ex);
                throw;
            }
        }

        public void RefreshToken()
        {
            throw new NotImplementedException();
        }
    }
}

