using CDOIntegrationService.Refactor.Models;
using System;
using System.Threading.Tasks;
using Incubator_OIA_CommonModels;

namespace CDOIntegrationService.Refactor.MessageService;

public interface IMessageService
{
    Task<CosmosModel.OutputMessageCollection> GetMessages(MessageCollectionRequest req);
}