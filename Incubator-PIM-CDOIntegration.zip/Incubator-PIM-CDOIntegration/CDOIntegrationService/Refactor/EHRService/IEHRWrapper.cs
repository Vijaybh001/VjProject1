using System.Threading.Tasks;
using Hl7.Fhir.Model;

namespace CDOIntegrationService;

public interface IEHRWrapper
{
    Task<Bundle> GetPatientData(string patientID, bool isMock);
    Task<Bundle> GetPatientRawDataByResource(string patientFhirId, string resourceType);
}