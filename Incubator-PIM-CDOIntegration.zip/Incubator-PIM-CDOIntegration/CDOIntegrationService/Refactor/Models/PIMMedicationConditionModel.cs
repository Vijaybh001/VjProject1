﻿using System.Collections.Generic;

namespace CDOIntegrationService.Refactor.Models
{
    public class ActiveMedication
    {
        public List<string> code { get; set; }
        public string name { get; set; }
        public string supplyCompletionDate { get; set; }
    }

    //public class Encounter
    //{
    //    public string code { get; set; }
    //    public string date { get; set; }
    //    public string display { get; set; }
    //}

    //public class Procedure
    //{
    //    public string code { get; set; }
    //    public string date { get; set; }
    //    public List<string> value { get; set; }
    //}

    //public class Condition
    //{
    //    public string code { get; set; }
    //    public string date { get; set; }
    //    public string display { get; set; }
    //}

    //public class Resource
    //{
    //    public string patientId { get; set; }
    //    public string patientName { get; set; }
    //    public string dob { get; set; }
    //    public string gender { get; set; }
    //    public List<ActiveMedication> activeMedication { get; set; }
    //    public string dateAsserted { get; set; }
    //    public List<Encounter> encounter { get; set; }
    //    public List<Procedure> procedure { get; set; }
    //    public List<Condition> condition { get; set; }
    //}

    public class PimResource
    {
        public string PatientId { get; set; }
        public string PatientName { get; set; }
        public string Dob { get; set; }
        public string Gender { get; set; }
        public List<ActiveMedication> ActiveMedication { get; set; }
    }
}
