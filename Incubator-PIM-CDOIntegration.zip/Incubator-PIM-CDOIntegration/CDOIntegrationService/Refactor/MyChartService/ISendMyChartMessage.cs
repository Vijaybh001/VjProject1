﻿using System;
using CDOIntegrationService.Refactor.Models;
using System.Threading.Tasks;

namespace CDOIntegrationService.Refactor.MyChartService
{
	public interface ISendMyChartMessage
	{
        Task<MyChartMessageOutputModel> SendMessage(MyChartMessageInputModel myChartMessageInputModel);
    }
}

