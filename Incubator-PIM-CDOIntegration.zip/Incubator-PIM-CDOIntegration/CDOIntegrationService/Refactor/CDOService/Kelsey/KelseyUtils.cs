﻿using System;
using Hl7.Fhir.Model;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Logging;
using YamlDotNet.Core.Tokens;
using CDOIntegrationService.Refactor.Models;

namespace CDOIntegrationService.Refactor.CDOService.Kelsey
{
    public class KelseyUtils
    {
        public PimResource ParsePatientDetails(Bundle bundle, ILogger logger)
        {
            //var bundle = new FhirJsonParser().Parse<Bundle>(bundleResponse);

            PimResource patient = ParsePatient(bundle, logger);
            return patient;
        }

        private PimResource ParsePatient(Bundle bundle, ILogger logger)
        {
            logger.LogInformation("KelseyUtils.ParsePatient() execution started");
            PimResource patient = new();
            var activemeds = new List<ActiveMedication>();
            foreach (var entry in bundle.Entry)
            {
                if (entry.Resource is Patient patientResource)
                {
                    patient.PatientId = patientResource.Id;
                    patient.PatientName = patientResource.Name[0]?.Text;//TODO: Why hardcoded to first name?
                    if (DateTime.TryParse(patientResource.BirthDate, out DateTime result))
                    {
                        patient.Dob = result.ToString();
                    }
                    else
                    {
                        patient.Dob = "";
                    }
                    if (patientResource.Gender != null)
                        patient.Gender = patientResource.Gender.Value.ToString();
                    else
                        patient.Gender = null;
                    //break; // Stop parsing after finding the patient resource
                }
                else if (entry.Resource is MedicationRequest medicationResource &&
                    medicationResource.Status == MedicationRequest.MedicationrequestStatus.Active)
                {
                    ParseActiveMedications(medicationResource, activemeds, logger);
                }
            }
            patient.ActiveMedication = activemeds;
            logger.LogInformation("KelseyUtils.ParsePatient() execution finished");
            return patient;
        }

        private List<ActiveMedication> ParseActiveMedications(MedicationRequest medicationResource, List<ActiveMedication> activeMedications, ILogger logger)
        {
            logger.LogInformation("KelseyUtils.ParseActiveMedications() execution started");
            ActiveMedication medication = new();

            if (medicationResource.Medication is CodeableConcept codeableConcept)
            {
                List<string> codeValues = codeableConcept.Coding?
                    .Where(x => x.System.Contains("rxnorm"))
                    .Select(x => x.Code)
                    .ToList();

                var name = codeableConcept.Text;

                if (codeValues != null && codeValues.Any())
                {
                    medication.code = codeValues;
                    medication.name = name;
                    medication.supplyCompletionDate = "";//CalculateSupplyCompletionDate(medicationResource.DispenseRequest, logger);
                }
                else
                {
                    logger.LogInformation("KelseyUtils.ParseActiveMedications() : medicationResource.Medication is not of valid type: {MedicationRequestId}", medicationResource.Id);
                }
            }
            activeMedications.Add(medication);
            logger.LogInformation("KelseyUtils.ParseActiveMedications() execution started");
            return activeMedications;
        }

        private string CalculateSupplyCompletionDate(MedicationRequest.DispenseRequestComponent medicationResource, ILogger logger)
        {
            logger.LogInformation("KelseyUtils.CalculateSupplyCompletionDate() execution started");
            try
            {
                DateTime startDate;
                short value;
                if (medicationResource.ValidityPeriod != null)
                {
                    if (!string.IsNullOrEmpty(medicationResource.ValidityPeriod.Start))
                        startDate = Convert.ToDateTime(medicationResource.ValidityPeriod.Start);
                    else
                        throw new Exception("medicationResource.DispenseRequest.ValidityPeriod.Start is null or Empty");
                }
                else
                    throw new Exception("medicationResource.DispenseRequest.ValidityPeriod is null");

                if (medicationResource.ExpectedSupplyDuration != null && medicationResource.ExpectedSupplyDuration.Value != null)
                {
                    value = Convert.ToInt16(medicationResource.ExpectedSupplyDuration.Value);
                }
                else
                    throw new Exception("medicationResource.ExpectedSupplyDuration or medicationResource.ExpectedSupplyDuration.Value is null.");

                var unit = medicationResource.ExpectedSupplyDuration.Unit;
                if (!string.IsNullOrEmpty(unit))
                    unit = unit.ToLower();
                logger.LogInformation("KelseyUtils.CalculateSupplyCompletionDate() execution started");
                switch (unit)
                {
                    case "day":
                        return startDate.AddDays(value).ToString();
                    case "month":
                        return startDate.AddMonths(value).ToString();
                    case "year":
                        return startDate.AddYears(value).ToString();
                    default:
                        return startDate.AddDays(value).ToString();
                }
            }
            catch (Exception ex)
            {
                logger.LogError("KelseyUtils.CalculateSupplyCompletionDate() failed. Exception occured: {Error}", ex);
                return "";
            }
        }
    }
}

