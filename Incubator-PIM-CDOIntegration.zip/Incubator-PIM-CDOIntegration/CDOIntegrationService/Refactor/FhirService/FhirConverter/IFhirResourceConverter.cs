﻿using System;
using Hl7.Fhir.Model;

namespace CDOIntegrationService
{
	public interface IFhirResourceConverter
	{
        Bundle ConvertAppointmentToEncounter(Bundle appointmentBundle, Bundle encounterBundle);
    }
}

