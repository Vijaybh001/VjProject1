using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Configuration;
using System.Net;
using CDOIntegrationService.Refactor.Models;
using FluentValidation;
using Serilog.Context;
using Incubator_OIA_CommonModels;
using CDOIntegrationService.Refactor.CustomException;

namespace CDOIntegrationService;

public  class GetMessagesHttpTrigger
{
    private readonly ICdoServiceFactory _cdoFactory;
    private readonly ILogger<GetMessagesHttpTrigger> _logger;
    private readonly IValidator<MessageCollectionRequest> _validator;
    public GetMessagesHttpTrigger(ILogger<GetMessagesHttpTrigger> log, ICdoServiceFactory cdoFactory, IValidator<MessageCollectionRequest> validator)
    {
        _cdoFactory = cdoFactory;
        _logger = log;
        _validator = validator;
    }
    [HttpPost]
    [FunctionName("GetMessages")]
    [OpenApiOperation(operationId: "GetMessages", tags: new[] { "GetMessages" })]
    [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(MessageCollectionRequest), Deprecated = false, Description = "MessageCollectionRequest", Required = true)]
    [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string))]
    public async Task<IActionResult> getMessages(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] MessageCollectionRequest req,
        ILogger log)
    {
       
        try
        {

            if (req == null)
                throw new ValidationException("RequestBody cannot be empty");

            await _validator.ValidateAndThrowAsync(req);
            using (LogContext.PushProperty("CdoId", req.CDOName))
            {
                _logger.LogInformation("GetMessagesHttpTrigger : GetMessages() execution started for DateTime : {Date} {Time}", req.eowAgeD, req.eowAgeT);
                var cdoService = _cdoFactory.GetCdoService(req.CDOName);
                CosmosModel.GetMessagesResponse messageResponse = new CosmosModel.GetMessagesResponse();
                var data = await cdoService.GetMessages(req);
                if (data.Messages != null)
                {
                    data.MessageCount = data.Messages.Count;
                    _logger.LogInformation("GetMessagesHttpTrigger : GetMessages() Messages count: {data.Messages.Count}", data.Messages.Count);
                }
                else
                {
                    _logger.LogInformation("GetMessagesHttpTrigger : GetMessages() Messages count is null");
                }
                messageResponse.OutputMessageCollectionResponse = data;
                messageResponse.APIStatusCode = new ResponseModel()
                {
                    StatusCode = (int)HttpStatusCode.OK
                };
                _logger.LogInformation("GetMessagesHttpTrigger : GetMessages() execution ended for DateTime : {Date} {Time}", req.eowAgeD, req.eowAgeT);
                return new OkObjectResult(messageResponse)
                {
                    StatusCode = (int)HttpStatusCode.OK
                };
            }

        }
        catch (ValidationException ex)
        {
            _logger.LogError("GetMessages.getMessages() failed. Exception: {Error}", ex);
            return new BadRequestObjectResult(new ResponseModel()
            {
                StatusCode = (int)HttpStatusCode.BadRequest,
                ErrorMessage = $"GetMessages.getMessages() failed. Exception: {ex.Message}"
            })
            {
                StatusCode = (int)HttpStatusCode.BadRequest
            }; ;
        }

        catch (ResponseCustomException ex)
        {
            _logger.LogError("GetMessages.getMessages() failed. Exception: {Error}", ex);
            return new BadRequestObjectResult(new CosmosModel.GetMessagesResponse()
            {
                APIStatusCode = new ResponseModel()
                {
                    StatusCode = ex.CustomObject.StatusCode,
                    ErrorMessage = $"GetMessages.getMessages() failed. Exception: {ex.CustomObject.ErrorMessage}"
                }
            })
            {
                StatusCode = ex.CustomObject.StatusCode
            };
        }

        catch (Exception ex)
        {
            var obj = new ResponseModel()
            {
                StatusCode = 0,
                ErrorMessage = $"GetMessages.getMessages() failed. Exception: {ex.Message}"
            };
            var result = new OkObjectResult(obj)
            {
                StatusCode = (int)HttpStatusCode.InternalServerError
            };
            _logger.LogError("GetMessages.getMessages() failed. Exception: {Error}", ex);
            return result;
        }
        

    }
}