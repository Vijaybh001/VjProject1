using CDOIntegrationService.Refactor.Models;
using Hl7.Fhir.Model;
using System.Threading.Tasks;

namespace CDOIntegrationService;

public interface IFhirWrapper
{
    Task<Bundle> GetPatientRaw(PatientRequestModel req);
    //Task<string> UpsertPatient(PatientRequestModel req, Patient data);
    Task<bool> SetBundle(PatientRequestModel req, Bundle data, string fhirId);
    Task<bool> DeletePatient(PatientRequestModel req);
}