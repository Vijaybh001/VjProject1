﻿using System;
using CDOIntegrationService.Refactor.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using CDOIntegrationService.Refactor.EHRService.Kelsey;
using CDOIntegrationService.Refactor;

namespace CDOIntegrationService.Triggers
{
    public class HealthCheckTrigger
    {
        private readonly IFhirCrudService _fhirCrudService;
        private readonly ILogger<HealthCheckTrigger> _logger;

        public HealthCheckTrigger(ILogger<HealthCheckTrigger> log, IFhirCrudService fhirCrudService)
        {
            _fhirCrudService = fhirCrudService;
            _logger = log;
        }
        [HttpGet]
        [FunctionName("HealthCheck")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string))]
        public async Task<IActionResult> Run(
               [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "healthcheck")] HttpRequest req,
               ILogger log)
        {
            try
            {
                _logger.LogInformation("HealthCheck() execution started ");

                var fhirDeleteHealth = await _fhirCrudService.GetDeleteFhirHealth();
                var fhirUpsertHealth = await _fhirCrudService.GetUpsertFhirHealth();
                var fhirHealth = await _fhirCrudService.GetFhirHealth();
                
                _logger.LogInformation("HealthCheck() execution ended ");
                if (fhirDeleteHealth && fhirHealth && fhirUpsertHealth)
                    return new OkObjectResult(new HealthResponseModel()
                    {
                        Status = true,
                        Message = "success"
                    });
                else
                {
                    var obj = new HealthResponseModel()
                    {
                        Status = false,
                        Message = "Health Check Failed"
                    };
                    var result = new OkObjectResult(obj)
                    {
                        StatusCode = (int)HttpStatusCode.InternalServerError
                    };
                    return result;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("HealthCheckTrigger.HealthCheck() failed. Exception: {Error}", ex);
                var obj = new HealthResponseModel()
                {
                    Status = false,
                    Message = "Health Check Failed: " + ex.Message
                };
                var errorResult = new OkObjectResult(obj)
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError
                };
                return errorResult;
            }
        }
    }
}