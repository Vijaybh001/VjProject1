﻿using System;
using CDOIntegrationService.Refactor.Models;
using FluentValidation;
namespace CDOIntegrationService.Validation
{
	public class MessageCollectionValidator: AbstractValidator<MessageCollectionRequest>
	{
		public MessageCollectionValidator()
		{
			RuleFor(x => x.CDOName).NotEmpty().NotNull().WithMessage("CDOID cannot be empty");
            RuleFor(x => x.EHRName).NotEmpty().NotNull().WithMessage("EHRName cannot be empty");
            RuleFor(x => x.MessageTypes).NotEmpty().NotNull().WithMessage("MessageType cannot be empty");
            RuleFor(x => x.eowAgeD).NotNull().NotEmpty().WithMessage("eowAgeD Should be Valid Date");
            RuleFor(x => x.eowAgeT).NotNull().NotEmpty().WithMessage("eowAgeT Should be Valid Time");
        }
	}
}

