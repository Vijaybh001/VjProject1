﻿using System;
namespace CDOIntegrationService.Refactor.Authentication
{
	public interface IAuthFactory
	{
		IAuthentication GetAuthService(string serviceName);
	}
}

