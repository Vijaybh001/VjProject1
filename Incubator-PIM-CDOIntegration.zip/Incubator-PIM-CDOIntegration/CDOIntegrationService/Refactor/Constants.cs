﻿using System;
namespace CDOIntegrationService.Refactor
{
	public class Constants
	{
		public const string KELSEY = "Kelsey";
		public const string XYZ = "Xyz";
		public const string EPIC = "Epic";
		public const string FHIR = "Fhir";
		public const string FLEX = "Flex";
        public const string START = "start";
        public const string OPERATIONOUTCOME = "\"resourceType\":\"OperationOutcome\"";

        public const int FHIR_ID_LENGTH = 64;
		public const string CDO = "CDO";
		public const string EOW = "EOW";
		public const string MRN = "PatientMRN";
		public const string ASSIGNING_AUTHORITY = "AssigningAuthority";
		public const string RESOURCE_TYPE = "ResourceType";
		public const string ENV = "Environment";
		public const string FHIR_ID = "PatientFhirID";
        public const string MY_CHART_SERVICE = "MyChart";

        public const string INPUT_MESSAGE_STATUS_PEND = "3 - Pend";
		public const string INPUT_MESSAGE_STATUS_SENT = "2 - Sent";
		public const string INPUT_MESSAGE_TYPE = "Rx Auth [32]";

		public const string FHIR_ALL_NONPATIENT_RESOURCES = "Appointment,MedicationRequest,Observation,Encounter,Condition";
		public const string FHIR_ALL_RESOURCES = "Patient,Appointment,MedicationRequest,Observation,Encounter,Condition";
    public const string FHIR_PATIENT_DETAILS_RESOURCES = "Patient,MedicationRequest";

        public const string PATIENT = "Patient";
        public const string APPOINTMENT = "Appointment";
        public const string MEDICATIONREQUEST = "MedicationRequest";
        public const string OBSERVATION = "Observation";
        public const string ENCOUNTER = "Encounter";
        public const string CONDITION = "Condition";
        public const string ALLERGYINTOLERANCE = "AllergyIntolerance";
        public const string MEDICATION = "Medication";
        public const string LOCATION = "Location";
        public const string SERVICEREQUEST = "ServiceRequest";
        public const string PRACTITIONER = "Practitioner";

        public const string FLEXDATEFORMAT = "yyyy-MM-dd";
        public const string CULTUREINFO = "en-US";

        public const string COMPLETESTATUS = "Completed";
        public const string PENDINGSTATUS = "Pending";
    }
}

