﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Incubator_OIA_CommonModels;

namespace CDOIntegrationService.Refactor.MedicationRequestStatusUpdate
{
	public interface IMedicationRequestStatusUpdater
	{
		Task MedicationRequestStatusUpdater(bool updateForActiveProvider);
    }
}

