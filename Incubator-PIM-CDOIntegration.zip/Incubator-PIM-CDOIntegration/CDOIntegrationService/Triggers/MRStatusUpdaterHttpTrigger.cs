﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Configuration;
using System.Net;
using CDOIntegrationService.Refactor.Models;
using Incubator_OIA_CommonModels;
using CDOIntegrationService.Refactor.MedicationRequestStatusUpdate;


namespace CDOIntegrationService;

public class MRStatusUpdaterHttpTrigger
{
    private readonly ICdoServiceFactory _cdoFactory;
    private readonly ILogger<MRStatusUpdaterHttpTrigger> _logger;
    private readonly ICheckMedicationRequestStatus _checkMedicationRequestStatus;
    private readonly IConfiguration _config;

    public MRStatusUpdaterHttpTrigger(ILogger<MRStatusUpdaterHttpTrigger> log, ICdoServiceFactory cdoFactory, ICheckMedicationRequestStatus checkMedicationRequestStatus, IConfiguration config)
    {
        _cdoFactory = cdoFactory;
        _logger = log;
        _checkMedicationRequestStatus = checkMedicationRequestStatus;
        _config = config;
    }
    [HttpPost]
    [FunctionName("MRStatusUpdaterHttpTrigger")]
    [OpenApiOperation(operationId: "MRStatusUpdaterHttpTrigger", tags: new[] { "MRStatusUpdaterHttpTrigger" })]
    [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(MessageCollectionRequest), Deprecated = false, Description = "MRStatusUpdaterHttpTrigger", Required = true)]
    [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string))]
    public async Task<IActionResult> MRStatusUpdaterHttp(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] MedicationOrder req,
        ILogger log)
    {
        try
        {
            log.LogInformation("MRStatusUpdaterHttpTrigger.MRStatusUpdaterHttp() started");

            var validationResult = ValidateMedicationOrder(req);
            if (!validationResult.IsValid)
            {
                _logger.LogWarning("Validation failed: {ValidationErrors}", validationResult.Errors);
                return new BadRequestObjectResult(new ResponseModel
                {
                    StatusCode = (int)HttpStatusCode.BadRequest,
                    ErrorMessage = validationResult.Errors
                });
            }

            var cdoService = _cdoFactory.GetCdoService(_config.GetValue<string>("PimMessageCollectionCDO"));
            var result = await cdoService.CheckMedicationRequestStatusService(req);

            result.APIStatusCode = new ResponseModel
            {
                StatusCode = (int)HttpStatusCode.OK
            };

            log.LogInformation("MRStatusUpdaterHttpTrigger.MRStatusUpdaterHttp() Finished");

            return new OkObjectResult(result);
        }
        catch (Exception ex)
        {
            var obj = new ResponseModel()
            {
                StatusCode = (int)HttpStatusCode.InternalServerError,
                ErrorMessage = $"MRStatusUpdaterHttpTrigger.MRStatusUpdaterHttp() failed. Exception: {ex.Message}"
            };
            var result = new OkObjectResult(obj)
            {
                StatusCode = (int)HttpStatusCode.InternalServerError
            };
            _logger.LogCritical("SetPatient.MRStatusUpdaterHttp() failed. Exception: {Error}", ex);
            return result;
        }
    }

    private (bool IsValid, string Errors) ValidateMedicationOrder(MedicationOrder order)
    {
        var errors = string.Empty;
        if (order == null)
        {
            errors = "Request body is missing.";
            return (false, errors);
        }

        if (string.IsNullOrWhiteSpace(order.PatientFhirId))
        {
            errors += "PatientFhirId is required. ";
        }

        if (string.IsNullOrWhiteSpace(order.PendedOrderId))
        {
            errors += "PendedOrderId is required.";
        }

        return (string.IsNullOrWhiteSpace(errors), errors);
    }
}