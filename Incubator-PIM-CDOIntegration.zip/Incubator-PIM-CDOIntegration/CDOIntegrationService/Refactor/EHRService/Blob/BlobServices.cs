﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using System;
using Microsoft.Extensions.Configuration;

namespace CDOIntegrationService
{
    public class BlobServices : IBlobServices
    {
        private readonly BlobContainerClient _blobContainerClient;
        private readonly ILogger<BlobServices> _logger;
        private readonly IConfiguration _config;

        public BlobServices(BlobServiceClient client, ILogger<BlobServices> logger, IConfiguration configuration)
        {
            _config = configuration;
            _blobContainerClient = client.GetBlobContainerClient(_config.GetValue<string>("EhrMockDataContainerName"));
            _logger = logger;
        }
        public async Task<string> ReadBlobData(string filePath)
        {
            _logger.LogInformation("BlobServices.ReadBlobData() execution started ");
            var blobClient = _blobContainerClient.GetBlobClient(filePath);
            if (!blobClient.Exists())
                return null;
            BlobDownloadResult downloadResult = await blobClient.DownloadContentAsync();
            var fileContent = downloadResult.Content.ToString();
            _logger.LogInformation("BlobServices.ReadBlobData() execution ended ");
            return fileContent;
        }
        public async Task<string> FetchBlobData(string filePath)
        {
            _logger.LogInformation("BlobServices.FetchBlobData() execution started ");
            string rulesEngineData = await ReadBlobData(filePath);

            _logger.LogInformation("BlobServices.FetchBlobData() execution ended ");
            return rulesEngineData;
        }
    }
}
