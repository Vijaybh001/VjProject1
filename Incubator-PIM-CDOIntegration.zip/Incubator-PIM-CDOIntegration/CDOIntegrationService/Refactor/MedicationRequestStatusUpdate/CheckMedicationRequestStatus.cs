﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.ConfigService;
using CDOIntegrationService.Refactor.DBLayer;
using CDOIntegrationService.Refactor.EHRService.Kelsey;
using CDOIntegrationService.Refactor.Models;
using Hl7.Fhir.Model;
using Hl7.Fhir.Serialization;
using Incubator_OIA_CommonModels;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Serilog.Context;

namespace CDOIntegrationService.Refactor.MedicationRequestStatusUpdate
{
	public class CheckMedicationRequestStatus: ICheckMedicationRequestStatus
    {
        private readonly IConfiguration _config;
        private readonly IEHRFactory _eHRFactory;
        private readonly ILogger<CheckMedicationRequestStatus> _logger;
        private readonly IAzureConfig _azureConfig;

        public CheckMedicationRequestStatus(IConfiguration config, IEHRFactory eHRFactory, ILogger<CheckMedicationRequestStatus> logger, IAzureConfig azureConfig)
		{
            _config = config;
            _eHRFactory = eHRFactory;
            _logger = logger;
            _azureConfig = azureConfig;
        }

        public async Task<MRStatusResponseModel> ProcessPendedOrderStatus(MedicationOrder req)
        {
            _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ProcessPendedOrderStatus() execution started ");
           
            var patientFhirId = req.PatientFhirId;
            var pendedOrderId = req.PendedOrderId;

            if (string.IsNullOrEmpty(patientFhirId) || string.IsNullOrEmpty(pendedOrderId))
            {
                _logger.LogInformation("MedicationRequestStatusUpdate.ProcessPendedOrderStatus(): Null or empty PatientFhirId or PendedOrderId.");
            }
            using (LogContext.PushProperty("PendedOrderId", pendedOrderId))
            {
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ProcessPendedOrderStatus() execution ended ");
                return await ValidatePendedMedicationRequest(patientFhirId, pendedOrderId);
            }            
        }

        private async Task<MRStatusResponseModel> ValidatePendedMedicationRequest(string patientFhirId, string pendedOrderId)
        {
            _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ValidatePendedMedicationRequest() execution started ");
            var medicationRequest = await GetMedicationsFromEpic(patientFhirId);
            var response = new MRStatusResponseModel();

            if (medicationRequest != null && medicationRequest.Count > 0)
            {
                var medReq = FindPendedMedicationRequest(pendedOrderId, medicationRequest);
                if (medReq?.Id != null)
                {
                    response.PendedOrderIdStatus = Constants.COMPLETESTATUS;
                    response.PendedOrderId = medReq.Id;
                }
                else
                {
                    response.PendedOrderIdStatus = Constants.PENDINGSTATUS;
                    response.PendedOrderId = null;
                }
            }
            else
            {
                response.PendedOrderIdStatus = Constants.PENDINGSTATUS;
                response.PendedOrderId = null;
            }
            _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ValidatePendedMedicationRequest() execution ended ");
            return response;
        }

        private async Task<List<MedicationRequest>> GetMedicationsFromEpic(string patientFhirId)
        {
            try
            {
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.GetMedicationsFromEpict() execution started ");
                _logger.LogInformation("MedicationRequestStatusUpdate.GetMedicationsFromEpic(): Getting medications from Epic for PatientFhirId: {PatientFhirId} - {DateTime}", patientFhirId.Replace(Environment.NewLine, ""), DateTime.UtcNow);
                var IsMock = _azureConfig.GetValueFromAzureConfig<bool>("IsMock");
                var ehrService = _eHRFactory.GetEHRService(Constants.EPIC, IsMock);

                if (ehrService == null || string.IsNullOrEmpty(patientFhirId))
                {
                    _logger.LogWarning("MedicationRequestStatusUpdate.GetMedicationsFromEpic(): EHR Service or patientFhirId is null for PatientFhirId: {PatientFhirId}", patientFhirId.Replace(Environment.NewLine, ""));
                    return new List<MedicationRequest>();
                }

                var patientMedReqData = await ehrService.GetPatientDataForMRUpdater(patientFhirId, Constants.MEDICATIONREQUEST);
                var fhirData = ParseFhirData(patientMedReqData);

                if (fhirData == null || fhirData.MedRequest == null)
                {
                    _logger.LogWarning("MedicationRequestStatusUpdate.GetMedicationsFromEpic(): FHIR Data or MedRequest is null for PatientFhirId: {PatientFhirId}", patientFhirId.Replace(Environment.NewLine, ""));
                    return new List<MedicationRequest>();
                }

                var medications = fhirData.MedRequest.Entry
                                .Where(entry => entry?.Resource is MedicationRequest)
                                .Select(entry => (MedicationRequest)entry.Resource)
                                .ToList();

                _logger.LogInformation("MedicationRequestStatusUpdate.GetMedicationsFromEpic(): Successfully fetched medications from Epic for PatientFhirId: {PatientFhirId} - {DateTime}", patientFhirId.Replace(Environment.NewLine, ""), DateTime.UtcNow);
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.GetMedicationsFromEpict() execution ended ");
                return medications;
            }
            catch (Exception ex)
            {
                _logger.LogWarning($"MedicationRequestStatusUpdate.GetMedicationsFromEpic(): An error occurred in GetMedicationsFromEpic: {ex.Message}");
                return new List<MedicationRequest>();
            }
        }

        private MedicationRequest FindPendedMedicationRequest(string pendedOrderId, List<MedicationRequest> medications)
        {
            try
            {
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.FindPendedMedicationRequest() execution started ");
                _logger.LogInformation("MedicationRequestStatusUpdate: FindPendedMedicationRequest(): Finding pended medication request for PendedOrderId: {PendedOrderId}", pendedOrderId.Replace(Environment.NewLine, ""));
                var validOids = _config.GetValue<string>("ValidOids");
                var oids = validOids.Split(',').Select(s => s.Trim()).ToList();

                if (medications == null)
                {
                    _logger.LogInformation("MedicationRequestStatusUpdate: FindPendedMedicationRequest(): Medications list is null for PendedOrderId: {PendedOrderId}", pendedOrderId.Replace(Environment.NewLine, ""));
                    return null;
                }

                var matchingMedication = medications.FirstOrDefault(medication =>
                    medication?.Identifier?.Any(identifier =>
                        oids.Contains(identifier.System) && identifier.Value == pendedOrderId
                    ) ?? false
                );

                if (matchingMedication != null)
                {
                    _logger.LogInformation("MedicationRequestStatusUpdate: FindPendedMedicationRequest(): Found pended medication request for PendedOrderId: {PendedOrderId}", pendedOrderId.Replace(Environment.NewLine, ""));
                }
                else
                {
                    _logger.LogInformation("MedicationRequestStatusUpdate: FindPendedMedicationRequest(): No matching pended medication request found for PendedOrderId: {PendedOrderId}", pendedOrderId.Replace(Environment.NewLine, ""));
                }
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.FindPendedMedicationRequest() execution ended ");
                return matchingMedication;
            }
            catch (Exception ex)
            {
                _logger.LogError($"MedicationRequestStatusUpdate: FindPendedMedicationRequest(): An error occurred in FindPendedMedicationRequest: {ex.Message}");
                return null;
            }
        }

        private FhirData ParseFhirData(string patientMedReqResult)
        {
            try
            {
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ParseFhirData() execution started ");
                var fhirData = new FhirData();
                var parser = new FhirJsonParser();
                if (!string.IsNullOrEmpty(patientMedReqResult))
                {
                    fhirData.MedRequest = parser.Parse<Bundle>(patientMedReqResult);
                }
                _logger.LogInformation("KelseyMedicationRequestStatusUpdate.ParseFhirData() execution ended ");
                return fhirData;
            }
            catch (Exception ex)
            {
                _logger.LogWarning($"MedicationRequestStatusUpdate: ParseFhirData(): An error occurred in ParseFhirData: {ex.Message}");
                throw;
            }
        }
    }
}

