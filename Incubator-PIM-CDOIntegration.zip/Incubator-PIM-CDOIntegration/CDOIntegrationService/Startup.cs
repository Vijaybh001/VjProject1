﻿using Azure.Core;
using Azure.Identity;
using CDOIntegrationService;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using RestSharp;
using Serilog;
using Serilog.Configuration;
using Serilog.Events;
using System;
using CDOIntegrationService.Refactor.Authentication;
using CDOIntegrationService.Refactor.MessageService;
using CDOIntegrationService.Refactor.RestLayer;
using AzureFhirFramework.RestClientWrapper;
using AzureFhirFramework.RestClientWrapper.RestPolicy;
using Microsoft.Extensions.Azure;
using CDOIntegrationService.Refactor.EHRService.Kelsey;
using CDOIntegrationService.Refactor.EHRService;
using FhirServiceLibrary;
using CDOIntegrationService.Refactor.SchedulingTicketService;
using Microsoft.Azure.Cosmos;
using CDOIntegrationService.Refactor.DBLayer;
using CDOIntegrationService.Refactor.ReturnToProvider;
using FluentValidation;
using CDOIntegrationService.Refactor.Models;
using CDOIntegrationService.Validation;
using CDOIntegrationService.Refactor.Flex;
using CDOIntegrationService.Refactor.MedicationRequestStatusUpdate;
using CDOIntegrationService.Refactor.RestLayer.BasicAuthClient;
using RestSharp.Authenticators;
using CDOIntegrationService.Refactor;
using CDOIntegrationService.Refactor.CDOService.Kelsey;
using CDOIntegrationService.Refactor.MyChartService;
using Incubator_OIA_CommonModels;
using CDOIntegrationService.Refactor.SignFinalOrder;
using static Incubator_OIA_CommonModels.CosmosModel;
using CDOIntegrationService.Refactor.AzureConfig;
using CDOIntegrationService.Refactor.ConfigService;
using AzureFhirFramework.Interfaces;
using AzureFhirFramework.Services;
using CDOIntegrationService.Refactor.MessageService.Kelsey;

[assembly: FunctionsStartup(typeof(Startup))]
namespace CDOIntegrationService
{
    public class Startup : FunctionsStartup
    {
        private IConfiguration config { get; set; }
        private TokenCredential servicePrincipal;


        private IConfigurationRoot _configuration = new ConfigurationBuilder()
            .SetBasePath(Environment.CurrentDirectory)
            .AddEnvironmentVariables()
            .Build();

        public override void ConfigureAppConfiguration(IFunctionsConfigurationBuilder builder)
        {

            _configuration = builder.ConfigurationBuilder
                .SetBasePath(Environment.CurrentDirectory)
                .AddJsonFile("local.settings.json", true)
                .AddEnvironmentVariables()
                .Build();

            var env = _configuration["CurrentEnvironment"];
#if DEBUG
            var tenantId = _configuration["TENANT_ID"];
            var clientId = _configuration["CLIENT_ID"];
            var clientSecret = _configuration["CLIENT_SECRET"];

            servicePrincipal = new ClientSecretCredential(tenantId, clientId, clientSecret);
            config = builder.ConfigurationBuilder
                .AddAzureAppConfiguration(options =>
                {

                    options.Connect(new(_configuration["AZConfigEndpoint"].ToString()), servicePrincipal)
                     .Select(KeyFilter.Any, LabelFilter.Null)
                     .Select(KeyFilter.Any, env);
                    options.ConfigureKeyVault(vault =>
                    {
                        vault.SetCredential(servicePrincipal);
                    });

                })
#else
            config = builder.ConfigurationBuilder
                .AddAzureAppConfiguration(options =>
                {
                    options.Connect(new Uri(_configuration["AZConfigEndpoint"]), new ManagedIdentityCredential() )
                    .Select(KeyFilter.Any, LabelFilter.Null)
                    .Select(KeyFilter.Any, env);
                    options.ConfigureKeyVault(vault =>
                    {
                        vault.SetCredential(new DefaultAzureCredential());
                    });
                })
                
#endif
                .Build();

            builder.ConfigurationBuilder.AddConfiguration(config);
        }
        
        public override void Configure(IFunctionsHostBuilder builder)
        {
            builder.Services.AddSingleton(typeof(IConfiguration), config);

            var connectionString = config.GetValue<string>("PIMAppInsightsConnectionString");
            var logConfig = new LoggerConfiguration()
                               .MinimumLevel.Information()
                               .MinimumLevel.Override("Microsoft", LogEventLevel.Information)
                               .Enrich.FromLogContext()
                               .Enrich.WithComponentName("PIM-CDOIntegration")
                               .Enrich.WithVersion().WriteTo.Console()
                               .WriteTo.Console(outputTemplate: "[{ComponentName} {Timestamp:HH:mm:ss} {CorrelationId} RequestID: {RequestID} EOWID: {EOWID} PatientFhirId: {PatientFhirId} CdoId: {CdoId} Csn: {Csn} MedicationRequestId: {MedicationRequestId} AppointmentId: {AppointmentId} PendedOrderID: {PendedOrderID} {Level:u3}] {Message:lj}{NewLine}{Exception}")
                               .WriteTo.AzureApplicationInsightsWithConnectionString(connectionString);

            builder.Services.AddLogging(loging =>
            {
                loging.RemoveMicrosoftApplicationInsightsLoggerProvider()
                       .AddSerilog(logConfig.CreateLogger(), dispose: true);
            });

            builder.AddHttpCorrelation();

            // builder.Services.AddSingleton(new RestClient());
            builder.Services.AddSingleton<BasicAuthRestClient>();
            builder.Services.AddSingleton<IFhirTokenService, FhirTokenService>();

            //blob client
            builder.Services.AddAzureClients(clients => {
                clients.AddBlobServiceClient(config.GetValue<string>("PIMBlobStorageConnectionString"))
                .ConfigureOptions(options =>
                {
                    options.Retry.Delay = TimeSpan.FromSeconds(config.GetValue<int>("PauseBetweenFailures"));
                    options.Retry.Mode = RetryMode.Exponential;
                    options.Retry.MaxRetries = config.GetValue<int>("MaxRetryAttempts");
                    options.Retry.NetworkTimeout = TimeSpan.FromSeconds(10);
                });
            });

#if DEBUG
            builder.Services.AddSingleton(client =>
            {
                return new CosmosClient(
                    config.GetValue<string>("PIMCosmosConnectionString"),
                    servicePrincipal,
                    new CosmosClientOptions()
                    {
                        ConnectionMode = ConnectionMode.Gateway,
                        MaxRetryAttemptsOnRateLimitedRequests = config.GetValue<int>("MaxRetryAttempts"),
                        MaxRetryWaitTimeOnRateLimitedRequests = TimeSpan.FromSeconds(config.GetValue<int>("PauseBetweenFailures")),
                        EnableContentResponseOnWrite = false,
                        AllowBulkExecution = true
                    });
            });

#else
            builder.Services.AddSingleton(client =>
            {
                return new CosmosClient(
                    config.GetValue<string>("PIMCosmosConnectionString"), 
                    new DefaultAzureCredential(),
                    new CosmosClientOptions()
                    {
                        ConnectionMode = ConnectionMode.Gateway,
                        MaxRetryAttemptsOnRateLimitedRequests = config.GetValue<int>("MaxRetryAttempts"),
                        MaxRetryWaitTimeOnRateLimitedRequests = TimeSpan.FromSeconds(config.GetValue<int>("PauseBetweenFailures")),
                        EnableContentResponseOnWrite=false,
                        AllowBulkExecution = true
                    });
            });
#endif
            builder.Services.AddSingleton(new RestClient(new RestClientOptions()
            {
                Timeout = TimeSpan.FromMilliseconds(config.GetValue<int>("RestClientTimeOut")) // in milliseconds
            }));

            builder.Services.AddScoped<IFhirResourceConverter, FhirResourceConverter>();
            builder.Services.AddScoped<ICdoServiceFactory, CdoServiceFactory>();
            builder.Services.AddScoped<ICdoFactory, CdoFactory>();
            builder.Services.AddScoped<IAuthFactory, AuthFactory>();
            builder.Services.AddScoped<IEHRFactory, EHRFactory>();

            // builder.Services.AddSingleton(new RestClient());
            builder.Services.AddSingleton<IRestPolicyManager, RestPolicyManager>();
            builder.Services.AddSingleton<IRestClientWrapper, RestClientWrapper>();

            builder.Services.AddScoped<IFhirCrudService, FhirCrudService>();
            
            builder.Services.AddScoped<AllscriptAuthentication>();
            builder.Services.AddScoped<EpicAuthentication>();
            builder.Services.AddScoped<FlexAuthentication>();

            builder.Services.AddScoped<EpicEhrService>();
            //builder.Services.AddScoped<IEHRService, AllscriptEhrService>();
            builder.Services.AddScoped<IBlobServices, BlobServices>();

            builder.Services.AddScoped<KelseyEHRWrapper>();

            builder.Services.AddScoped<KelseyMedicationRequestStatusUpdate>();

            builder.Services.AddScoped<CheckMedicationRequestStatus>();

            builder.Services.AddScoped<ICDSService, AllscriptCDSService>();
            builder.Services.AddScoped<ICDSService, EpicCDSService>();

            builder.Services.AddScoped<EpicMockService>();

            builder.Services.AddScoped<KelseyMessageService>();
            builder.Services.AddScoped<KelseyMockMessageService>();
            builder.Services.AddScoped<IProcessMessageData,ProcessMessageData>();

            builder.Services.AddScoped<SendRecommendation>();
            builder.Services.AddScoped<SendMockRecommendation>();

            builder.Services.AddScoped<KelseyFhirWrapper>();
            
            builder.Services.AddScoped<KelseyMessageService>();
            builder.Services.AddScoped<SignFinalOrder>();
            builder.Services.AddScoped<SignFinalOrderMock>();
            builder.Services.AddScoped<KelseyCdoService>();

            builder.Services.AddMemoryCache();

            builder.Services.AddScoped<FhirMessageHandler>();
            builder.Services.AddScoped<IUtils, Utils>();
            builder.Services.AddScoped<IAzureFhirAPIClient, AzureFhirAPIClient>();
            builder.Services.AddScoped<IBuildFHIRModelService, BuildFHIRModelService>();
            builder.Services.AddScoped<IGetFhirService, GetFhirService>();
            builder.Services.AddScoped<IFhirApiClientService, FhirApiClientService>();
            builder.Services.AddScoped<IFhirService, FhirService>();
            builder.Services.AddScoped<IFhirClientHelper, FhirClientHelper>();
            builder.Services.AddScoped<SendMockMyChartMessage>();
            builder.Services.AddScoped<SendMyChartMessage>();
            builder.Services.AddScoped<IFhirDeleteService, FhirDeleteService>();
            builder.Services.AddScoped<ISendMyChartMessage, SendMyChartMessage>();

            builder.Services.AddScoped<IMedicationRequestStatusUpdater, KelseyMedicationRequestStatusUpdate>();
            builder.Services.AddScoped<ICheckMedicationRequestStatus, CheckMedicationRequestStatus>();

            builder.Services.AddScoped<ICosmosService, CosmosService>();
            builder.Services.AddScoped<IProcessSchedulingTicket, ProcessSchedulingTicket>();

            builder.Services.AddScoped<IValidator<PatientRequestModel>, PatientRequestValidator>();
            builder.Services.AddScoped<IValidator<PIMFhirIdentifier>, IdentifierValidator>();
            builder.Services.AddScoped<IValidator<MessageCollectionRequest>, MessageCollectionValidator>();
            builder.Services.AddScoped<IValidator<MyChartMessageInputModel>, MyChartRequestValidator>();
            builder.Services.AddScoped<IValidator<InputMessage>, InputMessageValidator>();
            builder.Services.AddScoped<IValidator<PendedOrders>, PendedOrdersProviderValidator>();
            builder.Services.AddScoped<IValidator<FlexRequestBody>, FlexRequestValidator>();
            builder.Services.AddScoped<IValidator<OutReachRequest>, OutreachRequestValidator>();
            builder.Services.AddScoped<IValidator<RecommendationInputModel>, SendRecommendationValidator>();

            builder.Services.AddScoped<IAzureConfig, AzureConfig>();

            builder.Services.AddScoped<IFlexService, FlexService>();

            builder.Services.AddSingleton<FhirUtils>();
            builder.Services.AddSingleton<KelseyUtils>();
            builder.Services.AddSingleton<KelseyEHRUtils>();

            builder.Services.AddScoped<IKelseyMessageCollection, KelseyMessageCollection>();

        }
    }
}