﻿// using System;
// using System.Threading.Tasks;
// using FhirServiceLibrary;
// using Microsoft.Azure.WebJobs;
// using Microsoft.Extensions.Configuration;
// using Microsoft.Extensions.Logging;

// namespace CDOIntegrationService.Triggers
// {
//     public class FhirRetentionTimerTrigger
//     {
//         private readonly IFhirApiClientService _fhirApiClientService;
//         private readonly ILogger<FhirRetentionTimerTrigger> _logger;
//         private readonly IConfiguration _configuration;

//         public FhirRetentionTimerTrigger(IFhirApiClientService fhirApiClientService, ILogger<FhirRetentionTimerTrigger> logger, IConfiguration configuration)
//         {
//             _fhirApiClientService = fhirApiClientService;
//             _logger = logger;
//             _configuration = configuration;
//         }

//         [FunctionName("FhirRetentionTimerTrigger")]

//         public async Task Run([TimerTrigger("%FhirRetentionTimerTriggerFrequency%")] TimerInfo myTimer, ILogger log)
//         {
//             try
//             {
//                 _logger.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");

//                 var months = _configuration.GetValue<int>("FhirRetentionMonths");
//                 var sinceDateTime = DateTime.UtcNow.AddMonths(-months);

//                 _logger.LogInformation("Deleting fhir data older than {Time}", sinceDateTime);

//                 await _fhirApiClientService.DeletePastData(sinceDateTime);

//                 _logger.LogInformation($"C# Timer trigger function completed at: {DateTime.Now}");

//             }

//             catch (Exception ex)
//             {
//                 _logger.LogCritical("Exception Occurred for FhirRetentionTimerTrigger. {Error}", ex);
//                 throw;
//             }

//         }
//     }
// }
