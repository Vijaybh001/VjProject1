﻿using System;
using Hl7.Fhir.Model;
using Incubator_OIA_CommonModels;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CDOIntegrationService.Refactor.Models
{
	//public class ResponseModel
	//{
	//	public int Status { get; set; }

	//	[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
	//	public string ErrorMessage { get; set; }
	//}
    public class GetEverythingResponse : ResponseModel
    {
        public string GetEverythingData { get; set; }
    }
    public class UpsertPatientResponse : ResponseModel
    {
        public string UpsertpatientData { get; set; }
    }
    public class UpsertFhirResponse : ResponseModel
    {
        public string UpsertFhirData { get; set; }
    }
    public class GetPatDetailsResponse: ResponseModel
    {
        public PimResource Response { get; set; }
    }
    public class SignOrderResponse: ResponseModel
    {
        public string PendedMedRequestID { get; set; }
    }
    public class GetPatientDetailsResponse
    {
        public ResponseModel APIStatusCode { get; set; }
        public GetPatDetailsResponse GetPatDetailsResponse { get; set; }
    }
    public class GetPatientRawOutputModel
    {
        public ResponseModel APIStatusCode { get; set; }
        public Bundle BundleData { get; set; }
    }
    public class SetPatientOutputModel
    {
        public ResponseModel APIStatusCode { get; set; }
    }
    public class MRStatusResponseModel
    {
        public ResponseModel APIStatusCode { get; set; }
        public string PendedOrderId { get; set; }
        public string PendedOrderIdStatus { get; set; }
    }
}

