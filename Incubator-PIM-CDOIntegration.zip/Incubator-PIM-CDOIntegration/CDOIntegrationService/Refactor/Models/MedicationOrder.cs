﻿using System;
namespace CDOIntegrationService.Refactor.Models
{
	public class MedicationOrder
	{
        public string PatientFhirId { get; set; }
        public string PendedOrderId { get; set; }
    }
}

