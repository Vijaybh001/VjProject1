﻿using System;
using CDOIntegrationService.Refactor.Models;
using System.Threading.Tasks;

namespace CDOIntegrationService.Refactor.ReturnToProvider
{
	public interface ISendRecommendation
	{
        Task<ReturnToProviderResponse> RecommendationMessages(RecommendationInputModel req);
        
    }
}

