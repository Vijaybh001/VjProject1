﻿using System;
using System.Linq;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.DBLayer;
using CDOIntegrationService.Refactor.Models;
using CDOIntegrationService.Triggers;
using Incubator_OIA_CommonModels;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using static Incubator_OIA_CommonModels.CosmosModel;

namespace CDOIntegrationService.Refactor.MessageService.Kelsey
{
	public class KelseyMessageCollection: IKelseyMessageCollection
	{
        private readonly ICdoServiceFactory _cdoFactory;
        private readonly ILogger<KelseyMessageCollection> _logger;
        private readonly ICosmosService _cosmosService;
        private readonly IConfiguration _configuration;

        public KelseyMessageCollection(ILogger<KelseyMessageCollection> log, ICdoServiceFactory cdoFactory, ICosmosService cosmosService, IConfiguration configuration)
		{
            _cdoFactory = cdoFactory;
            _logger = log;
            _cosmosService = cosmosService;
            _configuration = configuration;
        }

        public async Task<OutputMessageCollection> RunMessageCollection()
        {
            try
            {
                _logger.LogInformation("KelseyMessageCollection.RunMessageCollection() execution started ");

                var cdoName = _configuration.GetValue<string>("PimMessageCollectionCDO");
                var ehrName = _configuration.GetValue<string>("PimMessageCollectionEHR");
                var messageTypes = _configuration.GetValue<string>("PimMessageType");
                var cdoService = _cdoFactory.GetCdoService(cdoName);
                CosmosModel.GetMessagesResponse messageResponse = new();

                var lastProcRecord = await _cosmosService.GetLastProcessedTime(cdoName);
                var req = new MessageCollectionRequest()
                {
                    CDOName = cdoName,
                    EHRName = ehrName,
                    eowAgeD = DateTime.Parse(lastProcRecord.date),
                    eowAgeT = DateTime.Parse(lastProcRecord.time),
                    MessageTypes = messageTypes
                };

                var outputMessageCollection = await cdoService.GetMessages(req);

                await _cosmosService.AddMessagesToCosmos(outputMessageCollection);

                if (outputMessageCollection.Messages.Count > 0)
                {
                    var maxDate = outputMessageCollection.Messages.Max(t => t.MsgSubmittedInstant);

                    await _cosmosService.UpdateMaxDateTime(maxDate, lastProcRecord);
                }

                _logger.LogInformation("KelseyMessageCollection.RunMessageCollection() execution ended ");

                return outputMessageCollection;
            }

            catch (Exception ex)
            {
                _logger.LogError("KelseyMessageCollection.RunMessageCollection() failed. {Error}", ex);
                throw;
            }
        }
	}
}

