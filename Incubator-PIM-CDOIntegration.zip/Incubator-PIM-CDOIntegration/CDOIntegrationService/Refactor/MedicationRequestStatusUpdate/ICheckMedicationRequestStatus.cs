﻿using System;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor.Models;

namespace CDOIntegrationService.Refactor.MedicationRequestStatusUpdate
{
	public interface ICheckMedicationRequestStatus
	{
        Task<MRStatusResponseModel> ProcessPendedOrderStatus(MedicationOrder req);
    }
}

