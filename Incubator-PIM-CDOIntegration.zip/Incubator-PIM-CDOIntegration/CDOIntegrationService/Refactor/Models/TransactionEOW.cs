﻿namespace CDOIntegrationService.Refactor.Models
{
    public class TransactionEOW
    {
        public string id { get; set; }
        public string date { get; set; }
        public string time { get; set; }
        public string timeZone { get; set; }
        public string taskAggDateTime { get; set; }
    }
}

