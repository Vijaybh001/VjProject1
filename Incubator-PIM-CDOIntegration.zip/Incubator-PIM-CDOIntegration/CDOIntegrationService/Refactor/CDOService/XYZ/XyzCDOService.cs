using System;
using System.Threading.Tasks;
using CDOIntegrationService.Refactor;
using CDOIntegrationService.Refactor.MessageService;
using CDOIntegrationService.Refactor.Models;
using AzureFhirFramework.RestClientWrapper;
using AzureFhirFramework.RestClientWrapper.RestPolicy;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Incubator_OIA_CommonModels;

namespace CDOIntegrationService;

public class XyzCdoService: ICdoService
{
    private readonly IConfiguration _config;
    private readonly ILogger<XyzCdoService> _logger;
    private readonly IRestClientWrapper _restClientWrapper;
    
    private readonly IEHRWrapper _ehrWrapperService;
    private readonly IFhirWrapper _fhirWrapperService;
    //private readonly ICDSService _cdsService;
    private readonly IMessageService _messageService;


    public XyzCdoService(IConfiguration config, ILogger<XyzCdoService> logger,IRestClientWrapper restClientWrapper,ICdoFactory cdoFactory)
    {
        _config = config;
        _logger = logger;
        _restClientWrapper= restClientWrapper;
        _ehrWrapperService = cdoFactory.GetEhrWrapperService(Constants.XYZ);
        _fhirWrapperService = cdoFactory.GetFhirWrapperService(Constants.XYZ);
        // _cdsService = cdoFactory1.GetCdsService();
        _messageService = cdoFactory.GetMessageService(Constants.XYZ, false);
    }

    public Task<CosmosModel.OutputMessageCollection> GetMessages(MessageCollectionRequest req)
    {
        throw new NotImplementedException();
    }

    public async Task<SignFinalOrderResponseModel> SignFinalOrder(CosmosModel.OutReachRequest req)
    {
        //TODO: This async method lacks 'await' operators and will run synchronously.
        throw  new NotImplementedException();
    }

    public Task<Bundle> GetPatientRaw(PatientRequestModel req)
    {
        throw new NotImplementedException();
    }

    public Task<MyChartMessageOutputModel> SendMyChartMessage(MyChartMessageInputModel req)
    {
        throw new NotImplementedException();
    }

    public Task<PimResource> GetPatientDetailsFromRaw(PatientRequestModel req)
    {
        throw new NotImplementedException();
    }

    public void SendCdsHookA()
    {
        throw new NotImplementedException();
    }

    public Task<bool> SetPatient(PatientRequestModel req)
    {
        throw new NotImplementedException();
    }
    public Task<bool> DeletePatient(PatientRequestModel req)
    {
        throw new System.NotImplementedException();
    }
    public Task<MyChartMessageOutputModel> MkoMessages(MyChartMessageInputModel req)
    {
        throw new NotImplementedException();
    }
    public Task<bool> ProcessSchedulingTicket(SchedulingTicketRequestModel req)
    {
        throw new NotImplementedException();
    }
    public Task<ReturnToProviderResponse> RecommendationMessages(RecommendationInputModel req)
    {
        throw new NotImplementedException();
    }

    public Task<string> SignOrder(FlexRequestBody flexRequestBody)
    {
        throw new NotImplementedException();
    }
    public System.Threading.Tasks.Task GetMedicationRequestUpdaterService(bool updateForActiveProvider)
    {
        throw new NotImplementedException();
    }
    public System.Threading.Tasks.Task<MRStatusResponseModel> CheckMedicationRequestStatusService(MedicationOrder order)
    {
        throw new NotImplementedException();
    }
    public Task<Bundle> GetPatientRawResource(string patientFhirId, string resourceType)
    {
        throw new NotImplementedException();
    }
}