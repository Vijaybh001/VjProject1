﻿using System;
using System.Threading.Tasks;

namespace CDOIntegrationService.Refactor.ConfigService
{
	public interface IAzureConfig
	{
        T GetValueFromAzureConfig<T>(string key);
	}
}

