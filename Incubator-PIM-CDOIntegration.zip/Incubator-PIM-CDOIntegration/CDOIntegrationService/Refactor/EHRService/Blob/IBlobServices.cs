﻿using System;
using System.Threading.Tasks;

namespace CDOIntegrationService
{
    public interface IBlobServices
    {
        Task<string> ReadBlobData(string filePath);
        Task<string> FetchBlobData(string filePath);
    }
}
