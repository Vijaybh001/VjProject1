﻿// using System.Text.Json;
// using CDOIntegrationService;
// using CDOIntegrationService.Refactor.Authentication;
// using CDOIntegrationService.Refactor.EHRService.Kelsey;
// using Hl7.Fhir.Model;
// using Hl7.Fhir.Serialization;
// using Microsoft.Extensions.Configuration;
// using Microsoft.Extensions.Logging;
// using Moq;
//
// namespace UnitTesting_CDO
// {
//     public class KelseyEHRTests
//     {
//         private readonly Mock<IEHRService> _epicMock;
//         private KelseyEHRWrapper _eHRWrapper;
//         private readonly Mock<IFhirResourceConverter> _fhirResourceConverter;
//         private readonly Mock<IAuthentication> _epicAuthentication;
//         private readonly Mock<IAuthFactory> _authMock;
//         private readonly Mock<IEHRFactory> _ehrFactoryMock;
//         public KelseyEHRTests()
//         {
//             _epicMock = new Mock<IEHRService>();
//             _ehrFactoryMock = new();
//             _ehrFactoryMock.Setup(x => x.GetEHRService(It.IsAny<string>(), It.IsAny<bool>())).Returns(_epicMock.Object);
//
//             _epicAuthentication = new Mock<IAuthentication>();
//             _epicAuthentication.Setup(x => x.GetToken()).ReturnsAsync("token");
//
//             _authMock = new();
//             _authMock.Setup(x => x.GetAuthService(It.IsAny<string>())).Returns(_epicAuthentication.Object);
//             _fhirResourceConverter = new Mock<IFhirResourceConverter>();
//             _eHRWrapper = new(new Mock<ILogger<KelseyEHRWrapper>>().Object, _ehrFactoryMock.Object, _fhirResourceConverter.Object, new Mock<IConfiguration>().Object);
//
//         }
//         [Fact]
//         public async System.Threading.Tasks.Task KelseyEHR_GetPatientData_NotNull()
//         {
//             //Arrange
//             var options = new JsonSerializerOptions().ForFhir(ModelInfo.ModelInspector);
//             var bundleOutput = JsonSerializer.Serialize(new Bundle(), options);
//             var patOutput = JsonSerializer.Serialize(new Patient(), options);
//             var id = "id";
//             var refer = "refer";
//
//             //var parser = new FhirJsonParser();
//             _epicMock.Setup(x => x.GetLocation(refer)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetAllergyIntolerance(id)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetAppointment(id)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetCondition(id)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetDiagReport(id)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetEncounter(id)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetMedRequest(id)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetObservation(id)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetPatient(id)).ReturnsAsync(patOutput);
//
//             //Act
//             var response = await _eHRWrapper.GetPatientData(id, false);
//
//             Assert.NotNull(response);
//         }
//         [Fact]
//         public async System.Threading.Tasks.Task KelseyEHR_GetPatientData_Error()
//         {
//             //Arrange
//             Bundle? bundle = null;
//             Patient? patient = null;
//             var options = new JsonSerializerOptions().ForFhir(ModelInfo.ModelInspector);
//             var bundleOutput = JsonSerializer.Serialize(bundle, options);
//             var patOutput = JsonSerializer.Serialize(patient, options);
//
//             var id = "id";
//             var refer = "refer";
//             //var parser = new FhirJsonParser();
//             _epicMock.Setup(x => x.GetLocation(refer)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetAllergyIntolerance(id)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetAppointment(id)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetCondition(id)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetDiagReport(id)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetEncounter(id)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetMedRequest(id)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetObservation(id)).ReturnsAsync(bundleOutput);
//             _epicMock.Setup(x => x.GetPatient(id)).ReturnsAsync(patOutput);
//
//             //Act
//             var exception = await Record.ExceptionAsync(async () => await _eHRWrapper.GetPatientData(string.Empty, false));
//             Assert.Null(exception);
//         }
//     }
// }
//
//
