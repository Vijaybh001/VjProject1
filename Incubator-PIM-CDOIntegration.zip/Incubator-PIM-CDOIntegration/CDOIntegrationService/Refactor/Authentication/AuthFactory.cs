﻿using System;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Serilog.Core;

namespace CDOIntegrationService.Refactor.Authentication
{
	public class AuthFactory: IAuthFactory
	{
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger<AuthFactory> _logger;
		public AuthFactory(IServiceProvider serviceProvider, ILogger<AuthFactory> logger)
		{
            _serviceProvider = serviceProvider;
            _logger = logger;
		}

        public IAuthentication GetAuthService(string serviceName)
        {
            _logger.LogInformation("AuthFactory.GetAuthService() execution started ");
            _logger.LogInformation("AuthFactory.GetAuthService() execution ended ");
            return serviceName switch
            {
                Constants.EPIC => _serviceProvider.GetService<EpicAuthentication>(),
                Constants.FLEX => _serviceProvider.GetService<FlexAuthentication>(),
                _ => throw new Exception("Invalid AuthService Type"),
            };
        }
    }
}

