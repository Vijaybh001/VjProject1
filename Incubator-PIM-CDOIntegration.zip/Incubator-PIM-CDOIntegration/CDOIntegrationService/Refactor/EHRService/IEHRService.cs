using System.Threading.Tasks;
using CDOIntegrationService.Refactor.Models;

namespace CDOIntegrationService
{
    public interface IEHRService
    {
        Task<string> GetPatientData(string patientFhirId, string resourceType, EhrFetchType ehrFetchType);
        Task<string> GetPatientDataForMRUpdater(string patientFhirId, string resourceName);
        Task<bool> GetEhrHealth();

    }
}